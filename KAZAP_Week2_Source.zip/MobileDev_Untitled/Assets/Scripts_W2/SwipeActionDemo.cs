using UnityEngine;
using TMPro;

public class SwipeActionDemo : MonoBehaviour
{
    [Header("References")]
    public SwipeDetector swipeDetector;
    public TextMeshProUGUI debugText;

    void OnEnable()
    {
        if (swipeDetector != null)
            swipeDetector.SwipeDetected += HandleSwipe;
    }

    void OnDisable()
    {
        if (swipeDetector != null)
            swipeDetector.SwipeDetected -= HandleSwipe;
    }

    private void HandleSwipe(SwipeDetector.SwipeDirection dir)
    {
        // Example mapping we�ll use in KAZAP!
        if (dir == SwipeDetector.SwipeDirection.Up)
        {
            SetDebug("Aegis Burst!");
            return;
        }

        SetDebug($"Swipe mapped: {dir}");
    }

    private void SetDebug(string msg)
    {
        if (debugText != null)
            debugText.text = msg;

        Debug.Log(msg);
    }
}