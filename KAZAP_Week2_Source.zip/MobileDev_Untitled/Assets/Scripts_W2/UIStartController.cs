using System.Collections;
using UnityEngine;
using TMPro;

public class UIStartController : MonoBehaviour
{
    [Header("UI")]
    public GameObject titlePanel;
    public GameObject hudPanel;
    public TextMeshProUGUI countdownText;

    [Header("Gameplay Roots")]
    public GameObject groundRoot;
    public GameObject shieldStackRoot;

    [Header("Zeus + Spawning")]
    public GameObject spawningRoot;   // <-- ADD THIS (assign Spawning here)
    public Transform zeus;
    public ZeusMover zeusMover;
    public BoltSpawner boltSpawner;

    [Header("Intro")]
    public Vector3 zeusIntroStartPos = new Vector3(0f, 4.2f, 0f);  // off-screen-ish
    public Vector3 zeusIntroEndPos = new Vector3(0f, 3.3f, 0f);    // centered at band
    public float zeusIntroMoveTime = 0.6f;

    public void OnPressStart()
    {
        Debug.Log("START BUTTON PRESSED");
        Debug.Log($"titlePanel: {(titlePanel ? titlePanel.name : "NULL")}");
        Debug.Log($"hudPanel: {(hudPanel ? hudPanel.name : "NULL")}");
        Debug.Log($"groundRoot: {(groundRoot ? groundRoot.name : "NULL")}");
        Debug.Log($"shieldStackRoot: {(shieldStackRoot ? shieldStackRoot.name : "NULL")}");
        Debug.Log($"spawningRoot: {(spawningRoot ? spawningRoot.name : "NULL")}");
        StartCoroutine(StartGameRoutine());
    }

    private IEnumerator StartGameRoutine()
    {
        // Hide menu
        if (titlePanel != null) titlePanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);

        // Show gameplay
        if (groundRoot != null) groundRoot.SetActive(true);
        if (shieldStackRoot != null) shieldStackRoot.SetActive(true);

        // IMPORTANT: BoltSpawner lives under Spawning. If Spawning is inactive, coroutines can't run.
        if (spawningRoot != null) spawningRoot.SetActive(true);

        // Pause gameplay systems during intro
        if (zeusMover != null) zeusMover.enabled = false;
        if (boltSpawner != null) boltSpawner.StopRound();

        // Intro move: Zeus floats to center
        if (zeus != null)
        {
            zeus.position = zeusIntroStartPos;

            float t = 0f;
            while (t < zeusIntroMoveTime)
            {
                t += Time.deltaTime;
                float a = Mathf.Clamp01(t / zeusIntroMoveTime);
                zeus.position = Vector3.Lerp(zeusIntroStartPos, zeusIntroEndPos, a);
                yield return null;
            }
            zeus.position = zeusIntroEndPos;
        }

        // Countdown
        if (countdownText != null)
        {
            countdownText.gameObject.SetActive(true);

            countdownText.text = "3";
            yield return new WaitForSeconds(0.6f);
            countdownText.text = "2";
            yield return new WaitForSeconds(0.6f);
            countdownText.text = "1";
            yield return new WaitForSeconds(0.6f);

            countdownText.text = "GO!";
            yield return new WaitForSeconds(0.4f);

            countdownText.gameObject.SetActive(false);
        }

        // Start gameplay
        if (zeusMover != null) zeusMover.enabled = true;
        if (boltSpawner != null) boltSpawner.StartRound();
    }
}