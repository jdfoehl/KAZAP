using UnityEngine;
using TMPro;

public class AccelerometerDebug : MonoBehaviour
{
    [Header("UI")]
    public TextMeshProUGUI debugText;

    [Header("Smoothing")]
    [Tooltip("0.1�0.3 is a good starting range. Higher = snappier, lower = smoother.")]
    public float smoothing = 0.15f;

    [Header("Editor Fallback (keyboard)")]
    public bool useKeyboardFallbackInEditor = true;
    [Tooltip("How strongly the keyboard drives the simulated acceleration.")]
    public float keyboardAccelStrength = 0.75f;

    [Header("Optional: Shake Detection (stretch / KAZAP candidate)")]
    public bool showShakeInfo = true;
    [Tooltip("Higher = harder to trigger. Start around 1.2�1.6.")]
    public float shakeThreshold = 1.35f;
    [Tooltip("Seconds between shake triggers.")]
    public float shakeCooldown = 0.75f;

    private Vector3 smoothedAccel;
    private float lastShakeTime = -999f;

    // Latch shake message so it stays visible
    private float shakeDisplayUntil = 0f;
    private int shakeCount = 0;

    void Update()
    {
        // Raw sensor value (will be Vector3.zero in the Unity Editor)
        Vector3 rawAccel = Input.acceleration;

        // Keyboard fallback for Editor iteration
        if (Application.isEditor && useKeyboardFallbackInEditor)
        {
            float x = 0f;
            float y = 0f;

            if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) x = -1f;
            if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) x = 1f;
            if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S)) y = -1f;
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) y = 1f;

            // Simulate a gravity-ish vector that changes with "tilt"
            rawAccel = new Vector3(x, -1f, y) * keyboardAccelStrength;
        }

        // Smooth it
        smoothedAccel = Vector3.Lerp(smoothedAccel, rawAccel, smoothing);

        // Basic tilt direction off X axis (like the lesson)
        string tiltLabel;
        if (Mathf.Abs(smoothedAccel.x) > 0.2f)
            tiltLabel = smoothedAccel.x > 0 ? "Tilt: RIGHT" : "Tilt: LEFT";
        else
            tiltLabel = "Tilt: UPRIGHT";

        // Optional shake detection (deliberate spike)
        bool shakeTriggered = false;
        float shakeSignal = 0f;

        if (showShakeInfo)
        {
            // Measure how much raw deviates from the smoothed "baseline" (filters out gravity)
            shakeSignal = (rawAccel - smoothedAccel).magnitude;

            if (shakeSignal > shakeThreshold && Time.time - lastShakeTime >= shakeCooldown)
            {
                shakeTriggered = true;
                lastShakeTime = Time.time;

                shakeCount++;
                shakeDisplayUntil = Time.time + 0.5f; // keep message visible for half a second
                Debug.Log($"Shake detected! Count={shakeCount}  Signal={shakeSignal:F2}");
            }
        }

        if (debugText != null)
        {
            string s = "ACCELEROMETER\n\n";
            s += $"RAW\nX: {rawAccel.x:F2}\nY: {rawAccel.y:F2}\nZ: {rawAccel.z:F2}\nMag: {rawAccel.magnitude:F2}\n\n";
            s += $"SMOOTHED\nX: {smoothedAccel.x:F2}\nY: {smoothedAccel.y:F2}\nZ: {smoothedAccel.z:F2}\nMag: {smoothedAccel.magnitude:F2}\n\n";
            s += $"{tiltLabel}\n";

            if (showShakeInfo)
            {
                s += $"\nShake Signal: {shakeSignal:F2}";
                s += $"\nShake Threshold: {shakeThreshold:F2}";
                s += $"\nShake Count: {shakeCount}";

                if (Time.time < shakeDisplayUntil)
                    s += "\n\n*** SHAKE TRIGGERED! ***";
            }

            debugText.text = s;
        }

        if (shakeTriggered)
            Debug.Log("Shake detected (debug)");
    }
}