using UnityEngine;
using TMPro;

public class TouchDetector : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TMP_Text feedbackText;

    [Header("Tap/Swipe Settings (pixels)")]
    [SerializeField] private float tapMaxDistance = 20f;     // <= this = tap
    [SerializeField] private float swipeMinDistance = 80f;   // >= this = swipe
    [SerializeField] private float swipeMaxTime = 0.5f;      // optional timing gate

    private Vector2 startPos;
    private float startTime;
    private bool tracking;

    private void Start()
    {
        if (feedbackText != null)
            feedbackText.text = "Waiting for input...";
    }

    private void Update()
    {
        // ---- Touch input (real device / emulator) ----
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);

            if (t.phase == TouchPhase.Began)
            {
                Begin(t.position);
            }
            else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
            {
                End(t.position, isTouch: true);
            }

            return; // If touch exists, don't also process mouse this frame
        }

        // ---- Mouse fallback (Unity Editor testing) ----
        if (Input.GetMouseButtonDown(0))
        {
            Begin(Input.mousePosition);
        }
        else if (Input.GetMouseButtonUp(0))
        {
            End(Input.mousePosition, isTouch: false);
        }
    }

    private void Begin(Vector2 screenPos)
    {
        tracking = true;
        startPos = screenPos;
        startTime = Time.time;

        SetText("Touch began...");
    }

    private void End(Vector2 endPos, bool isTouch)
    {
        if (!tracking)
            return;

        tracking = false;

        float elapsed = Time.time - startTime;
        float dist = Vector2.Distance(startPos, endPos);

        // TAP
        if (dist <= tapMaxDistance)
        {
            SetText(isTouch ? "TAP detected!" : "TAP detected! (mouse)");
            return;
        }

        // SWIPE (distance gate + optional time gate)
        if (dist >= swipeMinDistance && elapsed <= swipeMaxTime)
        {
            Vector2 delta = endPos - startPos;
            string dir = GetDirection(delta);
            SetText(isTouch ? $"SWIPE detected! ({dir})" : $"SWIPE detected! ({dir}) (mouse)");
            return;
        }

        // Otherwise: movement happened, but it didn't meet our �swipe� rules
        SetText($"Movement detected (not tap/swipe)\nDist: {dist:0} px  Time: {elapsed:0.00}s");
    }

    private string GetDirection(Vector2 delta)
    {
        // Decide based on which axis is larger
        if (Mathf.Abs(delta.x) > Mathf.Abs(delta.y))
            return (delta.x > 0f) ? "Right" : "Left";
        else
            return (delta.y > 0f) ? "Up" : "Down";
    }

    private void SetText(string msg)
    {
        if (feedbackText != null)
            feedbackText.text = msg;
    }
}