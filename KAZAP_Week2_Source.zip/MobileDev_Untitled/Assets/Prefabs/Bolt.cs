using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Collider2D))]
public class Bolt : MonoBehaviour
{
    [Header("Fall (Kinematic)")]
    public float fallSpeed = 8f;          // units/sec
    public float maxLifetime = 6f;        // safety despawn

    [Header("Debug")]
    public int spawnId;

    [Header("Effects (optional)")]
    public GameObject explodeVfxPrefab;

    private RoundManager rm;
    private Rigidbody2D rb;

    private float lifeTimer;
    private bool isDead;
    private bool isFrozen;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Called by RoundManager.RegisterBolt(...)
    public void Init(RoundManager roundManager, int id)
    {
        rm = roundManager;
        spawnId = id;
    }

    private void OnEnable()
    {
        lifeTimer = 0f;
        isDead = false;
        isFrozen = false;

        // Ensure we start "live" every spawn
        if (rb != null)
            rb.simulated = true;
    }

    private void FixedUpdate()
    {
        if (isDead || isFrozen) return;

        // Kinematic fall straight down (no physics gravity)
        Vector2 p = rb.position;
        p.y -= fallSpeed * Time.fixedDeltaTime;
        rb.MovePosition(p);

        // Safety despawn
        lifeTimer += Time.fixedDeltaTime;
        if (lifeTimer >= maxLifetime)
            Explode();
    }

    public void FreezeBolt()
    {
        if (isDead) return;

        isFrozen = true;

        // We *want* everything to truly stop (and we use realtime waits in RoundManager)
        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.angularVelocity = 0f;
            rb.simulated = false;
        }
    }

    public void Explode()
    {
        if (isDead) return;
        isDead = true;

        if (explodeVfxPrefab != null)
            Instantiate(explodeVfxPrefab, transform.position, Quaternion.identity);

        if (rm != null)
            rm.UnregisterBolt(this);

        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isDead) return;

        if (other.CompareTag("Shield"))
        {
            // Caught by shield -> vanish immediately
            Explode();
            return;
        }

        if (other.CompareTag("Ground"))
        {
            // Miss -> trigger Kaboom loss sequence
            if (rm != null)
                rm.OnBoltHitGround(this);
            else
                Explode(); // fallback
        }
    }

    private void OnDestroy()
    {
        if (rm != null)
            rm.UnregisterBolt(this);
    }
}