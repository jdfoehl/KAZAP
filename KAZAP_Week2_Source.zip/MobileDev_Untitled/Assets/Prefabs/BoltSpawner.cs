using System.Collections;
using UnityEngine;

public class BoltSpawner : MonoBehaviour
{
    [Header("References")]
    public Transform firePoint;      // Zeus child transform at the hand
    public GameObject boltPrefab;    // your Bolt prefab

    [Header("Round Settings")]
    public int boltsPerRound = 20;   // tunable difficulty scalar
    public float minSpawnDelay = 0.25f;
    public float maxSpawnDelay = 0.60f;

    [Header("Spawn Jitter")]
    public float xJitter = 0.15f;    // small randomness left/right

    private Coroutine spawnRoutine;
    private bool isPaused;

    public RoundManager roundManager;

    [Header("Debug")]
    public bool autoStart = false;

    private void Start()
    {
        if (autoStart)
            StartRound();
    }

    public void StartRound()
    {
        StopRound();

        spawnRoutine = StartCoroutine(SpawnRoundRoutine());
    }

    public void StopRound()
    {
        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
    }

    public void SetPaused(bool paused)
    {
        isPaused = paused;
    }

    private IEnumerator SpawnRoundRoutine()
    {
        for (int i = 0; i < boltsPerRound; i++)
        {
            // Pause gate (STH uses this)
            while (isPaused)
                yield return null;

            SpawnOneBolt();

            // Pausable delay (so delay time doesn't elapse during STH pause)
            float wait = Random.Range(minSpawnDelay, maxSpawnDelay);
            yield return WaitPausable(wait);
        }

        // Notify RoundManager that spawning is finished for this round
        if (roundManager != null)
        {
            roundManager.OnSpawnerFinishedThisRound();
        }
    }

    private IEnumerator WaitPausable(float seconds)
    {
        float t = 0f;
        while (t < seconds)
        {
            if (!isPaused)
                t += Time.deltaTime;

            yield return null;
        }
    }

    private void SpawnOneBolt()
    {
        if (boltPrefab == null || firePoint == null) return;

        Vector3 pos = firePoint.position;
        pos.x += Random.Range(-xJitter, xJitter);

        GameObject go = Instantiate(boltPrefab, pos, Quaternion.identity);

        // Register so RoundManager can freeze + sequence-pop
        if (roundManager != null)
        {
            Bolt b = go.GetComponent<Bolt>();
            if (b != null)
                roundManager.RegisterBolt(b);
        }
    }
}