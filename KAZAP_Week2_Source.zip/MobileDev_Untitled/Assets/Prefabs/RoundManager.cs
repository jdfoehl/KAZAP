using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class RoundSettings
{
    public string label = "Round 1";

    [Header("Spawner")]
    public int boltsPerRound = 20;
    public float minSpawnDelay = 0.25f;
    public float maxSpawnDelay = 0.60f;

    [Header("Zeus")]
    public float zeusMoveSpeed = 2.0f;
    public float zeusMinChangeTime = 0.4f;
    public float zeusMaxChangeTime = 1.2f;

    [Header("Round Clear UI")]
    [TextArea(2, 3)]
    public string clearTauntText = "Not bad... but it�s not over!";
    public float clearTauntHoldTime = 1.0f;

    public float roundLabelHoldTime = 1.0f;
}

public class RoundManager : MonoBehaviour
{
    [Header("Refs")]
    public BoltSpawner boltSpawner;
    public ZeusMover zeusMover;
    public ShieldDragController shieldDrag;

    [Header("Gameplay Roots (enable/disable)")]
    public GameObject groundRoot;     // e.g., Ground_Test
    public GameObject spawningRoot;   // e.g., Spawning
    public GameObject worldRoot;      // optional: World (if you want one toggle)

    [Header("UI")]
    public GameObject titlePanel;
    public GameObject hudPanel;
    public TMPro.TextMeshProUGUI centerText; // big center text (taunt/countdown)

    [Header("Shake the Heavens UI")]
    public Image shakeIcon;                 // assign your top-right icon Image
    [Range(0f, 1f)] public float shakeIconDimAlpha = 0.25f;
    [Range(0f, 1f)] public float shakeIconLitAlpha = 1.0f;

    [Tooltip("Prototype: Shake becomes available automatically starting at this round index.")]
    public int shakeUnlockRoundIndex = 3;

    // Runtime state
    private bool shakeAvailable;
    private bool shakeUsed;

    // STH effect runtime
    private Coroutine sthRoutine;

  

    [Header("Start Gate Prompt")]
    public GameObject tapHoldPrompt;   // assign a small TMP object near shields
    public GameObject shieldAuraRoot;  // assign an aura GO (can be empty for now)

    [Header("Intro Text")]
    [TextArea(2, 3)]
    public string tauntText = "You cannot block the heavens!";

    [Header("Intro Timing")]
    public float tauntHoldTime = 1.0f;        // how long taunt stays up
    public float countdownStepTime = 0.75f;   // time between 3 -> 2 -> 1
    public float goHoldTime = 0.5f;           // how long "GO!" stays up

    [Header("Intro Labels")]
    public string countdown3 = "3";
    public string countdown2 = "2";
    public string countdown1 = "1";
    public string goText = "GO!";

    [Header("Game Over UI")]
    [TextArea(2, 3)]
    public string gameOverTauntText = "Pathetic.";
    public float gameOverTauntHoldTime = 1.0f;

    public string gameOverText = "GAME OVER";
    public float gameOverHoldTime = 1.5f;

    [Header("Round Progression")]
    public int currentRoundIndex = 1; // 1-based
    public List<RoundSettings> rounds = new List<RoundSettings>()
{
    new RoundSettings(){ label="Round 1", boltsPerRound=20, minSpawnDelay=0.25f, maxSpawnDelay=0.60f },
    new RoundSettings(){ label="Round 2", boltsPerRound=30, minSpawnDelay=0.22f, maxSpawnDelay=0.55f },
    new RoundSettings(){ label="Round 3", boltsPerRound=40, minSpawnDelay=0.18f, maxSpawnDelay=0.45f },
};

    [TextArea(2, 3)]
    public string roundClearTauntText = "Not bad... but it�s not over!";
    public float roundClearTauntHoldTime = 1.0f;

    public float roundLabelHoldTime = 1.0f;

    [TextArea(2, 3)]
    public string finalWinText = "YOU WIN!";
    public float finalWinHoldTime = 1.5f;

    [Header("Reset")]
    public Transform zeusRoot;        // Zeus transform to reset position
    public Transform shieldStackRoot; // ShieldStack transform to reset position
    public float resetDelay = 1.0f;   // pause after the pop sequence

    [Header("Kaboom Pop Timing")]
    public float firstBoomHold = 0.10f;  // tiny beat after the first ground boom
    public float popInterval = 0.07f;    // time between each bolt pop

    [Header("Shake the Heavens (STH)")]
    [Tooltip("How long Zeus + spawning are stunned when STH is used.")]
    public float sthStunDuration = 1.25f;

    [Tooltip("If true, Zeus + spawner are both paused during STH (recommended).")]
    public bool sthPausesSpawner = true;

    private bool inSTHSequence;

    [Header("Shields / Lives")]
    [Tooltip("If empty, RoundManager will auto-cache Shield-tagged children under ShieldStackRoot (bottom->top).")]

    [Header("Shield Aura (tint)")]
    public Color auraOffColor = Color.white;
    public Color auraOnColor = new Color(1f, 0.92f, 0.35f, 1f); // warm yellow

    private readonly List<SpriteRenderer> shieldRenderersBottomToTop = new();

    public List<GameObject> shieldsBottomToTop = new();

    [Tooltip("If true, shields are found automatically at runtime from ShieldStackRoot children with tag 'Shield'.")]
    public bool autoCacheShieldsFromStack = true;

    [Header("Game Over")]
    public bool autoRestartAfterGameOver = false;
    public float gameOverRestartDelay = 1.5f;

    private readonly List<Bolt> activeBolts = new();
    private bool inLossSequence;
    private bool isGameOver;
    private int nextSpawnId = 1;

    public bool IsInLossSequence => inLossSequence;
    public bool IsGameOver => isGameOver;

    // Start-gate state
    private bool waitingForFirstGrab;
    private bool gameplayStarted; // prevents double-start if GrabStarted fires twice

    // Round-complete tracking
    private int spawnedThisRound;
    private int resolvedThisRound;
    private bool spawnerFinishedThisRound;
    private bool inRoundCompleteSequence;

    private void Awake()
    {
        CacheShieldsIfNeeded();
    }

    private void CacheShieldsIfNeeded()
    {
        if (!autoCacheShieldsFromStack) return;
        if (shieldsBottomToTop != null && shieldsBottomToTop.Count > 0) return;
        if (shieldStackRoot == null) return;

        // Find Shield-tagged children and sort bottom->top by Y
        shieldsBottomToTop = shieldStackRoot
            .GetComponentsInChildren<Transform>(true)
            .Where(t => t != shieldStackRoot && t.CompareTag("Shield"))
            .OrderBy(t => t.position.y)
            .Select(t => t.gameObject)
            .ToList();
    }

    public void RegisterBolt(Bolt b)
    {
        if (b == null) return;

        if (!activeBolts.Contains(b))
        {
            activeBolts.Add(b);
            spawnedThisRound++;
        }

        b.Init(this, nextSpawnId++);
    }

    public void UnregisterBolt(Bolt b)
    {
        if (b == null) return;

        // Only count as resolved if it was actually tracked
        if (activeBolts.Remove(b))
        {
            resolvedThisRound++;
            TryHandleRoundComplete();
        }
    }

    public void StartRound()
    {
        if (isGameOver) return;
        if (boltSpawner != null) boltSpawner.StartRound();
    }

    public void OnBoltHitGround(Bolt groundBolt)
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        StartCoroutine(LifeLostSequence(groundBolt));
    }

    private IEnumerator LifeLostSequence(Bolt groundBolt)
    {
        inLossSequence = true;

        // 1) Freeze gameplay
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;
        SetAuraVisible(false);
        SetPromptVisible(false);

        // Freeze all bolts in place (including the one that hit ground)
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else activeBolts[i].FreezeBolt();
        }

        // 2) First boom: explode the ground-hit bolt immediately
        if (groundBolt != null) groundBolt.Explode();

        yield return new WaitForSecondsRealtime(firstBoomHold);

        // 3) Snapshot remaining bolts, sort bottom -> top
        List<Bolt> snapshot = activeBolts
            .Where(b => b != null)
            .OrderBy(b => b.transform.position.y)  // bottom first
            .ThenBy(b => b.spawnId)                // tie-breaker
            .ToList();

        // 4) Pop them one-by-one upward
        foreach (Bolt b in snapshot)
        {
            if (b == null) continue;
            b.Explode();
            yield return new WaitForSecondsRealtime(popInterval);
        }

        // Make sure our list is clean after the pops
        activeBolts.RemoveAll(b => b == null);

        // 5) Lose ONE shield (bottom-most active)
        bool removed = RemoveOneShield();

        // IMPORTANT: If that was the last shield, STOP HERE (do NOT resume / start next round)
        if (!removed || AreAllShieldsGone())
        {
            HandleGameOver();
            inLossSequence = false;

            if (autoRestartAfterGameOver)
            {
                yield return new WaitForSecondsRealtime(gameOverRestartDelay);
                RestartFromGameOver();
            }

            yield break;
        }

        // 6) Reset-to-center (prototype behavior)
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        yield return new WaitForSecondsRealtime(resetDelay);

        // After a life loss, do Countdown/GO again (no taunt, no prompt),
        // then require a grab before Zeus starts throwing.
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        // Ensure spawner is set to the current round after a life loss restart
        ApplyRoundDifficulty(currentRoundIndex);

        // Reset tracking for the restarted attempt of this same round
        BeginRoundTracking();

        // Re-arm the �grab to begin� gate
        SubscribeShieldDragSignals();

        gameplayStarted = false;
        waitingForFirstGrab = true;

        // Keep Zeus frozen until grab
        if (zeusMover != null) zeusMover.enabled = false;

        // Allow dragging so they can �start� by grabbing
        if (shieldDrag != null) shieldDrag.enabled = true;

        // No prompt on life-loss restarts
        SetPromptVisible(false);

        // Aura should be off until they�re holding
        SetAuraVisible(false);

        // IMPORTANT: do not StartRound() here � OnShieldGrabStarted() will start it.
        inLossSequence = false;
    }

    private IEnumerator RoundCompleteSequence()
    {
        // Freeze gameplay immediately
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        // Snap Zeus + shields to center (like life lost)
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        // --- Round clear messaging ---
        // (Assumes you�ll add the inspector knobs shown below)
        RoundSettings prev = rounds[Mathf.Clamp(currentRoundIndex - 1, 0, rounds.Count - 1)];
        if (!string.IsNullOrEmpty(prev.clearTauntText))
        {
            ShowCenterText(prev.clearTauntText);
            yield return new WaitForSecondsRealtime(prev.clearTauntHoldTime);
        }

        currentRoundIndex++; // 1 -> 2 -> 3 etc

        // If we just completed the last round, treat it like a �win� for now
        int totalRounds = (rounds != null) ? rounds.Count : 0;
        if (currentRoundIndex > totalRounds)
        {
            ShowCenterText(finalWinText);
            yield return new WaitForSecondsRealtime(finalWinHoldTime);
            HideCenterText();
            ReturnToTitleScreenAndReset();
            yield break;
        }

        RoundSettings next = rounds[Mathf.Clamp(currentRoundIndex - 1, 0, rounds.Count - 1)];
        ShowCenterText(next.label);
        yield return new WaitForSecondsRealtime(next.roundLabelHoldTime);

        // Countdown/GO (no taunt, no prompt)
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        // Apply difficulty for the new round BEFORE we allow the grab gate
        ApplyRoundDifficulty(currentRoundIndex);

        // Re-arm �grab to begin� gate (NO prompt text)
        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        // Allow dragging so the player can �start� by grabbing
        if (shieldDrag != null) shieldDrag.enabled = true;

        // Keep Zeus frozen until grab starts the round
        if (zeusMover != null) zeusMover.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        // Reset round counters for the next round
        spawnedThisRound = 0;
        resolvedThisRound = 0;
        spawnerFinishedThisRound = false;

        // IMPORTANT: Do NOT StartRound() here � OnShieldGrabStarted() will start it.
    }

    private bool RemoveOneShield()
    {
        CacheShieldsIfNeeded();

        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0)
            return false;

        // Remove the lowest ACTIVE shield
        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf)
            {
                s.SetActive(false);
                return true;
            }
        }

        return false;
    }

    private bool AreAllShieldsGone()
    {
        CacheShieldsIfNeeded();

        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0)
            return true;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf)
                return false;
        }

        return true;
    }

    private void HandleGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        // Stop all active gameplay systems immediately
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        StartCoroutine(GameOverRoutine());
    }

    private IEnumerator GameOverRoutine()
    {
        // Safety: freeze + clear any remaining bolts (in case any survived)
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else
            {
                activeBolts[i].FreezeBolt();
                activeBolts[i].Explode();
            }
        }
        activeBolts.RemoveAll(b => b == null);

        // Snap Zeus to center X (keep his Y)
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        // Optional taunt
        if (!string.IsNullOrEmpty(gameOverTauntText))
        {
            ShowCenterText(gameOverTauntText);
            yield return new WaitForSecondsRealtime(gameOverTauntHoldTime);
        }

        // GAME OVER label
        ShowCenterText(gameOverText);
        yield return new WaitForSecondsRealtime(gameOverHoldTime);

        HideCenterText();

        ReturnToTitleScreenAndReset();
    }

    private void ReturnToTitleScreenAndReset()
    {
        // UI: back to title
        if (titlePanel != null) titlePanel.SetActive(true);
        if (hudPanel != null) hudPanel.SetActive(false);

        // Disable gameplay roots so the title is clean
        if (spawningRoot != null) spawningRoot.SetActive(false);
        if (groundRoot != null) groundRoot.SetActive(false);
        if (worldRoot != null) worldRoot.SetActive(false);

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(false);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(false);

        // Reset shields so a new game starts fresh next time
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        // Reset positions (optional but nice)
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }
        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        // Clear gate/prompt/aura state
        waitingForFirstGrab = false;
        gameplayStarted = false;

        SetAuraVisible(false);
        SetPromptVisible(false);
        HideCenterText();

        // Reset flags so OnPressStart can begin again
        inLossSequence = false;
        currentRoundIndex = 1;
        // Reset difficulty back to Round 1 so the next Start is always clean
        ApplyRoundDifficulty(currentRoundIndex);

        ResetShakeStateForNewRun();

        // Reset tracking flags/counters
        BeginRoundTracking();
        inRoundCompleteSequence = false;
        isGameOver = false;
    }

    private void RestartFromGameOver()
    {
        // Re-enable all shields
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
            {
                if (s != null) s.SetActive(true);
            }
        }

        // Reset positions
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        isGameOver = false;

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        StartRound();
    }
    public void OnPressStart()
    {
        StartCoroutine(BeginGameRoutine());
    }

    private IEnumerator BeginGameRoutine()
    {
        // UI swap
        if (titlePanel != null) titlePanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);

        currentRoundIndex = 1;

        ResetShakeStateForNewRun();

        // NEW GAME: force Round 1 difficulty onto the BoltSpawner
        ApplyRoundDifficulty(currentRoundIndex);

        // NEW GAME: reset round tracking state so RoundComplete can't inherit old values
        BeginRoundTracking();
        inRoundCompleteSequence = false;

        // ENABLE gameplay roots (this is what your current RoundManager was missing)
        if (worldRoot != null) worldRoot.SetActive(true);
        if (groundRoot != null) groundRoot.SetActive(true);
        if (spawningRoot != null) spawningRoot.SetActive(true);

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(true);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(true);

        // Re-enable shields at game start (in case you had them disabled in hierarchy)
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        // Hard-freeze everything before the intro
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        // Ensure prompt/aura are hidden during taunt + countdown
        SetPromptVisible(false);
        SetAuraVisible(false);

        // Zeus �float in� (simple version)
        if (zeusRoot != null)
        {
            Vector3 end = zeusRoot.position;
            Vector3 start = end;
            start.y += 2.0f;              // adjust: how far �offscreen� you want
            zeusRoot.position = start;

            float t = 0f;
            const float dur = 0.6f;
            while (t < dur)
            {
                t += Time.unscaledDeltaTime;
                zeusRoot.position = Vector3.Lerp(start, end, t / dur);
                yield return null;
            }
            zeusRoot.position = end;
        }

        // Taunt
        ShowCenterText(tauntText);
        yield return new WaitForSecondsRealtime(tauntHoldTime);

        // Round 1 label (so it matches the Round 2/3 flow)
        RoundSettings r1 = (rounds != null && rounds.Count > 0) ? rounds[0] : null;
        if (r1 != null && !string.IsNullOrEmpty(r1.label))
        {
            ShowCenterText(r1.label);
            yield return new WaitForSecondsRealtime(r1.roundLabelHoldTime);
        }

        // Countdown
        ShowCenterText(countdown3);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown2);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown1);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(goText);
        yield return new WaitForSecondsRealtime(goHoldTime);

        HideCenterText();

        // Gate start: player must tap+hold shields to begin
        SubscribeShieldDragSignals();

        gameplayStarted = false;
        waitingForFirstGrab = true;

        // Allow dragging now (so the player can "start" the round), but keep Zeus frozen
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = true;

        // Show prompt + ensure aura is off until they�re holding
        SetAuraVisible(false);
        SetPromptVisible(true);

        // IMPORTANT: Do NOT StartRound() here � OnShieldGrabStarted() will start it.
    }
    private void ShowCenterText(string msg)
    {
        if (centerText == null) return;
        centerText.gameObject.SetActive(true);
        centerText.text = msg;
    }

    private void HideCenterText()
    {
        if (centerText == null) return;
        centerText.text = "";
        centerText.gameObject.SetActive(false);
    }
    private void SetPromptVisible(bool on)
    {
        if (tapHoldPrompt != null) tapHoldPrompt.SetActive(on);
    }

    private void SetAuraVisible(bool on)
    {
        CacheShieldRenderersIfNeeded();

        Color target = on ? auraOnColor : auraOffColor;

        for (int i = 0; i < shieldRenderersBottomToTop.Count; i++)
        {
            SpriteRenderer sr = shieldRenderersBottomToTop[i];
            if (sr == null) continue;

            // Only tint active shields (so it works with 3/2/1 automatically)
            if (sr.gameObject.activeInHierarchy)
                sr.color = target;
        }
    }

    private void SubscribeShieldDragSignals()
    {
        if (shieldDrag == null) return;

        // Prevent double-subscribe if BeginGameRoutine runs again later
        shieldDrag.GrabStarted -= OnShieldGrabStarted;
        shieldDrag.GrabEnded -= OnShieldGrabEnded;

        shieldDrag.GrabStarted += OnShieldGrabStarted;
        shieldDrag.GrabEnded += OnShieldGrabEnded;
    }

    private void UnsubscribeShieldDragSignals()
    {
        if (shieldDrag == null) return;
        shieldDrag.GrabStarted -= OnShieldGrabStarted;
        shieldDrag.GrabEnded -= OnShieldGrabEnded;
    }

    private void OnShieldGrabStarted()
    {
        // Aura should always reflect "holding"
        SetAuraVisible(true);

        // If we�re still waiting to start, THIS is the moment we begin gameplay.
        if (!waitingForFirstGrab || gameplayStarted || isGameOver) return;

        gameplayStarted = true;
        waitingForFirstGrab = false;

        SetPromptVisible(false);

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        BeginRoundTracking();
        StartRound();
    }

    private void OnShieldGrabEnded()
    {
        // Aura off when finger lifts
        SetAuraVisible(false);
    }
    private void CacheShieldRenderersIfNeeded()
    {
        if (shieldRenderersBottomToTop.Count > 0) return;

        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null) return;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s == null) continue;

            SpriteRenderer sr = s.GetComponent<SpriteRenderer>();
            if (sr != null) shieldRenderersBottomToTop.Add(sr);
        }
    }
    private IEnumerator PlayCountdownOnlyRoutine()
    {
        // Countdown (no taunt)
        ShowCenterText(countdown3);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown2);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown1);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(goText);
        yield return new WaitForSecondsRealtime(goHoldTime);

        HideCenterText();
    }
    public void OnSpawnerFinishedThisRound()
    {
        spawnerFinishedThisRound = true;
        TryHandleRoundComplete();
    }
    private void BeginRoundTracking()
    {
        spawnedThisRound = 0;
        resolvedThisRound = 0;
        spawnerFinishedThisRound = false;
        nextSpawnId = 1;
    }

    private void TryHandleRoundComplete()
    {
        // Don�t complete a round during loss/gameover/intro gates
        if (isGameOver) return;
        if (inLossSequence) return;

        // If you have flags like these already, keep them.
        // This method assumes you already track:
        // - spawnedThisRound
        // - resolvedThisRound
        // - spawnerFinishedThisRound (set by OnSpawnerFinishedThisRound)

        if (!spawnerFinishedThisRound) return;

        if (spawnedThisRound <= 0) return;

        if (resolvedThisRound < spawnedThisRound) return;

        Debug.Log($"ROUND COMPLETE detected. Spawned={spawnedThisRound}, Resolved={resolvedThisRound}");

        // Prevent double-firing
        spawnerFinishedThisRound = false;

        StartCoroutine(RoundCompleteSequence());
    }

    private void SetShakeIconLit(bool lit)
    {
        if (shakeIcon == null) return;

        Color c = shakeIcon.color;
        c.a = lit ? shakeIconLitAlpha : shakeIconDimAlpha;
        shakeIcon.color = c;
    }

    private void UpdateShakeAvailabilityForRound(int roundIndex)
    {
        // Prototype rule: available starting Round 3, one use per run
        shakeAvailable = (!shakeUsed) && (roundIndex >= shakeUnlockRoundIndex);
        SetShakeIconLit(shakeAvailable);
    }

    private void ResetShakeStateForNewRun()
    {
        shakeAvailable = false;
        shakeUsed = false;
        SetShakeIconLit(false);

        // Safety: never let the spawner stay paused across lives/new games
        if (boltSpawner != null)
            boltSpawner.SetPaused(false);
    }

    private void ApplyRoundDifficulty(int roundIndex)
    {
        if (rounds == null || rounds.Count == 0) return;

        int idx = Mathf.Clamp(roundIndex - 1, 0, rounds.Count - 1);
        RoundSettings rs = rounds[idx];

        // Spawner settings (source of truth)
        if (boltSpawner != null)
        {
            boltSpawner.boltsPerRound = rs.boltsPerRound;
            boltSpawner.minSpawnDelay = rs.minSpawnDelay;
            boltSpawner.maxSpawnDelay = rs.maxSpawnDelay;
        }

        // Zeus settings (source of truth)
        if (zeusMover != null)
        {
            zeusMover.moveSpeed = rs.zeusMoveSpeed;

            // Safety: keep min <= max so Random.Range behaves predictably
            zeusMover.minChangeTime = Mathf.Min(rs.zeusMinChangeTime, rs.zeusMaxChangeTime);
            zeusMover.maxChangeTime = Mathf.Max(rs.zeusMinChangeTime, rs.zeusMaxChangeTime);
        }
        // Update shake icon availability (prototype rule: unlock at Round 3)
        UpdateShakeAvailabilityForRound(roundIndex);
    }

    public void Debug_OnShakeTheHeavensTriggered()
    {
        // Hard blocks
        if (isGameOver) return;
        if (inLossSequence) return;

        // Only allow if the icon logic says it's available
        if (!shakeAvailable) return;
        if (shakeUsed) return;

        // Consume it for this run
        shakeUsed = true;
        shakeAvailable = false;
        SetShakeIconLit(false);

        // Run effect
        if (sthRoutine != null) StopCoroutine(sthRoutine);
        sthRoutine = StartCoroutine(ShakeTheHeavensRoutine());
    }

    private IEnumerator ShakeTheHeavensRoutine()
    {
        // 1) Pause spawner + freeze Zeus movement
        if (boltSpawner != null) boltSpawner.SetPaused(true);
        if (zeusMover != null) zeusMover.enabled = false;

        // 2) Clear all active bolts (they "count" as resolved the same way your loss-pop does)
        List<Bolt> snapshot = activeBolts
            .Where(b => b != null)
            .ToList();

        for (int i = 0; i < snapshot.Count; i++)
        {
            Bolt b = snapshot[i];
            if (b == null) continue;
            b.Explode();
        }

        // Clean list after explosions
        activeBolts.RemoveAll(b => b == null);

        // 3) Stun duration
        yield return new WaitForSecondsRealtime(sthStunDuration);

        // 4) Resume if we�re still in normal play
        if (!isGameOver && !inLossSequence)
        {
            if (boltSpawner != null) boltSpawner.SetPaused(false);

            // Only re-enable Zeus if we�re not in a "grab-to-start" gate
            if (zeusMover != null && gameplayStarted && !waitingForFirstGrab)
                zeusMover.enabled = true;
        }

        sthRoutine = null;
    }


}