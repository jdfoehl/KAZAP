using UnityEngine;
using UnityEngine.UI;

public class ShakeTheHeavensInput : MonoBehaviour
{
    [Header("Shake Icon (Readiness Gate)")]
    [Tooltip("Assign your top-right shake icon Image here.")]
    public Image shakeIconImage;

    [Tooltip("Icon alpha at/above this value is considered READY (lit).")]
    [Range(0f, 1f)]
    public float readyAlphaThreshold = 0.95f;

    [Header("Real Device Shake Detection")]
    [Tooltip("0.10�0.30 is a good range. Higher = snappier, lower = smoother.")]
    [Range(0.01f, 1f)]
    public float smoothing = 0.15f;

    [Tooltip("Higher = harder to trigger. Start around 1.2�1.6.")]
    public float shakeThreshold = 1.35f;

    [Tooltip("Seconds between triggers.")]
    public float shakeCooldown = 0.75f;

    [Header("Editor / Emulator Trigger")]
    public bool enableEditorKey = true;
    public KeyCode editorKey = KeyCode.Space;

    [Header("Debug")]
    public bool logWhenBlocked = false;

    [Header("RoundManager Hook")]
    public RoundManager roundManager;

    [Header("Icon Visuals")]
    [Range(0f, 1f)] public float dimAlpha = 0.25f;   // matches your current grey
    [Range(0f, 1f)] public float brightAlpha = 1.0f; // lit

    private Vector3 smoothedAccel;
    private float lastShakeTime = -999f;

    // Track icon active state so we can detect "new game" re-enable
    private bool prevIconActive;

    // Prototype: one use per run (we�ll reset this later when we wire full behavior)
    private bool usedThisRun = false;

    private void Update()
    {
        // Detect icon being re-enabled (new game / new playthrough) and auto-rearm
        bool iconActive = (shakeIconImage != null && shakeIconImage.gameObject.activeInHierarchy);

        if (iconActive && !prevIconActive)
        {
            // Icon just appeared again -> treat as a fresh run
            Debug_ResetForNewRun();
        }

        prevIconActive = iconActive;

        // If we already used it this run, FORCE the icon to stay dim (even if something else relights it)
        if (usedThisRun)
        {
            if (shakeIconImage != null && shakeIconImage.gameObject.activeInHierarchy)
            {
                Color c = shakeIconImage.color;

                // If anything set it bright again, stomp it back to dim
                if (c.a > dimAlpha + 0.001f)
                {
                    c.a = dimAlpha;
                    shakeIconImage.color = c;
                }
            }

            // Still block triggering after use
            return;
        }

        // If not ready, block
        if (!IsIconReady())
        {
            if (logWhenBlocked && (Application.isEditor && enableEditorKey && Input.GetKeyDown(editorKey)))
                Debug.Log("STH blocked: icon not ready/lit.");
            return;
        }

        // NEW: Block STH during life-loss sequence / game over so we don't consume it visually
        if (roundManager != null && (roundManager.IsInLossSequence || roundManager.IsGameOver))
        {
            if (logWhenBlocked && (Application.isEditor && enableEditorKey && Input.GetKeyDown(editorKey)))
                Debug.Log("STH blocked: loss sequence / game over.");
            return;
        }

        // Editor/emulator: Space key
        if (Application.isEditor && enableEditorKey)
        {
            if (Input.GetKeyDown(editorKey))
            {
                TriggerSTH("EditorKey", 0f);
                return;
            }
        }

        // Device: accelerometer shake
        Vector3 rawAccel = Input.acceleration;
        smoothedAccel = Vector3.Lerp(smoothedAccel, rawAccel, smoothing);

        float shakeSignal = (rawAccel - smoothedAccel).magnitude;

        if (shakeSignal > shakeThreshold && Time.time - lastShakeTime >= shakeCooldown)
        {
            lastShakeTime = Time.time;
            TriggerSTH("Accelerometer", shakeSignal);
        }
    }

    private bool IsIconReady()
    {
        if (shakeIconImage == null) return false;
        if (!shakeIconImage.gameObject.activeInHierarchy) return false;

        // Your current setup: dim = alpha ~0.25, ready = alpha ~1.0
        return shakeIconImage.color.a >= readyAlphaThreshold;
    }

    private void TriggerSTH(string source, float signal)
    {
        usedThisRun = true; // consume once per run (prototype)

        // Dim icon immediately
        if (shakeIconImage != null)
        {
            Color c = shakeIconImage.color;
            c.a = dimAlpha;
            shakeIconImage.color = c;
        }

        Debug.Log($"STH TRIGGERED! source={source}  signal={signal:F2}");

        // Notify RoundManager (we�ll implement the real effect next step)
        if (roundManager != null)
            roundManager.Debug_OnShakeTheHeavensTriggered();
    }

    // We�ll call this later when Round 3 begins (or when a new game starts) to re-arm it.
    public void Debug_ResetForNewRun()
    {
        usedThisRun = false;
        lastShakeTime = -999f;
        smoothedAccel = Vector3.zero;

        // Reset icon to dim on a new run (Round 3 will brighten it later)
        if (shakeIconImage != null)
        {
            Color c = shakeIconImage.color;
            c.a = dimAlpha;
            shakeIconImage.color = c;
        }
    }
}
