using System.Collections;
using UnityEngine;

public class BoltSpawner : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private RoundManager roundManager;
    [SerializeField] private GameObject boltPrefab;
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private Transform spawnParent;

    [Header("Round Settings")]
    public int boltsPerRound = 10;

    public float minSpawnDelay = 0.25f;
    public float maxSpawnDelay = 0.7f;

    public float boltFallSpeed = 8f;

    [Header("State")]
    [SerializeField] private bool isPaused = false;

    private Coroutine spawnRoutine;
    private bool isRunning = false;
    private int spawnedThisRound = 0;

    public void SetBoltPrefab(GameObject newPrefab)
    {
        if (newPrefab == null) return;
        boltPrefab = newPrefab;
    }

    public void StartRound()
    {
        StopRound();

        isRunning = true;
        isPaused = false;
        spawnedThisRound = 0;

        spawnRoutine = StartCoroutine(SpawnRoutine());
    }

    public void StopRound()
    {
        isRunning = false;

        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
    }

    public void SetPaused(bool paused)
    {
        isPaused = paused;
    }

    private IEnumerator SpawnRoutine()
    {
        yield return null;

        int targetCount = Mathf.Max(0, boltsPerRound);

        while (isRunning && spawnedThisRound < targetCount)
        {
            while (isPaused)
                yield return null;

            SpawnOneBolt();
            spawnedThisRound++;

            float delay = Random.Range(minSpawnDelay, maxSpawnDelay);
            float t = 0f;

            while (t < delay)
            {
                if (!isRunning) yield break;
                if (!isPaused) t += Time.deltaTime;
                yield return null;
            }
        }

        isRunning = false;
        spawnRoutine = null;

        if (roundManager != null)
            roundManager.OnSpawnerFinishedThisRound();
    }

    private void SpawnOneBolt()
    {
        if (boltPrefab == null || spawnPoint == null)
        {
            Debug.LogWarning("[BoltSpawner] Missing boltPrefab or spawnPoint.");
            return;
        }

        Transform parent = spawnParent != null ? spawnParent : null;

        GameObject go = Instantiate(boltPrefab, spawnPoint.position, Quaternion.identity, parent);

        Bolt bolt = go.GetComponent<Bolt>();
        if (bolt != null)
        {
            bolt.fallSpeed = boltFallSpeed;

            if (roundManager != null)
                roundManager.RegisterBolt(bolt);
        }
    }
}