using UnityEngine;

public class ShieldDragController : MonoBehaviour
{
    [Header("What moves")]
    [Tooltip("The Transform that should actually move. If null, uses this transform.")]
    public Transform moveTarget;

    [Header("Where you�re allowed to start dragging")]
    [Tooltip("Touch must begin on one of these colliders (typically your 3 shield colliders).")]
    public Collider2D[] grabColliders;

    [Header("Drag Behavior")]
    public bool requireGrabOnShield = true;
    public bool lockY = true;
    public float smooth = 20f;

    // NEW: allow starting a grab if the finger/mouse is already held down
    // (fixes �GO! but can�t grab for a few seconds� feeling)
    public bool allowLateGrabWhileHeld = true;

    [Header("Pause Lock")]
    public bool inputLocked = false;

    [Header("Bounds")]
    public bool useCameraBounds = true;
    public float cameraPadding = 0.35f;
    public float minX = -2.5f;
    public float maxX = 2.5f;

    private Camera cam;
    private bool dragging;
    private int activeFingerId = -1;
    private float lockedY;



    // NEW: lets you lower/raise the band without changing art/transforms
    public float lockedYOffset = 0f;

    // NEW: prevents �snap back� if you adjust Y during play/testing
    public bool recaptureLockedYOnBeginDrag = true;

    // Signals (RoundManager will listen to these)
    public event System.Action GrabStarted;
    public event System.Action GrabEnded;

    [Header("Debug")]
    public bool debugGrabSignals = false;

    private void BeginDrag(int fingerId)
    {
        if (lockY && recaptureLockedYOnBeginDrag)
            lockedY = moveTarget.position.y;

        dragging = true;
        activeFingerId = fingerId;

        if (debugGrabSignals) Debug.Log("ShieldDragController: GrabStarted");
        GrabStarted?.Invoke();
    }

    private void EndDrag()
    {
        dragging = false;
        activeFingerId = -1;

        if (debugGrabSignals) Debug.Log("ShieldDragController: GrabEnded");
        GrabEnded?.Invoke();
    }

    public void ForceCancelDrag()
    {
        if (!dragging) return;

        // End the drag WITHOUT moving the target.
        dragging = false;
        activeFingerId = -1;

        if (debugGrabSignals) Debug.Log("ShieldDragController: ForceCancelDrag");
        GrabEnded?.Invoke();
    }

    private void Awake()
    {
        cam = Camera.main;
        if (moveTarget == null) moveTarget = transform;
        lockedY = moveTarget.position.y;

        // If grabColliders not assigned, fall back to a collider on this object (if any).
        if (grabColliders == null || grabColliders.Length == 0)
        {
            Collider2D c = GetComponent<Collider2D>();
            if (c != null) grabColliders = new Collider2D[] { c };
        }
    }

    private void Update()
    {
        if (inputLocked)
        {
            // Safety: if we ever get paused mid-drag, guarantee we exit cleanly.
            ForceCancelDrag();
            return;
        }

        HandleMouse();
        HandleTouch();
    }

    private void HandleMouse()
    {
        // Start on click-down (normal)
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 wp = cam.ScreenToWorldPoint(Input.mousePosition);
            if (CanStartDrag(wp))
            {
                BeginDrag(-999); // sentinel for mouse
            }
        }

        // NEW: If input becomes enabled while mouse is already held,
        // allow grab to begin immediately (no need to release/reclick)
        if (!dragging && allowLateGrabWhileHeld && Input.GetMouseButton(0))
        {
            Vector2 wp = cam.ScreenToWorldPoint(Input.mousePosition);
            if (CanStartDrag(wp))
            {
                BeginDrag(-999);
            }
        }

        if (dragging && activeFingerId == -999)
        {
            if (Input.GetMouseButton(0))
            {
                Vector2 wp = cam.ScreenToWorldPoint(Input.mousePosition);
                MoveTowardsX(wp.x);
            }
            else
            {
                EndDrag();
            }
        }
    }

    private void HandleTouch()
    {
        if (Input.touchCount <= 0) return;

        // Begin
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch t = Input.GetTouch(i);

            if (!dragging && (t.phase == TouchPhase.Began ||
                   (allowLateGrabWhileHeld && (t.phase == TouchPhase.Stationary || t.phase == TouchPhase.Moved))))
            {
                Vector2 wp = cam.ScreenToWorldPoint(t.position);
                if (CanStartDrag(wp))
                {
                    BeginDrag(t.fingerId);
                    break;
                }
            }
        }

        // Continue / End
        if (!dragging) return;

        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch t = Input.GetTouch(i);
            if (t.fingerId != activeFingerId) continue;

            if (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary)
            {
                Vector2 wp = cam.ScreenToWorldPoint(t.position);
                MoveTowardsX(wp.x);
            }
            else if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
            {
                EndDrag();
            }

            break;
        }
    }

    private bool CanStartDrag(Vector2 worldPos)
    {
        if (!requireGrabOnShield) return true;

        if (grabColliders == null) return false;

        for (int i = 0; i < grabColliders.Length; i++)
        {
            if (grabColliders[i] != null && grabColliders[i].OverlapPoint(worldPos))
                return true;
        }

        return false;
    }

    private void MoveTowardsX(float targetX)
    {
        float clampedX = ClampX(targetX);

        Vector3 p = moveTarget.position;
        if (lockY) p.y = lockedY + lockedYOffset;

        // Smooth
        p.x = Mathf.Lerp(p.x, clampedX, smooth * Time.deltaTime);

        moveTarget.position = p;
    }

    private float ClampX(float desiredX)
    {
        if (!useCameraBounds || cam == null) return Mathf.Clamp(desiredX, minX, maxX);

        float halfHeight = cam.orthographicSize;
        float halfWidth = halfHeight * cam.aspect;

        float left = cam.transform.position.x - halfWidth + cameraPadding;
        float right = cam.transform.position.x + halfWidth - cameraPadding;

        return Mathf.Clamp(desiredX, left, right);
    }

  
}