using UnityEngine;

[RequireComponent(typeof(RectTransform))]
public class SafeAreaFitter : MonoBehaviour
{
    private RectTransform rect;
    private Rect lastSafeArea;
    private ScreenOrientation lastOrientation;

    private void Awake()
    {
        rect = GetComponent<RectTransform>();
        ApplySafeArea();
    }

    private void Update()
    {
        // Re-apply if something changes (rotation, resolution, safe area)
        if (Screen.safeArea != lastSafeArea || Screen.orientation != lastOrientation)
            ApplySafeArea();
    }

    private void ApplySafeArea()
    {
        Rect safe = Screen.safeArea;

        lastSafeArea = safe;
        lastOrientation = Screen.orientation;

        Vector2 anchorMin = safe.position;
        Vector2 anchorMax = safe.position + safe.size;

        anchorMin.x /= Screen.width;
        anchorMin.y /= Screen.height;
        anchorMax.x /= Screen.width;
        anchorMax.y /= Screen.height;

        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }
}