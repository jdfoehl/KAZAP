﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class TitleStartSequence : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private RectTransform titlePanelRect;     // TitlePanel
    [SerializeField] private ZeusTitleUI zeusTitleUI;          // ZeusTitleUI component (on ZeusTitle_UI)
    [SerializeField] private RectTransform boltPrefab;         // UI bolt prefab (RectTransform)
    [SerializeField] private Image startButtonImage;           // StartButton background Image
    [SerializeField] private Button startButton;               // optional: disable during sequence
    [SerializeField] private Button optionsButton;             // optional: disable during sequence
    [SerializeField] private RoundManager roundManager;        // Managers/RoundManager
    [SerializeField] private TitleAudioController titleAudio;

    [Header("Title Music Behavior")]
    [Tooltip("When the title screen becomes active again, restart title music (fixes silence after returning from gameplay).")]
    [SerializeField] private bool restartTitleMusicOnEnable = true;

    [Header("Bolt Travel")]
    [SerializeField] private float boltTravelTimeSeconds = 0.35f; // seconds to reach Start
    [SerializeField] private float hitDistancePx = 8f;

    [Header("Zeus Start Pose")]
    [SerializeField] private float zeusSnapHoldArmUpSeconds = 0.15f; // how long Zeus holds ARM UP after snap
    [SerializeField] private bool snapToBandCenter = true;           // if false, snaps to 0

    [Header("Start Button Flash")]
    [SerializeField] private float flickerDuration = 0.35f;
    [SerializeField] private float flickerHz = 12f;
    [SerializeField] private float holdYellowDuration = 0.25f;

    [Header("Colors")]
    [SerializeField] private Color flickerColorA = Color.white;
    [SerializeField] private Color flickerColorB = new Color(1f, 0.92f, 0.2f, 1f);
    [SerializeField] private Color holdColor = new Color(1f, 0.92f, 0.2f, 1f);

    private bool isRunning = false;
    private Color startButtonOriginalColor;

    private void Awake()
    {
        if (startButtonImage != null)
            startButtonOriginalColor = startButtonImage.color;
    }

    private void OnEnable()
    {
        // Whenever the title screen comes back (ex: after Game Over),
        // reset button state so the player can start again.
        isRunning = false;

        if (startButton != null) startButton.interactable = true;
        if (optionsButton != null) optionsButton.interactable = true;

        if (startButtonImage != null) startButtonImage.color = startButtonOriginalColor;

        // ✅ CRITICAL FIX: restart title music when returning to title
        if (restartTitleMusicOnEnable && titleAudio != null)
        {
            // This assumes you added HardRestartTitleMusic() to TitleAudioController.
            titleAudio.HardRestartTitleMusic();
        }
    }

    public void PlayStartSequence()
    {
        if (isRunning) return;
        StartCoroutine(StartSequenceRoutine());
    }

    private IEnumerator StartSequenceRoutine()
    {
        isRunning = true;

        if (startButton != null) startButton.interactable = false;
        if (optionsButton != null) optionsButton.interactable = false;

        if (titleAudio != null)
            titleAudio.FadeOutTitleMusic();

        // Safety checks
        if (titlePanelRect == null) titlePanelRect = GetComponentInParent<RectTransform>();
        if (boltPrefab == null || zeusTitleUI == null || startButtonImage == null || roundManager == null)
        {
            Debug.LogError("[TitleStartSequence] Missing references. Cannot run start sequence.");
            CleanupFail();
            yield break;
        }

        if (zeusTitleUI.zeusRect == null)
        {
            Debug.LogError("[TitleStartSequence] ZeusTitleUI.zeusRect is null. Assign it (usually ZeusTitle_UI RectTransform).");
            CleanupFail();
            yield break;
        }

        // ---- 1) Freeze Zeus + snap ONLY X (anchored pixels), keep Y band ----
        zeusTitleUI.StopPatrol();

        float centerX = 0f;

        if (snapToBandCenter)
        {
            centerX = (zeusTitleUI.minX + zeusTitleUI.maxX) * 0.5f;
        }

        zeusTitleUI.SnapToCenterX(centerX);

        // ---- 2) Hold ARM UP pose (optional 2-frame throw) ----
        if (zeusSnapHoldArmUpSeconds > 0f)
        {
            yield return StartCoroutine(zeusTitleUI.PlayThrowTwoFrame(zeusSnapHoldArmUpSeconds));
        }

        // ---- 3) Spawn bolt under TitlePanel ----
        RectTransform bolt = Instantiate(boltPrefab, titlePanelRect);
        bolt.gameObject.SetActive(true);

        if (titleAudio != null)
            titleAudio.PlayZap();

        Vector2 startPos = WorldToLocalPointIn(titlePanelRect, zeusTitleUI.zeusRect.position);
        Vector2 endPos = WorldToLocalPointIn(titlePanelRect, startButtonImage.rectTransform.position);

        bolt.anchoredPosition = startPos;

        // ---- 4) Travel (arrive in boltTravelTimeSeconds) ----
        float travelTime = Mathf.Max(0.01f, boltTravelTimeSeconds);
        float t = 0f;

        while (Vector2.Distance(bolt.anchoredPosition, endPos) > hitDistancePx)
        {
            t += Time.unscaledDeltaTime;
            float alpha = Mathf.Clamp01(t / travelTime);
            float eased = alpha * alpha * (3f - 2f * alpha);

            bolt.anchoredPosition = Vector2.Lerp(startPos, endPos, eased);

            if (alpha >= 1f) break;
            yield return null;
        }

        bolt.anchoredPosition = endPos;
        Destroy(bolt.gameObject);

        if (titleAudio != null)
            titleAudio.PlayCrackleOnce();

        // ---- 5) Flicker then hold ----
        yield return StartCoroutine(FlickerStartButton());
        startButtonImage.color = holdColor;
        yield return new WaitForSecondsRealtime(holdYellowDuration);

        startButtonImage.color = startButtonOriginalColor;

        // ---- 6) Transition to gameplay ----
        roundManager.OnPressStart();

        isRunning = false;
    }

    private void CleanupFail()
    {
        isRunning = false;
        if (startButton != null) startButton.interactable = true;
        if (optionsButton != null) optionsButton.interactable = true;
    }

    private IEnumerator FlickerStartButton()
    {
        if (flickerDuration <= 0f) yield break;

        float elapsed = 0f;
        float halfPeriod = (flickerHz <= 0f) ? 0.05f : (0.5f / flickerHz);
        float toggleTimer = 0f;
        bool toggle = false;

        while (elapsed < flickerDuration)
        {
            float dt = Time.unscaledDeltaTime;
            elapsed += dt;
            toggleTimer += dt;

            if (toggleTimer >= halfPeriod)
            {
                toggleTimer = 0f;
                toggle = !toggle;
                startButtonImage.color = toggle ? flickerColorA : flickerColorB;
            }

            yield return null;
        }
    }

    private static Vector2 WorldToLocalPointIn(RectTransform parent, Vector3 worldPos)
    {
        Vector3 local = parent.InverseTransformPoint(worldPos);
        return new Vector2(local.x, local.y);
    }
}