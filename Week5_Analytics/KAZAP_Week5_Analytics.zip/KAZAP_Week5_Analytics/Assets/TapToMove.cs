using UnityEngine;

public class TapToMove : MonoBehaviour
{
    public float moveSpeed = 5f;

    private Vector3 targetPosition;
    private Camera mainCamera;

    void Start()
    {
        mainCamera = Camera.main;
        targetPosition = transform.position;
    }

    void Update()
    {
        // Handle touch input
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                // Convert touch position to world position
                Vector3 touchWorldPos = mainCamera.ScreenToWorldPoint(touch.position);
                touchWorldPos.z = 0; // Keep at same depth (2D game)

                targetPosition = touchWorldPos;
            }
        }

        // For testing in Unity Editor (mouse input)
        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(Input.mousePosition);
            mouseWorldPos.z = 0;
            targetPosition = mouseWorldPos;
        }

        // Move toward target position
        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            moveSpeed * Time.deltaTime
        );
    }
}