using System.Collections.Generic;
using UnityEngine;

public class BoltPool : MonoBehaviour
{
    [Header("Pool Setup")]
    [SerializeField] private GameObject prefab;
    [SerializeField] private Transform poolParent;
    [SerializeField] private int prewarmCount = 20;

    private readonly Queue<GameObject> pool = new Queue<GameObject>();

    public void Configure(GameObject prefabToUse, Transform parentForPooled, int prewarm)
    {
        prefab = prefabToUse;
        poolParent = parentForPooled;
        prewarmCount = Mathf.Max(0, prewarm);
        Prewarm(prewarmCount);
    }

    private void Awake()
    {
        if (poolParent == null) poolParent = transform;
    }

    private void Prewarm(int count)
    {
        if (prefab == null) return;

        for (int i = 0; i < count; i++)
        {
            GameObject go = Instantiate(prefab, Vector3.zero, Quaternion.identity, poolParent);
            go.SetActive(false);
            pool.Enqueue(go);
        }
    }

    public GameObject Get(Vector3 position, Quaternion rotation, Transform activeParent)
    {
        if (prefab == null)
        {
            Debug.LogWarning("[BoltPool] No prefab assigned.");
            return null;
        }

        GameObject go = pool.Count > 0 ? pool.Dequeue() : Instantiate(prefab, Vector3.zero, Quaternion.identity, poolParent);

        Transform t = go.transform;
        if (activeParent != null) t.SetParent(activeParent, worldPositionStays: false);

        t.position = position;
        t.rotation = rotation;

        go.SetActive(true);
        return go;
    }

    public void Return(GameObject go)
    {
        if (go == null) return;

        go.SetActive(false);

        Transform t = go.transform;
        if (poolParent != null) t.SetParent(poolParent, worldPositionStays: false);

        pool.Enqueue(go);
    }

    public void ClearAllActiveChildren(Transform activeParent)
    {
        if (activeParent == null) return;

        // Return all children under activeParent back to pool
        for (int i = activeParent.childCount - 1; i >= 0; i--)
        {
            Transform child = activeParent.GetChild(i);
            Return(child.gameObject);
        }
    }
}