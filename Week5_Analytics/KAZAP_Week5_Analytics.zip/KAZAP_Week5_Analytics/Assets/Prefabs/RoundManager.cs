using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class DeityProfile
{
    [Header("Identity")]
    public string deityName = "Zeus";
    public int roundsCount = 5;

    [Header("Spine (per-deity)")]
    [Tooltip("0.10 -> 1.0, 1.1, 1.2... within THIS deity.")]
    [Range(0f, 1f)] public float spineIncrementPerRound = 0.10f;

    [Header("First Appearance Intro (plays only on this deity's Round 1)")]
    public bool playIntroOnFirstRound = true;

    [TextArea(2, 3)]
    [Tooltip("If blank, RoundManager.tauntText will be used as a fallback.")]
    public string introText = "";

    public float introHoldTime = 1.0f;

    [Tooltip("How far above the final position the deity starts before floating down.")]
    public float introFloatYOffset = 2.0f;

    [Tooltip("How long the float-down takes.")]
    public float introFloatDuration = 0.6f;

    [Header("Round UI")]
    public bool showRoundLabel = true;
    public float roundLabelHoldTime = 1.0f;

    [TextArea(2, 3)]
    public string clearTauntText = "";
    public float clearTauntHoldTime = 1.0f;

    [Header("Cosmetics")]
    public Sprite deitySprite = null;

    [Tooltip("Tint applied to your BG_Gradient (Image or SpriteRenderer).")]
    public Color bgGradientTint = Color.white;

    [Tooltip("Projectile prefab for this deity (bolt, broken heart, etc).")]
    public GameObject projectilePrefab = null;

    [Header("Gameplay (Constant per Deity)")]
    [Tooltip("Constant for all rounds in this deity (NOT spine-scaled).")]
    public int boltsPerRound = 20;

    [Header("Optional Per-Knob Weights (1 = pure spine)")]
    [Tooltip("Spawn delays scale DOWN by spine^weight (harder).")]
    [Range(0.0f, 3.0f)] public float spawnDelayWeight = 1.0f;

    [Tooltip("Bolt fall speed scales UP by spine^weight.")]
    [Range(0.0f, 3.0f)] public float boltFallSpeedWeight = 1.0f;

    [Tooltip("Zeus move speed scales UP by spine^weight.")]
    [Range(0.0f, 3.0f)] public float zeusMoveSpeedWeight = 1.0f;

    [Tooltip("Direction-change times scale DOWN by spine^weight (harder/more chaotic).")]
    [Range(0.0f, 3.0f)] public float zeusChangeTimeWeight = 1.0f;

    [Header("Baseline Resets (inherit previous deity by default)")]
    public bool overrideBaselineMinSpawnDelay = false;
    public float baselineMinSpawnDelay = 0.25f;

    public bool overrideBaselineMaxSpawnDelay = false;
    public float baselineMaxSpawnDelay = 0.60f;

    public bool overrideBaselineBoltFallSpeed = false;
    public float baselineBoltFallSpeed = 8f;

    public bool overrideBaselineZeusMoveSpeed = false;
    public float baselineZeusMoveSpeed = 2.0f;

    public bool overrideBaselineZeusMinChangeTime = false;
    public float baselineZeusMinChangeTime = 0.40f;

    public bool overrideBaselineZeusMaxChangeTime = false;
    public float baselineZeusMaxChangeTime = 1.20f;
}

public class RoundManager : MonoBehaviour
{
    [Header("Music (Title + Gameplay)")]
    [Tooltip("Title screen music loop source (AudioHub's music AudioSource).")]
    public AudioSource titleMusicSource;

    [Tooltip("Gameplay music loop source (GamePlayMusic object's AudioSource).")]
    public AudioSource gameplayMusicSource;

    [Tooltip("If true, stop title music when gameplay starts.")]
    public bool stopTitleMusicOnGameplayStart = true;

    [Tooltip("If true, resume title music when returning to title.")]
    public bool resumeTitleMusicOnReturnToTitle = true;

    [Header("Refs")]
    public BoltSpawner boltSpawner;
    public ZeusMover zeusMover;
    public ShieldDragController shieldDrag;

    [Header("SFX (Shared + Failure/Pop)")]
    [Tooltip("Assign the AudioSource on your tagged SFX object (ex: Spawning). Used for projectile spawn SFX and fail/pop SFX.")]
    public AudioSource sharedSfxSource;

    [Tooltip("One clip used for 'bolt hit ground' + pop sequence SFX.")]
    public AudioClip failPopSfx;

    [Range(0f, 1f)] public float failPopVolume = 1f;

    [Header("Deity Visual Swap")]
    [SerializeField] private Transform deityVisualRoot;          // assign Zeus_Frames_1 transform OR leave null to auto-find
    [SerializeField] private string deityVisualChildName = "Zeus_Frames_1";
    [SerializeField] private SpriteRenderer deityVisualRenderer; // auto-cached if null

    [Header("Gameplay Roots (enable/disable)")]
    public GameObject groundRoot;
    public GameObject spawningRoot;
    public GameObject worldRoot;

    [Header("UI")]
    public GameObject titlePanel;
    public GameObject hudPanel;
    public TMPro.TextMeshProUGUI centerText;

    [Header("Deity UI / Cosmetics Targets (optional)")]
    [Tooltip("If assigned, this Image's sprite will be set to the current deitySprite.")]
    public Image deitySpriteImage;

    [Tooltip("If assigned, this SpriteRenderer's sprite will be set to the current deitySprite.")]
    public SpriteRenderer deitySpriteRenderer;

    [Tooltip("If assigned, tint will be applied here.")]
    public Image bgGradientImage;

    [Tooltip("If assigned, tint will be applied here.")]
    public SpriteRenderer bgGradientSpriteRenderer;

    [Header("Shake the Heavens UI")]
    public Image shakeIcon;
    [Range(0f, 1f)] public float shakeIconDimAlpha = 0.25f;
    [Range(0f, 1f)] public float shakeIconLitAlpha = 1.0f;

    [Tooltip("Prototype: Shake becomes available automatically starting at this OVERALL round index.")]
    public int shakeUnlockOverallRoundIndex = 3;

    // Runtime shake state
    private bool shakeAvailable;
    private bool shakeUsed;
    private Coroutine sthRoutine;

    [Header("Start Gate Prompt")]
    public GameObject tapHoldPrompt;
    public GameObject shieldAuraRoot;

    [Header("Intro Text (fallback if a deity introText is blank)")]
    [TextArea(2, 3)]
    public string tauntText = "You cannot block the heavens!";

    [Header("Intro Timing (global countdown/go)")]
    public float countdownStepTime = 0.75f;
    public float goHoldTime = 0.5f;

    [Header("Intro Labels")]
    public string countdown3 = "3";
    public string countdown2 = "2";
    public string countdown1 = "1";
    public string goText = "GO!";

    [Header("Game Over UI")]
    [TextArea(2, 3)]
    public string gameOverTauntText = "Pathetic.";
    public float gameOverTauntHoldTime = 1.0f;

    public string gameOverText = "GAME OVER";
    public float gameOverHoldTime = 1.5f;

    [TextArea(2, 3)]
    public string finalWinText = "YOU WIN!";
    public float finalWinHoldTime = 1.5f;

    [Header("Safety Floors (Divide-Down Targets)")]
    public float minAllowedDelay = 0.05f;
    public float minAllowedChangeTime = 0.05f;

    [Header("Deity Profiles (set count to control total rounds)")]
    public List<DeityProfile> deityProfiles = new List<DeityProfile>();

    [Header("Initial Baselines (used ONLY for Deity #1 start if no inheritance yet)")]
    public float initialMinSpawnDelay = 0.25f;
    public float initialMaxSpawnDelay = 0.60f;
    public float initialBoltFallSpeed = 8f;
    public float initialZeusMoveSpeed = 2.0f;
    public float initialZeusMinChangeTime = 0.40f;
    public float initialZeusMaxChangeTime = 1.20f;

    [Header("Reset")]
    public Transform zeusRoot;
    public Transform shieldStackRoot;
    public float resetDelay = 1.0f;

    [Header("Kaboom Pop Timing")]
    public float firstBoomHold = 0.10f;
    public float popInterval = 0.07f;

    [Header("Shake the Heavens (STH)")]
    public float sthStunDuration = 1.25f;
    public bool sthPausesSpawner = true;

    [Header("Shield Aura (tint)")]
    public Color auraOffColor = Color.white;
    public Color auraOnColor = new Color(1f, 0.92f, 0.35f, 1f);

    [Header("Shields / Lives")]
    public List<GameObject> shieldsBottomToTop = new();
    public bool autoCacheShieldsFromStack = true;

    [Header("Game Over")]
    public bool autoRestartAfterGameOver = false;
    public float gameOverRestartDelay = 1.5f;

    // ---------- Runtime state ----------
    private readonly List<SpriteRenderer> shieldRenderersBottomToTop = new();
    private readonly List<Bolt> activeBolts = new();

    private bool inLossSequence;
    private bool isGameOver;

    public bool IsInLossSequence => inLossSequence;
    public bool IsGameOver => isGameOver;

    private bool waitingForFirstGrab;
    private bool gameplayStarted;

    // --- Analytics runtime ---
    private float runStartRealtime;
    private float roundStartRealtime;
    private int shieldsLostThisRound;

    // round tracking
    private int spawnedThisRound;
    private int resolvedThisRound;
    private bool spawnerFinishedThisRound;
    private int nextSpawnId = 1;

    // deity/round indices
    private int currentDeityIndex = 0;          // 0-based
    private int currentRoundWithinDeity = 1;    // 1-based
    private int currentOverallRoundIndex = 1;   // 1-based (across all deities)

    // inherited baselines at start of current deity
    private float inheritedMinSpawnDelay;
    private float inheritedMaxSpawnDelay;
    private float inheritedBoltFallSpeed;
    private float inheritedZeusMoveSpeed;
    private float inheritedZeusMinChangeTime;
    private float inheritedZeusMaxChangeTime;

    private void Awake()
    {
        CacheShieldsIfNeeded();

        // Ensure gameplay music never leaks into title on scene load.
        StopGameplayMusic();
    }

    // -------------------- Shields --------------------
    private void CacheShieldsIfNeeded()
    {
        if (!autoCacheShieldsFromStack) return;
        if (shieldsBottomToTop != null && shieldsBottomToTop.Count > 0) return;
        if (shieldStackRoot == null) return;

        shieldsBottomToTop = shieldStackRoot
            .GetComponentsInChildren<Transform>(true)
            .Where(t => t != shieldStackRoot && t.CompareTag("Shield"))
            .OrderBy(t => t.position.y)
            .Select(t => t.gameObject)
            .ToList();
    }

    private void CacheShieldRenderersIfNeeded()
    {
        if (shieldRenderersBottomToTop.Count > 0) return;

        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null) return;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s == null) continue;

            SpriteRenderer sr = s.GetComponent<SpriteRenderer>();
            if (sr != null) shieldRenderersBottomToTop.Add(sr);
        }
    }

    private void SetAuraVisible(bool on)
    {
        CacheShieldRenderersIfNeeded();

        Color target = on ? auraOnColor : auraOffColor;

        for (int i = 0; i < shieldRenderersBottomToTop.Count; i++)
        {
            SpriteRenderer sr = shieldRenderersBottomToTop[i];
            if (sr == null) continue;
            if (sr.gameObject.activeInHierarchy) sr.color = target;
        }
    }

    private void SetPromptVisible(bool on)
    {
        if (tapHoldPrompt != null) tapHoldPrompt.SetActive(on);
    }

    // -------------------- Bolt tracking --------------------
    public void RegisterBolt(Bolt b)
    {
        if (b == null) return;

        if (!activeBolts.Contains(b))
        {
            activeBolts.Add(b);
            spawnedThisRound++;
        }

        // This is your shared SFX source used by Bolt spawn audio
        b.Init(this, nextSpawnId++, sharedSfxSource);
    }

    public void UnregisterBolt(Bolt b)
    {
        if (b == null) return;

        if (activeBolts.Remove(b))
        {
            resolvedThisRound++;
            TryHandleRoundComplete();
        }
    }

    public void OnSpawnerFinishedThisRound()
    {
        spawnerFinishedThisRound = true;
        TryHandleRoundComplete();
    }

    // -------------------- Start / Intro --------------------
    public void OnPressStart()
    {
        StartCoroutine(BeginGameRoutine());
    }

    private IEnumerator BeginGameRoutine()
    {
        Time.timeScale = 1f; // HARD RESET: ensure we never start a run paused

        if (titlePanel != null) titlePanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);

        if (stopTitleMusicOnGameplayStart) StopTitleMusic();
        StartGameplayMusic();

        ResetShakeStateForNewRun();

        // enable roots
        if (worldRoot != null) worldRoot.SetActive(true);
        if (groundRoot != null) groundRoot.SetActive(true);
        if (spawningRoot != null) spawningRoot.SetActive(true);
        if (AudioSettingsManager.Instance != null)
            AudioSettingsManager.Instance.ApplySaved();

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(true);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(true);

        // re-enable shields
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        // hard-freeze before intro
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetPromptVisible(false);
        SetAuraVisible(false);

        // reset indices
        currentDeityIndex = Mathf.Clamp(currentDeityIndex, 0, Mathf.Max(0, deityProfiles.Count - 1));
        currentRoundWithinDeity = 1;
        currentOverallRoundIndex = 1;

        // initialize inherited baselines for deity #1
        inheritedMinSpawnDelay = initialMinSpawnDelay;
        inheritedMaxSpawnDelay = initialMaxSpawnDelay;
        inheritedBoltFallSpeed = initialBoltFallSpeed;
        inheritedZeusMoveSpeed = initialZeusMoveSpeed;
        inheritedZeusMinChangeTime = initialZeusMinChangeTime;
        inheritedZeusMaxChangeTime = initialZeusMaxChangeTime;

        // apply deity cosmetics + difficulty for Round 1
        ApplyDeityCosmetics(GetCurrentDeity());
        ApplyDifficultyForCurrentRound();

        BeginRoundTracking();

        runStartRealtime = Time.realtimeSinceStartup;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("run_start", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index", currentOverallRoundIndex },
            { "starting_shields", GetActiveShieldCount() }
        }, flush: true);

        // per-deity first-appearance intro
        yield return StartCoroutine(PlayDeityFirstAppearanceIntroIfNeeded());

        // deity round label (optional)
        yield return StartCoroutine(ShowRoundLabelIfEnabled());

        // countdown
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        // gate start: first grab starts the round
        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = true;

        SetAuraVisible(false);
        SetPromptVisible(true);
    }

    private IEnumerator PlayDeityFirstAppearanceIntroIfNeeded()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) yield break;

        if (currentRoundWithinDeity != 1) yield break;
        if (!dp.playIntroOnFirstRound) yield break;

        // Float-in
        if (zeusRoot != null && dp.introFloatDuration > 0f)
        {
            Vector3 end = zeusRoot.position;
            Vector3 start = end;
            start.y += dp.introFloatYOffset;

            zeusRoot.position = start;

            float t = 0f;
            float dur = Mathf.Max(0.01f, dp.introFloatDuration);
            while (t < dur)
            {
                t += Time.unscaledDeltaTime;
                zeusRoot.position = Vector3.Lerp(start, end, t / dur);
                yield return null;
            }
            zeusRoot.position = end;
        }

        // Intro phrase
        string msg = string.IsNullOrEmpty(dp.introText) ? tauntText : dp.introText;
        if (!string.IsNullOrEmpty(msg))
        {
            ShowCenterText(msg);
            yield return new WaitForSecondsRealtime(Mathf.Max(0f, dp.introHoldTime));
            HideCenterText();
        }
    }

    private IEnumerator ShowRoundLabelIfEnabled()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) yield break;

        if (!dp.showRoundLabel) yield break;

        string msg = $"{dp.deityName} - Round {currentRoundWithinDeity}";
        ShowCenterText(msg);
        yield return new WaitForSecondsRealtime(dp.roundLabelHoldTime);
        HideCenterText();
    }

    private IEnumerator PlayCountdownOnlyRoutine()
    {
        ShowCenterText(countdown3);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown2);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(countdown1);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        ShowCenterText(goText);
        yield return new WaitForSecondsRealtime(goHoldTime);

        HideCenterText();
    }

    // -------------------- Round start gating --------------------
    private void SubscribeShieldDragSignals()
    {
        if (shieldDrag == null) return;

        shieldDrag.GrabStarted -= OnShieldGrabStarted;
        shieldDrag.GrabEnded -= OnShieldGrabEnded;

        shieldDrag.GrabStarted += OnShieldGrabStarted;
        shieldDrag.GrabEnded += OnShieldGrabEnded;
    }

    private void OnShieldGrabStarted()
    {
        SetAuraVisible(true);

        if (!waitingForFirstGrab || gameplayStarted || isGameOver) return;

        gameplayStarted = true;
        waitingForFirstGrab = false;

        SetPromptVisible(false);

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        roundStartRealtime = Time.realtimeSinceStartup;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("round_start", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "bolts_per_round", (boltSpawner != null ? boltSpawner.boltsPerRound : -1) },
            { "shields_remaining", GetActiveShieldCount() }
        });

        BeginRoundTracking();
        StartRound();
    }

    private void OnShieldGrabEnded()
    {
        SetAuraVisible(false);
    }

    // -------------------- Core round control --------------------
    public void StartRound()
    {
        if (isGameOver) return;
        if (boltSpawner != null) boltSpawner.StartRound();
    }

    private void BeginRoundTracking()
    {
        spawnedThisRound = 0;
        resolvedThisRound = 0;
        spawnerFinishedThisRound = false;
        nextSpawnId = 1;

        shieldsLostThisRound = 0;
    }

    private void TryHandleRoundComplete()
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        if (!spawnerFinishedThisRound) return;
        if (spawnedThisRound <= 0) return;
        if (resolvedThisRound < spawnedThisRound) return;

        spawnerFinishedThisRound = false;
        StartCoroutine(RoundCompleteSequence());
    }

    private IEnumerator RoundCompleteSequence()
    {
        // Freeze gameplay
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        float roundSeconds = Time.realtimeSinceStartup - roundStartRealtime;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("round_complete", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "round_seconds", Mathf.RoundToInt(roundSeconds) },
            { "shields_lost_this_round", shieldsLostThisRound }
        }, flush: true);

        // Snap Zeus + shields to center
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }
        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        // clear taunt (deity-level)
        if (dp != null && !string.IsNullOrEmpty(dp.clearTauntText))
        {
            ShowCenterText(dp.clearTauntText);
            yield return new WaitForSecondsRealtime(dp.clearTauntHoldTime);
            HideCenterText();
        }

        // Advance round within deity
        currentRoundWithinDeity++;

        bool advancedToNewDeity = false;

        // If deity finished, advance deity and rebuild baselines
        if (dp != null && currentRoundWithinDeity > Mathf.Max(1, dp.roundsCount))
        {
            int lastRoundWithin = Mathf.Max(1, dp.roundsCount);
            CacheEndOfDeityAsInherited(dp, lastRoundWithin);

            currentDeityIndex++;

            // Win if no more deities
            if (currentDeityIndex >= deityProfiles.Count)
            {
                ShowCenterText(finalWinText);
                yield return new WaitForSecondsRealtime(finalWinHoldTime);
                HideCenterText();
                ReturnToTitleScreenAndReset();
                yield break;
            }

            currentRoundWithinDeity = 1;
            advancedToNewDeity = true;

            ApplyDeityCosmetics(GetCurrentDeity());
            ResetShakeForNewDeity();
        }

        // Overall round always increments when we move to a new round
        currentOverallRoundIndex++;

        if (advancedToNewDeity)
        {
            yield return StartCoroutine(PlayDeityFirstAppearanceIntroIfNeeded());
        }

        yield return StartCoroutine(ShowRoundLabelIfEnabled());
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        ApplyDifficultyForCurrentRound();

        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (shieldDrag != null) shieldDrag.enabled = true;
        if (zeusMover != null) zeusMover.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        BeginRoundTracking();
    }

    // -------------------- Difficulty / cosmetics --------------------
    private DeityProfile GetCurrentDeity()
    {
        if (deityProfiles == null || deityProfiles.Count == 0) return null;
        currentDeityIndex = Mathf.Clamp(currentDeityIndex, 0, deityProfiles.Count - 1);
        return deityProfiles[currentDeityIndex];
    }

    private void ApplyDeityCosmetics(DeityProfile dp)
    {
        if (dp == null) return;

        CacheDeityVisualRendererIfNeeded();

        if (dp.deitySprite != null && deityVisualRenderer != null)
            deityVisualRenderer.sprite = dp.deitySprite;

        if (dp.deitySprite != null && deitySpriteImage != null)
            deitySpriteImage.sprite = dp.deitySprite;

        if (dp.deitySprite != null && deitySpriteRenderer != null)
            deitySpriteRenderer.sprite = dp.deitySprite;

        if (bgGradientImage != null)
            bgGradientImage.color = dp.bgGradientTint;

        if (bgGradientSpriteRenderer != null)
            bgGradientSpriteRenderer.color = dp.bgGradientTint;

        if (boltSpawner != null && dp.projectilePrefab != null)
            boltSpawner.SetBoltPrefab(dp.projectilePrefab);
    }

    private void ApplyDifficultyForCurrentRound()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) return;

        float baseMinDelay = dp.overrideBaselineMinSpawnDelay ? dp.baselineMinSpawnDelay : inheritedMinSpawnDelay;
        float baseMaxDelay = dp.overrideBaselineMaxSpawnDelay ? dp.baselineMaxSpawnDelay : inheritedMaxSpawnDelay;
        float baseFall = dp.overrideBaselineBoltFallSpeed ? dp.baselineBoltFallSpeed : inheritedBoltFallSpeed;
        float baseMove = dp.overrideBaselineZeusMoveSpeed ? dp.baselineZeusMoveSpeed : inheritedZeusMoveSpeed;
        float baseMinT = dp.overrideBaselineZeusMinChangeTime ? dp.baselineZeusMinChangeTime : inheritedZeusMinChangeTime;
        float baseMaxT = dp.overrideBaselineZeusMaxChangeTime ? dp.baselineZeusMaxChangeTime : inheritedZeusMaxChangeTime;

        float spine = 1.0f + (currentRoundWithinDeity - 1) * dp.spineIncrementPerRound;

        float delayScale = Mathf.Pow(spine, Mathf.Max(0f, dp.spawnDelayWeight));
        float fallScale = Mathf.Pow(spine, Mathf.Max(0f, dp.boltFallSpeedWeight));
        float moveScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusMoveSpeedWeight));
        float changeScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusChangeTimeWeight));

        int bolts = Mathf.Max(1, dp.boltsPerRound);

        float minD = Mathf.Max(minAllowedDelay, baseMinDelay / delayScale);
        float maxD = Mathf.Max(minAllowedDelay, baseMaxDelay / delayScale);
        if (maxD < minD) maxD = minD;

        float fall = baseFall * fallScale;

        float zeusSpeed = baseMove * moveScale;
        float minCT = Mathf.Max(minAllowedChangeTime, baseMinT / changeScale);
        float maxCT = Mathf.Max(minAllowedChangeTime, baseMaxT / changeScale);

        if (boltSpawner != null)
        {
            boltSpawner.boltsPerRound = bolts;
            boltSpawner.minSpawnDelay = minD;
            boltSpawner.maxSpawnDelay = maxD;
            boltSpawner.boltFallSpeed = fall;
        }

        if (zeusMover != null)
        {
            zeusMover.moveSpeed = zeusSpeed;
            zeusMover.minChangeTime = Mathf.Min(minCT, maxCT);
            zeusMover.maxChangeTime = Mathf.Max(minCT, maxCT);
        }

        UpdateShakeAvailabilityForOverallRound(currentOverallRoundIndex);
    }

    private void CacheEndOfDeityAsInherited(DeityProfile dp, int lastRoundWithinDeity)
    {
        if (dp == null) return;

        float baseMinDelay = dp.overrideBaselineMinSpawnDelay ? dp.baselineMinSpawnDelay : inheritedMinSpawnDelay;
        float baseMaxDelay = dp.overrideBaselineMaxSpawnDelay ? dp.baselineMaxSpawnDelay : inheritedMaxSpawnDelay;
        float baseFall = dp.overrideBaselineBoltFallSpeed ? dp.baselineBoltFallSpeed : inheritedBoltFallSpeed;
        float baseMove = dp.overrideBaselineZeusMoveSpeed ? dp.baselineZeusMoveSpeed : inheritedZeusMoveSpeed;
        float baseMinT = dp.overrideBaselineZeusMinChangeTime ? dp.baselineZeusMinChangeTime : inheritedZeusMinChangeTime;
        float baseMaxT = dp.overrideBaselineZeusMaxChangeTime ? dp.baselineZeusMaxChangeTime : inheritedZeusMaxChangeTime;

        float spine = 1.0f + (lastRoundWithinDeity - 1) * dp.spineIncrementPerRound;

        float delayScale = Mathf.Pow(spine, Mathf.Max(0f, dp.spawnDelayWeight));
        float fallScale = Mathf.Pow(spine, Mathf.Max(0f, dp.boltFallSpeedWeight));
        float moveScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusMoveSpeedWeight));
        float changeScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusChangeTimeWeight));

        inheritedMinSpawnDelay = Mathf.Max(minAllowedDelay, baseMinDelay / delayScale);
        inheritedMaxSpawnDelay = Mathf.Max(minAllowedDelay, baseMaxDelay / delayScale);
        if (inheritedMaxSpawnDelay < inheritedMinSpawnDelay) inheritedMaxSpawnDelay = inheritedMinSpawnDelay;

        inheritedBoltFallSpeed = baseFall * fallScale;
        inheritedZeusMoveSpeed = baseMove * moveScale;

        inheritedZeusMinChangeTime = Mathf.Max(minAllowedChangeTime, baseMinT / changeScale);
        inheritedZeusMaxChangeTime = Mathf.Max(minAllowedChangeTime, baseMaxT / changeScale);
        if (inheritedZeusMaxChangeTime < inheritedZeusMinChangeTime) inheritedZeusMaxChangeTime = inheritedZeusMinChangeTime;
    }

    // -------------------- Life loss / Game over --------------------
    public void OnBoltHitGround(Bolt groundBolt)
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        StartCoroutine(LifeLostSequence(groundBolt));
    }

    private IEnumerator LifeLostSequence(Bolt groundBolt)
    {
        inLossSequence = true;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("life_lost", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "cause", "bolt_hit_ground" },
            { "shields_before_loss", GetActiveShieldCount() }
        }, flush: true);

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        // freeze bolts
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else activeBolts[i].FreezeBolt();
        }

        // failure SFX at the "ground hit" moment
        if (groundBolt != null)
            PlayFailPopSfx();

        // explode ground-hit bolt
        if (groundBolt != null) groundBolt.Explode();
        yield return new WaitForSecondsRealtime(firstBoomHold);

        // pop remaining bottom->top
        List<Bolt> snapshot = activeBolts
            .Where(b => b != null)
            .OrderBy(b => b.transform.position.y)
            .ThenBy(b => b.spawnId)
            .ToList();

        foreach (Bolt b in snapshot)
        {
            if (b == null) continue;

            PlayFailPopSfx();

            b.Explode();
            yield return new WaitForSecondsRealtime(popInterval);
        }

        activeBolts.RemoveAll(b => b == null);

        bool removed = RemoveOneShield();
        if (!removed || AreAllShieldsGone())
        {
            HandleGameOver();
            inLossSequence = false;

            if (autoRestartAfterGameOver)
            {
                yield return new WaitForSecondsRealtime(gameOverRestartDelay);
                RestartFromGameOver();
            }

            yield break;
        }

        // reset X positions
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }
        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        yield return new WaitForSecondsRealtime(resetDelay);

        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        ApplyDifficultyForCurrentRound();
        BeginRoundTracking();

        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = true;

        SetPromptVisible(false);
        SetAuraVisible(false);

        inLossSequence = false;
    }

    private bool RemoveOneShield()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0) return false;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf)
            {
                shieldsLostThisRound++;
                s.SetActive(false);
                return true;
            }
        }
        return false;
    }

    private bool AreAllShieldsGone()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0) return true;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf) return false;
        }
        return true;
    }

    private void HandleGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        float runSeconds = Time.realtimeSinceStartup - runStartRealtime;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("run_end", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index_reached", currentOverallRoundIndex },
            { "run_seconds", Mathf.RoundToInt(runSeconds) }
        }, flush: true);

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        StartCoroutine(GameOverRoutine());
    }

    private IEnumerator GameOverRoutine()
    {
        // clear bolts
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else
            {
                activeBolts[i].FreezeBolt();
                activeBolts[i].Explode();
            }
        }
        activeBolts.RemoveAll(b => b == null);

        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        if (!string.IsNullOrEmpty(gameOverTauntText))
        {
            ShowCenterText(gameOverTauntText);
            yield return new WaitForSecondsRealtime(gameOverTauntHoldTime);
        }

        ShowCenterText(gameOverText);
        yield return new WaitForSecondsRealtime(gameOverHoldTime);

        HideCenterText();
        ReturnToTitleScreenAndReset();
    }

    private void ReturnToTitleScreenAndReset()
    {
        Time.timeScale = 1f;

        if (titlePanel != null) titlePanel.SetActive(true);
        if (hudPanel != null) hudPanel.SetActive(false);

        StopGameplayMusic();
        if (resumeTitleMusicOnReturnToTitle) StartTitleMusic();

        if (spawningRoot != null) spawningRoot.SetActive(false);
        if (groundRoot != null) groundRoot.SetActive(false);
        if (worldRoot != null) worldRoot.SetActive(false);

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(false);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(false);

        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        waitingForFirstGrab = false;
        gameplayStarted = false;

        SetAuraVisible(false);
        SetPromptVisible(false);
        HideCenterText();

        inLossSequence = false;
        isGameOver = false;

        currentDeityIndex = 0;
        currentRoundWithinDeity = 1;
        currentOverallRoundIndex = 1;

        inheritedMinSpawnDelay = initialMinSpawnDelay;
        inheritedMaxSpawnDelay = initialMaxSpawnDelay;
        inheritedBoltFallSpeed = initialBoltFallSpeed;
        inheritedZeusMoveSpeed = initialZeusMoveSpeed;
        inheritedZeusMinChangeTime = initialZeusMinChangeTime;
        inheritedZeusMaxChangeTime = initialZeusMaxChangeTime;

        ResetShakeStateForNewRun();
        BeginRoundTracking();
    }

    private void RestartFromGameOver()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        isGameOver = false;

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        StartRound();
    }

    // -------------------- Center text helpers --------------------
    private void ShowCenterText(string msg)
    {
        if (centerText == null) return;
        centerText.gameObject.SetActive(true);
        centerText.text = msg;
    }

    private void HideCenterText()
    {
        if (centerText == null) return;
        centerText.text = "";
        centerText.gameObject.SetActive(false);
    }

    private int GetActiveShieldCount()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null) return 0;

        int count = 0;
        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            var s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf) count++;
        }
        return count;
    }

    // -------------------- Shake the Heavens --------------------
    private void SetShakeIconLit(bool lit)
    {
        if (shakeIcon == null) return;
        Color c = shakeIcon.color;
        c.a = lit ? shakeIconLitAlpha : shakeIconDimAlpha;
        shakeIcon.color = c;
    }

    private void UpdateShakeAvailabilityForOverallRound(int overallRoundIndex)
    {
        shakeAvailable = (!shakeUsed) && (overallRoundIndex >= shakeUnlockOverallRoundIndex);
        SetShakeIconLit(shakeAvailable);
    }

    private void ResetShakeStateForNewRun()
    {
        shakeAvailable = false;
        shakeUsed = false;
        SetShakeIconLit(false);

        if (boltSpawner != null)
            boltSpawner.SetPaused(false);
    }

    public void Debug_OnShakeTheHeavensTriggered()
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        if (!shakeAvailable) return;
        if (shakeUsed) return;

        // ---- Analytics: STH used (counts bolts cleared right now) ----
        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("sth_used", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index", currentOverallRoundIndex },
            { "bolts_cleared", activeBolts.Count }
        }, flush: true);

        shakeUsed = true;
        shakeAvailable = false;
        SetShakeIconLit(false);

        if (sthRoutine != null) StopCoroutine(sthRoutine);
        sthRoutine = StartCoroutine(ShakeTheHeavensRoutine());
    }

    private IEnumerator ShakeTheHeavensRoutine()
    {
        if (boltSpawner != null) boltSpawner.SetPaused(true);
        if (zeusMover != null) zeusMover.enabled = false;

        List<Bolt> snapshot = activeBolts.Where(b => b != null).ToList();
        for (int i = 0; i < snapshot.Count; i++)
        {
            Bolt b = snapshot[i];
            if (b == null) continue;
            b.Explode();
        }

        activeBolts.RemoveAll(b => b == null);

        yield return new WaitForSecondsRealtime(sthStunDuration);

        if (!isGameOver && !inLossSequence)
        {
            if (boltSpawner != null) boltSpawner.SetPaused(false);

            if (zeusMover != null && gameplayStarted && !waitingForFirstGrab)
                zeusMover.enabled = true;
        }

        sthRoutine = null;
    }

    private void ResetShakeForNewDeity()
    {
        shakeUsed = false;
        shakeAvailable = false;
        SetShakeIconLit(false);

        if (boltSpawner != null)
            boltSpawner.SetPaused(false);
    }

    private void CacheDeityVisualRendererIfNeeded()
    {
        if (deityVisualRenderer != null) return;

        if (deityVisualRoot != null)
        {
            deityVisualRenderer = deityVisualRoot.GetComponent<SpriteRenderer>();
            return;
        }

        if (zeusRoot != null)
        {
            Transform t = zeusRoot.Find(deityVisualChildName);
            if (t != null)
            {
                deityVisualRenderer = t.GetComponent<SpriteRenderer>();
                if (deityVisualRenderer != null) return;
            }

            deityVisualRenderer = zeusRoot.GetComponentInChildren<SpriteRenderer>(true);
        }
    }

    public void UI_QuitToTitle()
    {
        Time.timeScale = 1f;

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        ReturnToTitleScreenAndReset();
    }

    // -------------------- SFX helper --------------------
    private void PlayFailPopSfx()
    {
        if (sharedSfxSource == null) return;
        if (failPopSfx == null) return;
        sharedSfxSource.PlayOneShot(failPopSfx, failPopVolume);
    }

    private void StartGameplayMusic()
    {
        if (gameplayMusicSource == null) return;

        gameplayMusicSource.loop = true;

        if (!gameplayMusicSource.isPlaying)
            gameplayMusicSource.Play();
    }

    private void StopGameplayMusic()
    {
        if (gameplayMusicSource == null) return;

        if (gameplayMusicSource.isPlaying)
            gameplayMusicSource.Stop();
    }

    private void StopTitleMusic()
    {
        if (titleMusicSource == null) return;

        if (titleMusicSource.isPlaying)
            titleMusicSource.Stop();
    }

    private void StartTitleMusic()
    {
        if (titleMusicSource == null) return;

        titleMusicSource.loop = true;

        // HARD restart so it always comes back after being stopped once
        titleMusicSource.Stop();
        titleMusicSource.time = 0f;          // reset playback head
        titleMusicSource.Play();
    }
}