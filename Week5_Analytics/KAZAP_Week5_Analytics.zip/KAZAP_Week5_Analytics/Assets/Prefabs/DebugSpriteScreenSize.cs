using UnityEngine;

public class DebugSpriteScreenSize : MonoBehaviour
{
    void Start()
    {
        var sr = GetComponent<SpriteRenderer>();
        if (!sr) return;

        var cam = Camera.main;
        var b = sr.bounds;

        Vector3 min = cam.WorldToScreenPoint(b.min);
        Vector3 max = cam.WorldToScreenPoint(b.max);

        float w = Mathf.Abs(max.x - min.x);
        float h = Mathf.Abs(max.y - min.y);

        Debug.Log($"{name} screen size: {w:F0} x {h:F0} px");
    }
}