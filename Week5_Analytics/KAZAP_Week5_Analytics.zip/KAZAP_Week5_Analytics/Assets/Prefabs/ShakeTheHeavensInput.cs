using UnityEngine;
using UnityEngine.UI;

public class ShakeTheHeavensInput : MonoBehaviour
{
    [Header("Shake Icon (Readiness Gate)")]
    [Tooltip("Assign your top-right shake icon Image here.")]
    public Image shakeIconImage;

    [Tooltip("Icon alpha at/above this value is considered READY (lit).")]
    [Range(0f, 1f)]
    public float readyAlphaThreshold = 0.95f;

    [Header("Real Device Shake Detection")]
    [Tooltip("0.10�0.30 is a good range. Higher = snappier, lower = smoother.")]
    [Range(0.01f, 1f)]
    public float smoothing = 0.15f;

    [Tooltip("Higher = harder to trigger. Start around 1.2�1.6.")]
    public float shakeThreshold = 1.35f;

    [Tooltip("Seconds between triggers.")]
    public float shakeCooldown = 0.75f;

    [Header("Editor / Emulator Trigger")]
    public bool enableEditorKey = true;
    public KeyCode editorKey = KeyCode.Space;

    [Header("Debug")]
    public bool logWhenBlocked = false;

    [Header("RoundManager Hook")]
    public RoundManager roundManager;

   

    private Vector3 smoothedAccel;
    private float lastShakeTime = -999f;

 

    // Prototype: one use per run (we�ll reset this later when we wire full behavior)
    // private bool usedThisRun = false;

    private void Update()
    {
        

        if (Time.timeScale == 0f)
            return;

        // If not ready, block
        if (!IsIconReady())
        {
            if (logWhenBlocked && (Application.isEditor && enableEditorKey && Input.GetKeyDown(editorKey)))
                Debug.Log("STH blocked: icon not ready/lit.");
            return;
        }

        // NEW: Block STH during life-loss sequence / game over so we don't consume it visually
        if (roundManager != null && (roundManager.IsInLossSequence || roundManager.IsGameOver))
        {
            if (logWhenBlocked && (Application.isEditor && enableEditorKey && Input.GetKeyDown(editorKey)))
                Debug.Log("STH blocked: loss sequence / game over.");
            return;
        }

        // Editor/emulator: Space key
        if (Application.isEditor && enableEditorKey)
        {
            if (Input.GetKeyDown(editorKey))
            {
                TriggerSTH("EditorKey", 0f);
                return;
            }
        }

        // Device: accelerometer shake
        Vector3 rawAccel = Input.acceleration;
        smoothedAccel = Vector3.Lerp(smoothedAccel, rawAccel, smoothing);

        float shakeSignal = (rawAccel - smoothedAccel).magnitude;

        if (shakeSignal > shakeThreshold && Time.time - lastShakeTime >= shakeCooldown)
        {
            lastShakeTime = Time.time;
            TriggerSTH("Accelerometer", shakeSignal);
        }
    }

    private bool IsIconReady()
    {
        if (shakeIconImage == null) return false;
        if (!shakeIconImage.gameObject.activeInHierarchy) return false;

        // Your current setup: dim = alpha ~0.25, ready = alpha ~1.0
        return shakeIconImage.color.a >= readyAlphaThreshold;
    }

    private void TriggerSTH(string source, float signal)
    {
        Debug.Log($"STH TRIGGERED! source={source}  signal={signal:F2}");

        if (roundManager != null)
            roundManager.Debug_OnShakeTheHeavensTriggered();
    }

    // We�ll call this later when Round 3 begins (or when a new game starts) to re-arm it.
    
}
