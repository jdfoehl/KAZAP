using System;
using UnityEngine;
using TMPro;

public class SwipeDetector : MonoBehaviour
{
    [Header("UI (optional)")]
    public TextMeshProUGUI debugText;

    [Header("Swipe detection parameters")]
    [Tooltip("Minimum pixels to count as swipe")]
    public float minSwipeDistance = 50f;

    [Tooltip("Maximum duration (seconds) for a swipe")]
    public float maxSwipeTime = 0.5f;

    public enum SwipeDirection { None, Up, Down, Left, Right }

    // Event you can subscribe to from other scripts (KAZAP will use this later)
    public event Action<SwipeDirection> SwipeDetected;

    private Vector2 startPos;
    private float startTime;
    private bool isTracking;

    void Update()
    {
        // Touch input (device / emulator)
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            switch (touch.phase)
            {
                case TouchPhase.Began:
                    BeginTrack(touch.position);
                    SetDebug("Touch began...");
                    break;

                case TouchPhase.Ended:
                    EndTrack(touch.position);
                    break;

                case TouchPhase.Canceled:
                    CancelTrack();
                    SetDebug("Touch canceled");
                    break;
            }

            return; // If we have touch, don't also process mouse this frame
        }

        // Mouse input (Editor convenience)
        if (Input.GetMouseButtonDown(0))
        {
            BeginTrack(Input.mousePosition);
            SetDebug("Mouse down...");
        }

        if (Input.GetMouseButtonUp(0))
        {
            EndTrack(Input.mousePosition);
        }
    }

    private void BeginTrack(Vector2 position)
    {
        startPos = position;
        startTime = Time.time;
        isTracking = true;
    }

    private void EndTrack(Vector2 endPos)
    {
        if (!isTracking)
            return;

        float duration = Time.time - startTime;
        float distance = Vector2.Distance(startPos, endPos);

        if (distance >= minSwipeDistance && duration <= maxSwipeTime)
        {
            SwipeDirection dir = GetSwipeDirection(startPos, endPos);
            OnSwipe(dir);
        }
        else
        {
            SetDebug("Not a valid swipe\n(too slow or too short)");
        }

        isTracking = false;
    }

    private void CancelTrack()
    {
        isTracking = false;
    }

    private SwipeDirection GetSwipeDirection(Vector2 start, Vector2 end)
    {
        Vector2 v = end - start;

        if (Mathf.Abs(v.x) > Mathf.Abs(v.y))
            return v.x > 0 ? SwipeDirection.Right : SwipeDirection.Left;

        return v.y > 0 ? SwipeDirection.Up : SwipeDirection.Down;
    }

    private void OnSwipe(SwipeDirection direction)
    {
        SetDebug($"SWIPE {direction.ToString().ToUpper()}!");
        Debug.Log($"Swipe detected: {direction}");

        SwipeDetected?.Invoke(direction);
    }

    private void SetDebug(string msg)
    {
        if (debugText != null)
            debugText.text = msg;
    }
}