using UnityEngine;
using UnityEngine.UI;

public class AudioSettingsManager : MonoBehaviour
{
    [Header("UI")]
    public Toggle musicToggle;
    public Toggle sfxToggle;

    [Header("PlayerPrefs Keys")]
    public string musicPrefKey = "MusicEnabled";
    public string sfxPrefKey = "SFXEnabled";

    // Optional: easy access from other scripts (RoundManager)
    public static AudioSettingsManager Instance { get; private set; }

    private void Awake()
    {
        // Singleton-ish (keeps things simple if you ever duplicate panels)
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        // Load saved prefs (default ON)
        bool musicOn = PlayerPrefs.GetInt(musicPrefKey, 1) == 1;
        bool sfxOn = PlayerPrefs.GetInt(sfxPrefKey, 1) == 1;

        // Set UI state WITHOUT firing listeners
        if (musicToggle != null) musicToggle.SetIsOnWithoutNotify(musicOn);
        if (sfxToggle != null) sfxToggle.SetIsOnWithoutNotify(sfxOn);

        // Ensure we don't double-register if this object re-enables
        if (musicToggle != null)
        {
            musicToggle.onValueChanged.RemoveListener(OnMusicToggled);
            musicToggle.onValueChanged.AddListener(OnMusicToggled);
        }

        if (sfxToggle != null)
        {
            sfxToggle.onValueChanged.RemoveListener(OnSfxToggled);
            sfxToggle.onValueChanged.AddListener(OnSfxToggled);
        }

        // Apply immediately on boot (covers title screen)
        ApplySaved();
    }

    /// <summary>
    /// Re-apply PlayerPrefs to all tagged audio objects.
    /// Call this after enabling gameplay roots (SpawningRoot, etc).
    /// </summary>
    public void ApplySaved()
    {
        bool musicOn = PlayerPrefs.GetInt(musicPrefKey, 1) == 1;
        bool sfxOn = PlayerPrefs.GetInt(sfxPrefKey, 1) == 1;

        ApplyMusic(musicOn);
        ApplySfx(sfxOn);
    }

    private void OnMusicToggled(bool on)
    {
        PlayerPrefs.SetInt(musicPrefKey, on ? 1 : 0);
        PlayerPrefs.Save();
        ApplyMusic(on);
    }

    private void OnSfxToggled(bool on)
    {
        PlayerPrefs.SetInt(sfxPrefKey, on ? 1 : 0);
        PlayerPrefs.Save();
        ApplySfx(on);
    }

    private void ApplyMusic(bool on)
    {
        GameObject[] tagged = GameObject.FindGameObjectsWithTag("Music");
        for (int i = 0; i < tagged.Length; i++)
        {
            if (tagged[i] == null) continue;

            AudioSource[] sources = tagged[i].GetComponentsInChildren<AudioSource>(true);
            for (int s = 0; s < sources.Length; s++)
            {
                if (sources[s] == null) continue;
                sources[s].mute = !on;
            }
        }
    }

    private void ApplySfx(bool on)
    {
        GameObject[] tagged = GameObject.FindGameObjectsWithTag("SFX");
        for (int i = 0; i < tagged.Length; i++)
        {
            if (tagged[i] == null) continue;

            AudioSource[] sources = tagged[i].GetComponentsInChildren<AudioSource>(true);
            for (int s = 0; s < sources.Length; s++)
            {
                if (sources[s] == null) continue;
                sources[s].mute = !on;
            }
        }
    }
}