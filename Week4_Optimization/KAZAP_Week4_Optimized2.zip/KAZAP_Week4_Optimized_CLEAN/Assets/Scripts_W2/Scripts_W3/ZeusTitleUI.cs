using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class ZeusTitleUI : MonoBehaviour
{
    [Header("References")]
    public RectTransform zeusRect;      // Zeus UI Image RectTransform
    public Image zeusImage;             // Zeus UI Image component

    [Header("Zeus Sprites (2-frame throw)")]
    public Sprite zeusArmUp;
    public Sprite zeusArmDown;

    [Header("Horizontal Patrol Band (anchored X in pixels)")]
    public float minX = -260f;
    public float maxX = 260f;
    public float moveSpeed = 260f;      // pixels/sec

    [Header("Auto Band (recommended)")]
    public bool autoComputeBand = true;
    public RectTransform bandRect;   // TitlePanel
    public float edgePadding = 40f;  // extra breathing room

    [Header("Direction Changes")]
    public float minChangeTime = 0.4f;
    public float maxChangeTime = 1.2f;

    private float dir = 1f;
    private float timer;
    private bool patrolEnabled = true;

    private void Reset()
    {
        zeusRect = GetComponent<RectTransform>();
        zeusImage = GetComponent<Image>();
    }

    private void OnEnable()
    {
        patrolEnabled = true;
        PickNewDirectionAndTimer();
    }

    private void Update()
    {
        if (!patrolEnabled || zeusRect == null) return;

        if (autoComputeBand && bandRect != null)
        {
            float halfBand = bandRect.rect.width * 0.5f;
            float halfZeus = zeusRect.rect.width * 0.5f;
            minX = -halfBand + halfZeus + edgePadding;
            maxX = halfBand - halfZeus - edgePadding;
        }

        Vector2 p = zeusRect.anchoredPosition;
        p.x += dir * moveSpeed * Time.unscaledDeltaTime;

        // Clamp + bounce
        if (p.x <= minX)
        {
            p.x = minX;
            dir = 1f;
            PickNewDirectionAndTimer();
        }
        else if (p.x >= maxX)
        {
            p.x = maxX;
            dir = -1f;
            PickNewDirectionAndTimer();
        }

        zeusRect.anchoredPosition = p;

        // Random direction change
        timer -= Time.unscaledDeltaTime;
        if (timer <= 0f)
        {
            dir = (Random.value < 0.5f) ? -1f : 1f;
            PickNewDirectionAndTimer();
        }
    }

    private void PickNewDirectionAndTimer()
    {
        timer = Random.Range(minChangeTime, maxChangeTime);
    }

    public void StopPatrol()
    {
        patrolEnabled = false;
    }

    public void SnapToCenterX(float centerX = 0f)
    {
        if (zeusRect == null) return;
        Vector2 p = zeusRect.anchoredPosition;
        p.x = centerX;
        zeusRect.anchoredPosition = p;
    }

    public IEnumerator PlayThrowTwoFrame(float armUpTime = 0.08f)
    {
        if (zeusImage == null) yield break;

        if (zeusArmUp != null) zeusImage.sprite = zeusArmUp;
        yield return new WaitForSecondsRealtime(armUpTime);

        if (zeusArmDown != null) zeusImage.sprite = zeusArmDown;
    }
}