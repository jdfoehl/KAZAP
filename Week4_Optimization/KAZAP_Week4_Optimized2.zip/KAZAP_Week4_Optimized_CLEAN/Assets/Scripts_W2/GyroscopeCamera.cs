using UnityEngine;
using TMPro;

public class GyroscopeCamera : MonoBehaviour
{
    public TextMeshProUGUI debugText;

    private Gyroscope gyro;
    private bool gyroEnabled;

    void Start()
    {
        gyroEnabled = EnableGyro();
        if (debugText != null)
            debugText.text = gyroEnabled ? "Gyroscope Active" : "Gyroscope NOT available (using fallback)";
    }

    bool EnableGyro()
    {
        if (!SystemInfo.supportsGyroscope) return false; // Unity check :contentReference[oaicite:1]{index=1}

        gyro = Input.gyro;
        gyro.enabled = true;
        return true;
    }

    void Update()
    {
        if (!gyroEnabled)
        {
            // Fallback: let you test in Editor with mouse look (optional)
            float yaw = Input.GetAxis("Mouse X") * 2f;
            float pitch = -Input.GetAxis("Mouse Y") * 2f;
            transform.Rotate(pitch, yaw, 0f, Space.Self);

            if (debugText != null)
                debugText.text = "Gyro NOT available\n(Mouse look fallback)";
            return;
        }

        // Gyro attitude is a Quaternion (device orientation)
        Quaternion deviceRotation = gyro.attitude;

        // Unity vs device coordinate correction (common pattern; may need slight tweaks per device/emulator)
        Quaternion correction = Quaternion.Euler(90f, 0f, 0f);
        transform.rotation = correction * deviceRotation;

        if (debugText != null)
        {
            Vector3 euler = transform.rotation.eulerAngles;
            Vector3 rr = gyro.rotationRate;
            debugText.text =
                "Gyroscope Active\n" +
                $"Euler  X:{euler.x:F1}  Y:{euler.y:F1}  Z:{euler.z:F1}\n" +
                $"RotRate X:{rr.x:F2}  Y:{rr.y:F2}  Z:{rr.z:F2}";
        }
    }
}