using UnityEngine;
using UnityEngine.InputSystem;

public class ShieldDragController : MonoBehaviour
{
    [Header("What moves")]
    [Tooltip("The Transform that should actually move. If null, uses this transform.")]
    public Transform moveTarget;

    [Header("Where you�re allowed to start dragging")]
    [Tooltip("Touch must begin on one of these colliders (typically your 3 shield colliders).")]
    public Collider2D[] grabColliders;

    [Header("Drag Behavior")]
    public bool requireGrabOnShield = true;
    public bool lockY = true;
    public float smooth = 20f;

    // allow starting a grab if the finger/mouse is already held down
    public bool allowLateGrabWhileHeld = true;

    [Header("Pause Lock")]
    public bool inputLocked = false;

    [Header("Bounds")]
    public bool useCameraBounds = true;
    public float cameraPadding = 0.35f;
    public float minX = -2.5f;
    public float maxX = 2.5f;

    private Camera cam;
    private bool dragging;
    private int activePointerId = int.MinValue; // touchId for touch; -999 for mouse
    private float lockedY;

    // lets you lower/raise the band without changing art/transforms
    public float lockedYOffset = 0f;

    // prevents �snap back� if you adjust Y during play/testing
    public bool recaptureLockedYOnBeginDrag = true;

    // Signals (RoundManager will listen to these)
    public event System.Action GrabStarted;
    public event System.Action GrabEnded;

    [Header("Debug")]
    public bool debugGrabSignals = false;

    private const int MOUSE_ID = -999;

    private void Awake()
    {
        cam = Camera.main;
        if (moveTarget == null) moveTarget = transform;
        lockedY = moveTarget.position.y;

        // If grabColliders not assigned, fall back to a collider on this object (if any).
        if (grabColliders == null || grabColliders.Length == 0)
        {
            Collider2D c = GetComponent<Collider2D>();
            if (c != null) grabColliders = new Collider2D[] { c };
        }
    }

    private void Update()
    {
        if (inputLocked)
        {
            // Safety: if we ever get paused mid-drag, guarantee we exit cleanly.
            ForceCancelDrag();
            return;
        }

        HandleMouse_NewInputSystem();
        HandleTouch_NewInputSystem();
    }

    private void BeginDrag(int pointerId)
    {
        if (lockY && recaptureLockedYOnBeginDrag)
            lockedY = moveTarget.position.y;

        dragging = true;
        activePointerId = pointerId;

        if (debugGrabSignals) Debug.Log("ShieldDragController: GrabStarted");
        GrabStarted?.Invoke();
    }

    private void EndDrag()
    {
        dragging = false;
        activePointerId = int.MinValue;

        if (debugGrabSignals) Debug.Log("ShieldDragController: GrabEnded");
        GrabEnded?.Invoke();
    }

    public void ForceCancelDrag()
    {
        if (!dragging) return;

        // End the drag WITHOUT moving the target.
        dragging = false;
        activePointerId = int.MinValue;

        if (debugGrabSignals) Debug.Log("ShieldDragController: ForceCancelDrag");
        GrabEnded?.Invoke();
    }

    private void HandleMouse_NewInputSystem()
    {
        if (Mouse.current == null || cam == null) return;

        bool downThisFrame = Mouse.current.leftButton.wasPressedThisFrame;
        bool held = Mouse.current.leftButton.isPressed;

        Vector2 screenPos = Mouse.current.position.ReadValue();
        Vector2 wp = ScreenToWorld2D(screenPos);

        // Start on click-down (normal)
        if (downThisFrame && !dragging)
        {
            if (CanStartDrag(wp))
                BeginDrag(MOUSE_ID);
        }

        // Late-grab: if input becomes enabled while mouse is already held
        if (!dragging && allowLateGrabWhileHeld && held)
        {
            if (CanStartDrag(wp))
                BeginDrag(MOUSE_ID);
        }

        // Continue / End
        if (dragging && activePointerId == MOUSE_ID)
        {
            if (held)
            {
                MoveTowardsX(wp.x);
            }
            else
            {
                EndDrag();
            }
        }
    }

    private void HandleTouch_NewInputSystem()
    {
        if (Touchscreen.current == null || cam == null) return;

        var touches = Touchscreen.current.touches;

        // Begin
        for (int i = 0; i < touches.Count; i++)
        {
            var t = touches[i];
            if (t == null) continue;

            // Only consider active touches
            bool pressed = t.press.isPressed;
            if (!pressed) continue;

            var phase = t.phase.ReadValue();
            int touchId = t.touchId.ReadValue();
            Vector2 wp = ScreenToWorld2D(t.position.ReadValue());

            if (!dragging)
            {
                bool wantsBegin =
                    phase == UnityEngine.InputSystem.TouchPhase.Began ||
                    (allowLateGrabWhileHeld && (phase == UnityEngine.InputSystem.TouchPhase.Moved ||
                                                phase == UnityEngine.InputSystem.TouchPhase.Stationary));

                if (wantsBegin && CanStartDrag(wp))
                {
                    BeginDrag(touchId);
                    break;
                }
            }
        }

        // Continue / End
        if (!dragging) return;

        bool foundActiveTouch = false;

        for (int i = 0; i < touches.Count; i++)
        {
            var t = touches[i];
            if (t == null) continue;

            int touchId = t.touchId.ReadValue();
            if (touchId != activePointerId) continue;

            foundActiveTouch = true;

            bool pressed = t.press.isPressed;
            var phase = t.phase.ReadValue();

            if (!pressed || phase == UnityEngine.InputSystem.TouchPhase.Ended || phase == UnityEngine.InputSystem.TouchPhase.Canceled)
            {
                EndDrag();
                break;
            }

            if (phase == UnityEngine.InputSystem.TouchPhase.Moved || phase == UnityEngine.InputSystem.TouchPhase.Stationary)
            {
                Vector2 wp = ScreenToWorld2D(t.position.ReadValue());
                MoveTowardsX(wp.x);
            }

            break;
        }

        // If our active touch vanished (rare, but can happen), end safely.
        if (dragging && !foundActiveTouch && activePointerId != MOUSE_ID)
        {
            EndDrag();
        }
    }

    private Vector2 ScreenToWorld2D(Vector2 screenPos)
    {
        Vector3 w3 = cam.ScreenToWorldPoint(new Vector3(screenPos.x, screenPos.y, 0f));
        return new Vector2(w3.x, w3.y);
    }

    private bool CanStartDrag(Vector2 worldPos)
    {
        if (!requireGrabOnShield) return true;
        if (grabColliders == null) return false;

        for (int i = 0; i < grabColliders.Length; i++)
        {
            if (grabColliders[i] != null && grabColliders[i].OverlapPoint(worldPos))
                return true;
        }

        return false;
    }

    private void MoveTowardsX(float targetX)
    {
        float clampedX = ClampX(targetX);

        Vector3 p = moveTarget.position;
        if (lockY) p.y = lockedY + lockedYOffset;

        // Smooth
        p.x = Mathf.Lerp(p.x, clampedX, smooth * Time.deltaTime);

        moveTarget.position = p;
    }

    private float ClampX(float desiredX)
    {
        if (!useCameraBounds || cam == null) return Mathf.Clamp(desiredX, minX, maxX);

        float halfHeight = cam.orthographicSize;
        float halfWidth = halfHeight * cam.aspect;

        float left = cam.transform.position.x - halfWidth + cameraPadding;
        float right = cam.transform.position.x + halfWidth - cameraPadding;

        return Mathf.Clamp(desiredX, left, right);
    }
}