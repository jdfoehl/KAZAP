using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Collider2D))]
public class Bolt : MonoBehaviour
{
    [Header("Fall (Kinematic)")]
    public float fallSpeed = 8f;          // units/sec
    public float maxLifetime = 6f;        // safety despawn

    [Header("Debug")]
    public int spawnId;

    [Header("Effects (optional)")]
    public GameObject explodeVfxPrefab;

    [Header("Audio (optional)")]
    public AudioClip spawnSfx;
    public AudioClip explodeSfx;
    [Range(0f, 1f)] public float sfxVolume = 1f;

    private RoundManager rm;
    private Rigidbody2D rb;

    private float lifeTimer;
    private bool isDead;
    private bool isFrozen;

    private float baseFallSpeed;

    // If RoundManager passes a shared AudioSource (recommended), we use it.
    // Otherwise we fall back to a local AudioSource (if present).
    private AudioSource sfxSource;

    // Pool reference (set by BoltSpawner when spawned)
    private BoltPool pool;

    public void SetPool(BoltPool poolRef)
    {
        pool = poolRef;
    }

    // Prevent double-unregister (Explode + OnDestroy)
    private bool unregistered;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        baseFallSpeed = fallSpeed;

        // Fallback local AudioSource (optional)
        if (sfxSource == null)
            sfxSource = GetComponent<AudioSource>();
    }

    // Called by RoundManager.RegisterBolt(...)
    public void Init(RoundManager roundManager, int id, AudioSource sharedSfxSource)
    {
        rm = roundManager;
        spawnId = id;

        // Prefer shared source, fallback to local
        if (sharedSfxSource != null)
            sfxSource = sharedSfxSource;
        else if (sfxSource == null)
            sfxSource = GetComponent<AudioSource>();

        // Spawn sound (optional)
        PlaySfx(spawnSfx);
    }

    public void ApplyFallSpeedScalar(float scalar)
    {
        // scalar 1.0 = unchanged, 1.3 = 30% faster, etc.
        fallSpeed = baseFallSpeed * Mathf.Max(0.1f, scalar);
    }

    private void OnEnable()
    {
        lifeTimer = 0f;
        isDead = false;
        isFrozen = false;
        unregistered = false;

        // Ensure we start "live" every spawn
        if (rb != null)
            rb.simulated = true;
    }

    private void FixedUpdate()
    {
        if (isDead || isFrozen) return;

        // Kinematic fall straight down (no physics gravity)
        Vector2 p = rb.position;
        p.y -= fallSpeed * Time.fixedDeltaTime;
        rb.MovePosition(p);

        // Safety despawn
        lifeTimer += Time.fixedDeltaTime;
        if (lifeTimer >= maxLifetime)
            Explode();
    }

    public void FreezeBolt()
    {
        if (isDead) return;

        isFrozen = true;

        // We *want* everything to truly stop (and we use realtime waits in RoundManager)
        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.angularVelocity = 0f;
            rb.simulated = false;
        }
    }

    public void Explode()
    {
        if (isDead) return;
        isDead = true;

        // VFX
        if (explodeVfxPrefab != null)
            Instantiate(explodeVfxPrefab, transform.position, Quaternion.identity);

        // SFX
        PlaySfx(explodeSfx);

        // Unregister ONCE
        UnregisterOnce();

        // Pool return (preferred). Fallback to Destroy if no pool provided.
        if (pool != null)
        {
            pool.Return(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void PlaySfx(AudioClip clip)
    {
        if (clip == null) return;

        // Preferred: shared/local AudioSource
        if (sfxSource != null)
        {
            sfxSource.PlayOneShot(clip, sfxVolume);
            return;
        }

        // Last resort: spatial one-shot
        AudioSource.PlayClipAtPoint(clip, transform.position, sfxVolume);
    }

    private void UnregisterOnce()
    {
        if (unregistered) return;
        unregistered = true;

        if (rm != null)
        {
            rm.UnregisterBolt(this);
            rm = null; // ensure OnDestroy can't re-unregister through old reference
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isDead) return;

        if (other.CompareTag("Shield"))
        {
            // Caught by shield -> vanish immediately (this will currently play explodeSfx)
            Explode();
            return;
        }

        if (other.CompareTag("Ground"))
        {
            // Miss -> trigger Kaboom loss sequence
            if (rm != null)
                rm.OnBoltHitGround(this);
            else
                Explode(); // fallback
        }
    }

    private void OnDestroy()
    {
        // Safety: if destroyed without calling Explode (edge cases), unregister once.
        UnregisterOnce();
    }
}