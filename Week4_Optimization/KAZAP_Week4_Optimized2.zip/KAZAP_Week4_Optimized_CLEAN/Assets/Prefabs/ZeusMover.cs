using UnityEngine;

public class ZeusMover : MonoBehaviour
{
    [Header("Horizontal Band")]
    public float minX = -2.5f;
    public float maxX = 2.5f;
    public float moveSpeed = 2.0f;

    [Header("Direction Changes")]
    public float minChangeTime = 0.4f;
    public float maxChangeTime = 1.2f;

    private float dir = 1f;
    private float timer;

    private void OnEnable()
    {
        PickNewDirectionAndTimer();
    }

    private void Update()
    {
        Vector3 p = transform.position;
        p.x += dir * moveSpeed * Time.deltaTime;

        // Clamp + bounce
        if (p.x <= minX)
        {
            p.x = minX;
            dir = 1f;
            PickNewDirectionAndTimer();
        }
        else if (p.x >= maxX)
        {
            p.x = maxX;
            dir = -1f;
            PickNewDirectionAndTimer();
        }

        transform.position = p;

        // Random direction change
        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            dir = (Random.value < 0.5f) ? -1f : 1f;
            PickNewDirectionAndTimer();
        }
    }

    private void PickNewDirectionAndTimer()
    {
        timer = Random.Range(minChangeTime, maxChangeTime);
    }
}