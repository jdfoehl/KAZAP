using System.Collections;
using UnityEngine;

public class TitleAudioController : MonoBehaviour
{
    [Header("Audio Sources")]
    [Tooltip("Looping music source (title theme).")]
    [SerializeField] private AudioSource musicSource;

    [Tooltip("SFX source for one-shots (zap) and loops (crackle).")]
    [SerializeField] private AudioSource sfxSource;

    [Header("Clips")]
    [SerializeField] private AudioClip titleLoop;
    [SerializeField] private AudioClip zapOneShot;
    [SerializeField] private AudioClip crackleLoop;

    [Header("Volumes")]
    [Range(0f, 1f)][SerializeField] private float titleMusicVolume = 0.6f;
    [Range(0f, 1f)][SerializeField] private float zapVolume = 0.9f;
    [Range(0f, 1f)][SerializeField] private float crackleVolume = 0.85f;

    [Header("Timing")]
    [SerializeField] private float musicFadeOutSeconds = 0.2f;

    private Coroutine musicFadeRoutine;

    private void Reset()
    {
        var sources = GetComponents<AudioSource>();
        if (sources.Length >= 1) musicSource = sources[0];
        if (sources.Length >= 2) sfxSource = sources[1];
    }

    private void Awake()
    {
        // Enforce 2D audio
        if (musicSource != null) musicSource.spatialBlend = 0f;
        if (sfxSource != null) sfxSource.spatialBlend = 0f;
    }

    private void Start()
    {
        PlayTitleLoop();
    }

    // ---------------- MUSIC ----------------

    public void PlayTitleLoop()
    {
        if (musicSource == null || titleLoop == null) return;

        musicSource.loop = true;
        musicSource.clip = titleLoop;
        musicSource.volume = titleMusicVolume;

        if (!musicSource.isPlaying)
            musicSource.Play();
    }

    /// <summary>
    /// Use this when returning to the Title screen after gameplay.
    /// It cancels any fade, restores volume, and guarantees the title loop is playing.
    /// </summary>
    public void HardRestartTitleMusic()
    {
        if (musicSource == null || titleLoop == null) return;

        // Cancel any in-progress fade that might be keeping volume at 0 / stopping playback.
        if (musicFadeRoutine != null)
        {
            StopCoroutine(musicFadeRoutine);
            musicFadeRoutine = null;
        }

        // Re-apply settings defensively (safe even if already correct)
        musicSource.Stop();
        musicSource.loop = true;
        musicSource.clip = titleLoop;
        musicSource.volume = titleMusicVolume;

        // Guarantee playback
        musicSource.Play();
    }

    public void FadeOutTitleMusic()
    {
        if (musicSource == null) return;

        if (musicFadeRoutine != null)
            StopCoroutine(musicFadeRoutine);

        musicFadeRoutine = StartCoroutine(MusicFadeOutRoutine(musicFadeOutSeconds));
    }

    private IEnumerator MusicFadeOutRoutine(float duration)
    {
        float startVol = musicSource.volume;
        float t = 0f;

        duration = Mathf.Max(0.01f, duration);

        while (t < duration)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / duration);
            musicSource.volume = Mathf.Lerp(startVol, 0f, a);
            yield return null;
        }

        musicSource.volume = 0f;
        musicSource.Stop();

        musicFadeRoutine = null;
    }

    // ---------------- SFX ----------------

    public void PlayZap()
    {
        if (sfxSource == null || zapOneShot == null) return;
        sfxSource.PlayOneShot(zapOneShot, zapVolume);
    }

    public void PlayCrackleOnce()
    {
        if (sfxSource == null || crackleLoop == null) return;

        // Ensure the one-shot isn�t competing with any prior clip/loop on this source
        sfxSource.Stop();
        sfxSource.loop = false;
        sfxSource.clip = null;

        sfxSource.PlayOneShot(crackleLoop, crackleVolume);
    }
}