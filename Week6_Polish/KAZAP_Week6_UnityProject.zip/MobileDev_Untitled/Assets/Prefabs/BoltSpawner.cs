using System.Collections;
using UnityEngine;

public class BoltSpawner : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private RoundManager roundManager;
    [SerializeField] private GameObject boltPrefab;
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private Transform spawnParent;

    [Header("Pooling")]
    [SerializeField] private BoltPool boltPool;
    [SerializeField] private int prewarmBolts = 25;

    [Header("Round Settings")]
    public int boltsPerRound = 10;

    public float minSpawnDelay = 0.25f;
    public float maxSpawnDelay = 0.7f;

    public float boltFallSpeed = 8f;

    [Header("State")]
    [SerializeField] private bool isPaused = false;

    private Coroutine spawnRoutine;
    private bool isRunning = false;
    private int spawnedThisRound = 0;

    public void SetBoltPrefab(GameObject newPrefab)
    {
        if (newPrefab == null) return;

        boltPrefab = newPrefab;

        // Reconfigure pool when prefab changes (e.g., Zeus -> Aphrodite)
        EnsurePoolReady(forceRebuild: true);
    }

    private void Awake()
    {
        EnsurePoolReady(forceRebuild: false);
    }

    private void EnsurePoolReady(bool forceRebuild)
    {
        if (boltPool == null)
        {
            boltPool = GetComponent<BoltPool>();
            if (boltPool == null) boltPool = gameObject.AddComponent<BoltPool>();
        }

        // We just (re)configure. BoltPool will prewarm.
        // Note: for simplicity, we don't destroy old pooled objects here�this is fine for a prototype.
        if (boltPrefab != null)
        {
            Transform poolParent = spawnParent != null ? spawnParent : transform;
            boltPool.Configure(boltPrefab, poolParent, prewarmBolts);
        }
    }

    public void StartRound()
    {
        StopRound();

        isRunning = true;
        isPaused = false;
        spawnedThisRound = 0;

        spawnRoutine = StartCoroutine(SpawnRoutine());
    }

    public void StopRound()
    {
        isRunning = false;

        if (spawnRoutine != null)
        {
            StopCoroutine(spawnRoutine);
            spawnRoutine = null;
        }
    }

    public void SetPaused(bool paused)
    {
        isPaused = paused;
    }

    // Call this when you want to remove all existing bolts instantly (e.g., shake power, round end, life loss)
    public void ReturnAllActiveBolts()
    {
        if (boltPool == null) return;

        Transform activeParent = spawnParent != null ? spawnParent : null;
        if (activeParent != null)
            boltPool.ClearAllActiveChildren(activeParent);
    }

    private IEnumerator SpawnRoutine()
    {
        yield return null;

        int targetCount = Mathf.Max(0, boltsPerRound);

        while (isRunning && spawnedThisRound < targetCount)
        {
            while (isPaused)
                yield return null;

            SpawnOneBolt();
            spawnedThisRound++;

            float delay = Random.Range(minSpawnDelay, maxSpawnDelay);
            float t = 0f;

            while (t < delay)
            {
                if (!isRunning) yield break;
                if (!isPaused) t += Time.deltaTime;
                yield return null;
            }
        }

        isRunning = false;
        spawnRoutine = null;

        if (roundManager != null)
            roundManager.OnSpawnerFinishedThisRound();
    }

    private void SpawnOneBolt()
    {
        if (boltPrefab == null || spawnPoint == null)
        {
            Debug.LogWarning("[BoltSpawner] Missing boltPrefab or spawnPoint.");
            return;
        }

        Transform parent = spawnParent != null ? spawnParent : null;

        // POOL instead of Instantiate
        if (boltPool == null) EnsurePoolReady(forceRebuild: false);

        GameObject go = boltPool.Get(spawnPoint.position, Quaternion.identity, parent);
        if (go == null) return;

        Bolt bolt = go.GetComponent<Bolt>();
        if (bolt != null)
        {
            bolt.fallSpeed = boltFallSpeed;

            // NEW: tell the bolt which pool to return to (instead of Destroy)
            bolt.SetPool(boltPool);

            if (roundManager != null)
                roundManager.RegisterBolt(bolt);
        }
    }
}