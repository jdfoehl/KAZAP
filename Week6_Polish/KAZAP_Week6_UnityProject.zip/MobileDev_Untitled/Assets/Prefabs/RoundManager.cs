﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public enum DeityGrantedPower
{
    None = 0,
    ShakeTheHeavens = 1
}

[System.Serializable]
public class DeityProfile
{
    [Header("Identity")]
    public string deityName = "Zeus";
    public int roundsCount = 5;

    [Header("Spine (per-deity)")]
    [Tooltip("0.10 -> 1.0, 1.1, 1.2... within THIS deity.")]
    [Range(0f, 1f)] public float spineIncrementPerRound = 0.10f;

    [Header("First Appearance Intro (plays only on this deity's Round 1)")]
    public bool playIntroOnFirstRound = true;

    [TextArea(2, 3)]
    [Tooltip("If blank, RoundManager.tauntText will be used as a fallback.")]
    public string introText = "";

    public float introHoldTime = 1.0f;

    [Tooltip("How far above the final position the deity starts before floating down.")]
    public float introFloatYOffset = 2.0f;

    [Tooltip("How long the float-down takes.")]
    public float introFloatDuration = 0.6f;

    [Header("Intro Vocal (optional)")]
    [Tooltip("Plays once during the intro phrase (ex: laugh / sting).")]
    public AudioClip introVocalClip = null;

    [Tooltip("Delay (seconds) after the intro text appears before playing the vocal.")]
    public float introVocalDelay = 0.0f;

    [Range(0f, 1f)]
    [Tooltip("Volume scale for this vocal clip (multiplies the AudioSource volume).")]
    public float introVocalVolume = 1.0f;

    [Header("Round UI")]
    public bool showRoundLabel = true;
    public Color roundLabelColor = Color.white;
    public float roundLabelHoldTime = 1.0f;

    [Header("Run Complete - Rain Tuning")]
    [Tooltip("Final size multiplier for THIS deity's rain projectiles (after auto-size).")]
    public float runCompleteRainSizeMultiplier = 1f;

    [Tooltip("If true, rain projectiles use the projectilePrefab's Z rotation.")]
    public bool runCompleteRainUsePrefabRotation = true;

    [Tooltip("Additional Z rotation offset (degrees). Use this if a sprite still isn't pointing down).")]
    public float runCompleteRainRotationOffset = 0f;

    [Tooltip("If true, rain spawns from grantWorldOrigin (hand) instead of the sprite center.")]
    public bool runCompleteRainUseGrantOrigin = true;

    [Tooltip("Optional extra UI offset (pixels) after converting hand world position to UI local.")]
    public Vector2 runCompleteRainUiOffset = Vector2.zero;

    [TextArea(2, 3)]
    [Tooltip("Fallback taunt used if the pool below is empty.")]
    public string clearTauntText = "";

    [Tooltip("Random taunt pool used after NON-final rounds. (Avoids immediate repeats when possible.)")]
    public string[] clearTauntPool;

    public float clearTauntHoldTime = 1.0f;

    [Header("Cosmetics")]
    public Sprite deitySprite = null;

    [Tooltip("Tint applied to your BG_Gradient (Image or SpriteRenderer).")]
    public Color bgGradientTint = Color.white;

    [Tooltip("Projectile prefab for this deity (bolt, broken heart, etc).")]
    public GameObject projectilePrefab = null;

    [Header("Gameplay (Constant per Deity)")]
    [Tooltip("Constant for all rounds in this deity (NOT spine-scaled).")]
    public int boltsPerRound = 20;

    [Header("Optional Per-Knob Weights (1 = pure spine)")]
    [Tooltip("Spawn delays scale DOWN by spine^weight (harder).")]
    [Range(0.0f, 3.0f)] public float spawnDelayWeight = 1.0f;

    [Tooltip("Bolt fall speed scales UP by spine^weight.")]
    [Range(0.0f, 3.0f)] public float boltFallSpeedWeight = 1.0f;

    [Tooltip("Zeus move speed scales UP by spine^weight.")]
    [Range(0.0f, 3.0f)] public float zeusMoveSpeedWeight = 1.0f;

    [Tooltip("Direction-change times scale DOWN by spine^weight (harder/more chaotic).")]
    [Range(0.0f, 3.0f)] public float zeusChangeTimeWeight = 1.0f;

    [Header("Baseline Resets (inherit previous deity by default)")]
    public bool overrideBaselineMinSpawnDelay = false;
    public float baselineMinSpawnDelay = 0.25f;

    public bool overrideBaselineMaxSpawnDelay = false;
    public float baselineMaxSpawnDelay = 0.60f;

    public bool overrideBaselineBoltFallSpeed = false;
    public float baselineBoltFallSpeed = 8f;

    public bool overrideBaselineZeusMoveSpeed = false;
    public float baselineZeusMoveSpeed = 2.0f;

    public bool overrideBaselineZeusMinChangeTime = false;
    public float baselineZeusMinChangeTime = 0.40f;

    public bool overrideBaselineZeusMaxChangeTime = false;
    public float baselineZeusMaxChangeTime = 1.20f;

    [Header("Power Grant (on deity clear)")]
    public DeityGrantedPower grantedPower = DeityGrantedPower.None;

    [Tooltip("World-space origin where the power icon starts (ex: deity hand).")]
    public Transform grantWorldOrigin;

    [TextArea(1, 2)]
    public string grantText = "You have proven your worth. Take this!";

    public float grantHoldTime = 0.75f;

    [TextArea(1, 2)]
    public string grantHowToText = "Tap SHAKE at any time to stun the gods!";

    public float grantHowToHoldTime = 0.90f;

    [Tooltip("How long the icon takes to fly into the slot.")]
    public float grantIconFlySeconds = 0.60f;

    [Tooltip("Icon punch scale (Shake icon) on arrival.")]
    public float grantIconPunchScale = 1.25f;

    [Tooltip("Optional one-shot SFX for the reward moment.")]
    public AudioClip grantSfx = null;

    [Range(0f, 1f)]
    public float grantSfxVolume = 0.8f;
}

public class RoundManager : MonoBehaviour
{
    [Header("Music (Title + Gameplay)")]
    [Tooltip("Title screen music loop source (AudioHub's music AudioSource).")]
    public AudioSource titleMusicSource;

    [Tooltip("Gameplay music loop source (GamePlayMusic object's AudioSource).")]
    public AudioSource gameplayMusicSource;

    [Tooltip("If true, stop title music when gameplay starts.")]
    public bool stopTitleMusicOnGameplayStart = true;

    [Tooltip("If true, resume title music when returning to title.")]
    public bool resumeTitleMusicOnReturnToTitle = true;

    [Header("Music (Run Complete)")]
    [Tooltip("Optional: dedicated music loop source for the Run Complete screen.")]
    public AudioSource runCompleteMusicSource;

    [Tooltip("Loop clip to play during the Run Complete screen.")]
    public AudioClip runCompleteMusicClip;

    [Range(0f, 1f)]
    public float runCompleteMusicVolume = 1f;

    [Tooltip("If true, stop gameplay music when Run Complete screen begins.")]
    public bool stopGameplayMusicOnRunComplete = true;

    [Header("Refs")]
    public BoltSpawner boltSpawner;
    public ZeusMover zeusMover;
    public ShieldDragController shieldDrag;

    [Header("SFX (Shared + Failure/Pop)")]
    [Tooltip("Assign the AudioSource on your tagged SFX object (ex: Spawning). Used for projectile spawn SFX and fail/pop SFX.")]
    public AudioSource sharedSfxSource;

    [Tooltip("One clip used for 'bolt hit ground' + pop sequence SFX.")]
    public AudioClip failPopSfx;

    [Range(0f, 1f)] public float failPopVolume = 1f;

    [Header("SFX (Countdown)")]
    [Tooltip("Optional. If null, we'll use sharedSfxSource.")]
    [SerializeField] private AudioSource countdownSfxSource;

    [SerializeField] private AudioClip countdownTickSfx;   // used for 3/2/1
    [SerializeField] private AudioClip countdownGoSfx;     // used for GO!

    [SerializeField, Range(0f, 1f)] private float countdownSfxVolume = 1f;

    [Tooltip("Optional: slightly raises pitch each step (3->2->1).")]
    [SerializeField] private bool countdownPitchRamp = true;

    [SerializeField, Range(0f, 0.25f)] private float countdownPitchStep = 0.06f;

    [Header("Deity Visual Swap")]
    [SerializeField] private Transform deityVisualRoot;          // assign Zeus_Frames_1 transform OR leave null to auto-find
    [SerializeField] private string deityVisualChildName = "Zeus_Frames_1";
    [SerializeField] private SpriteRenderer deityVisualRenderer; // auto-cached if null

    [SerializeField] private DeityEntranceBeamController deityEntranceBeam;

    [Header("Gameplay Roots (enable/disable)")]
    public GameObject groundRoot;
    public GameObject spawningRoot;
    public GameObject worldRoot;

    [Header("Deity Entrance SFX (Loop)")]
    [SerializeField] private AudioSource deityEntranceLoopSource;
    [SerializeField] private AudioClip deityEntranceLoopClip;
    [SerializeField, Range(0f, 1f)] private float deityEntranceLoopVolume = 0.55f;
    [SerializeField] private float deityEntranceLoopFadeOutSeconds = 0.08f;

    [Header("Deity Intro Vocal SFX (one-shot)")]
    [SerializeField] private AudioSource deityIntroVocalSource;

    [Header("UI")]
    public GameObject titlePanel;
    public GameObject hudPanel;
    public TMPro.TextMeshProUGUI centerText;
    public GameObject menuBgFullBleed;

    [Header("Run Complete UI")]
    public GameObject runCompletePanel;
    public TMPro.TextMeshProUGUI trialCompleteText;
    public TMPro.TextMeshProUGUI runStatsText;
    public TMPro.TextMeshProUGUI continueText;

    public TMPro.TextMeshProUGUI cameoNameText;

    [TextArea(1, 2)]
    public string runCompleteTapText = "TAP ANYWHERE TO CONTINUE";

    [Header("Run Complete Curtain Call")]
    public RectTransform cameoStartAnchor;
    public RectTransform cameoEndAnchor;
    public UnityEngine.UI.Image cameoDeityImage;

    [Tooltip("How long each deity float-down takes.")]
    public float cameoFloatSeconds = 0.65f;

    [Tooltip("Hold time after landing before firing.")]
    public float cameoLandHoldSeconds = 0.20f;

    [Tooltip("How long the signature shot travels.")]
    public float cameoShotSeconds = 0.28f;

    [Tooltip("How long the deity fades out.")]
    public float cameoVanishSeconds = 0.18f;

    [Header("Run Complete - TRIAL COMPLETE Blink")]
    public int trialBlinkCount = 5;
    public float trialBlinkOnSeconds = 0.28f;
    public float trialBlinkOffSeconds = 0.22f;

    [Header("Run Complete - Projectile Rain Exit")]
    public RectTransform impactLineAnchor;  // your ImpactLineAnchor
    public RectTransform cameoVfxRoot;      // your CameoVfxRoot

    [Header("Run Complete - World to UI Sizing")]
    public bool rainAutoSizeFromWorld = true;

    [Tooltip("Final multiplier after world->UI conversion (use this to 'art direct' the look).")]
    public float rainWorldToUiScale = 1.0f;

    [Tooltip("How many projectiles rain down per deity exit.")]
    public int rainCount = 16;

    [Tooltip("Seconds between each projectile spawn (stagger knob).")]
    public float rainStaggerSeconds = 0.06f;

    [Tooltip("How long each projectile takes to travel to the shield lip.")]
    public float rainTravelSeconds = 0.35f;

    [Tooltip("Projectile UI size (width/height).")]
    public float rainProjectileSize = 46f;

    [Tooltip("Small X jitter so the stream reads as multiple projectiles (0 = perfectly straight line).")]
    public float rainXJitter = 6f;

    [Header("Run Complete - Impact Shrapnel (UI)")]
    public int shrapnelFragments = 14;
    public float shrapnelLifetimeSeconds = 0.35f;
    public float shrapnelSpeed = 240f;
    public float shrapnelFragmentSize = 14f;

    [Tooltip("0 = all directions, 90 = mostly upward, 180 = full upward half-sphere.")]
    [Range(0f, 180f)]
    public float shrapnelUpConeDegrees = 120f;

    [Header("Run Complete - Impact SFX (optional)")]
    public AudioClip runCompleteImpactSfx;
    [Range(0f, 1f)] public float runCompleteImpactVolume = 1f;

    [Tooltip("Prevents audio spam when many impacts happen quickly.")]
    public float runCompleteImpactCooldownSeconds = 0.05f;

    private float nextRunCompleteImpactSfxTime;

    private bool awaitingRunCompleteTap;

    [Header("Deity UI / Cosmetics Targets (optional)")]
    [Tooltip("If assigned, this Image's sprite will be set to the current deitySprite.")]
    public Image deitySpriteImage;

    [Tooltip("If assigned, this SpriteRenderer's sprite will be set to the current deitySprite.")]
    public SpriteRenderer deitySpriteRenderer;

    [Tooltip("If assigned, tint will be applied here.")]
    public Image bgGradientImage;

    [Tooltip("If assigned, tint will be applied here.")]
    public SpriteRenderer bgGradientSpriteRenderer;

    [Header("Shake the Heavens UI")]
    public Image shakeIcon;

    [Tooltip("Optional parent (RectTransform) for the flying power icon. If empty, uses shakeIcon's parent.")]
    public RectTransform powerFlyParent;

    [Range(0f, 1f)] public float shakeIconDimAlpha = 0.25f;
    [Range(0f, 1f)] public float shakeIconLitAlpha = 1.0f;

    [Tooltip("Prototype: Shake becomes available automatically starting at this OVERALL round index.")]
    public int shakeUnlockOverallRoundIndex = 3;

    // Runtime shake state
    private bool shakeAvailable;
    private bool shakeUsed;
    private Coroutine sthRoutine;

    private bool shakeUnlockedThisRun;

    [Header("Start Gate Prompt")]
    public GameObject tapHoldPrompt;
    public GameObject shieldAuraRoot;

    [Header("Intro Text (fallback if a deity introText is blank)")]
    [TextArea(2, 3)]
    public string tauntText = "You cannot block the heavens!";

    [Header("Intro Timing (global countdown/go)")]
    public float countdownStepTime = 0.75f;
    public float goHoldTime = 0.5f;

    [Header("Intro Labels")]
    public string countdown3 = "3";
    public string countdown2 = "2";
    public string countdown1 = "1";
    public string goText = "GO!";

    [Header("Game Over UI")]
    [TextArea(2, 3)]
    public string gameOverTauntText = "Pathetic.";
    public float gameOverTauntHoldTime = 1.0f;

    public string gameOverText = "GAME OVER";
    public float gameOverHoldTime = 1.5f;

    [TextArea(2, 3)]
    public string finalWinText = "YOU WIN!";
    public float finalWinHoldTime = 1.5f;

    [Header("Safety Floors (Divide-Down Targets)")]
    public float minAllowedDelay = 0.05f;
    public float minAllowedChangeTime = 0.05f;

    [Header("Deity Profiles (set count to control total rounds)")]
    public List<DeityProfile> deityProfiles = new List<DeityProfile>();

    [Header("Initial Baselines (used ONLY for Deity #1 start if no inheritance yet)")]
    public float initialMinSpawnDelay = 0.25f;
    public float initialMaxSpawnDelay = 0.60f;
    public float initialBoltFallSpeed = 8f;
    public float initialZeusMoveSpeed = 2.0f;
    public float initialZeusMinChangeTime = 0.40f;
    public float initialZeusMaxChangeTime = 1.20f;

    [Header("Reset")]
    public Transform zeusRoot;
    public Transform shieldStackRoot;
    public float resetDelay = 1.0f;

    [Header("Kaboom Pop Timing")]
    public float firstBoomHold = 0.10f;
    public float popInterval = 0.07f;

    [Header("Life Lost - Shield Blink (after big flash)")]
    [SerializeField] private float shieldBlinkDelaySeconds = 0.18f;     // wait AFTER the culmination flash


    [Header("Life Lost Polish (Big Moment)")]
    [SerializeField] private TransformShake2D lifeLostCameraShake; // put this on a CAMERA CHILD (see note below)
    [SerializeField] private float lifeLostShakeDuration = 0.18f;  // seconds
    [SerializeField] private float lifeLostShakeMagnitude = 0.22f; // world units (tune this)
    [SerializeField] private UIFlash2D lifeLostFlash;              // LifeLostFlashOverlay's UIFlash2D

    [Header("SFX (Shield Loss)")]
    [SerializeField] private AudioClip shieldDrainSfx;
    [SerializeField, Range(0f, 1f)] private float shieldDrainVolume = 1f;

    [SerializeField, Range(1f, 4f)] private float shieldDrainVolumeBoost = 2f;

    [SerializeField] private int finalFlashPulses = 2;
    [SerializeField] private float finalFlashOnSeconds = 0.05f;
    [SerializeField] private float finalFlashOffSeconds = 0.03f;
    [SerializeField, Range(0f, 1f)] private float finalFlashAlpha = 0.85f;

    [SerializeField] private AudioClip finalPopSfx;            // BIG culmination SFX
    [SerializeField, Range(0f, 1f)] private float finalPopVolume = 1f;

    [Header("Bolt Local Flash (per pop)")]
    [SerializeField] private Color boltFlashColor = Color.white;
    [SerializeField] private float boltFlashSeconds = 0.035f;

    [Header("Shield Loss Blink")]
    [SerializeField] private int shieldBlinkCount = 3;
    [SerializeField] private float shieldBlinkOnSeconds = 0.06f;
    [SerializeField] private float shieldBlinkOffSeconds = 0.05f;

    [Header("Shake the Heavens (STH)")]
    public float sthStunDuration = 1.25f;
    public bool sthPausesSpawner = true;

    [Header("Shield Aura (tint)")]
    public Color auraOffColor = Color.white;
    public Color auraOnColor = new Color(1f, 0.92f, 0.35f, 1f);

    [Header("Shields / Lives")]
    public List<GameObject> shieldsBottomToTop = new();
    public bool autoCacheShieldsFromStack = true;

    [Header("Game Over")]
    public bool autoRestartAfterGameOver = false;
    public float gameOverRestartDelay = 1.5f;

    // ---------- Runtime state ----------
    private readonly List<SpriteRenderer> shieldRenderersBottomToTop = new();
    private readonly List<Bolt> activeBolts = new();

    private bool inLossSequence;
    private bool isGameOver;

    public bool IsInLossSequence => inLossSequence;
    public bool IsGameOver => isGameOver;

    private bool waitingForFirstGrab;
    private bool gameplayStarted;

    // --- Analytics runtime ---
    private float runStartRealtime;
    private float roundStartRealtime;
    private int shieldsLostThisRound;

    // round tracking
    private int spawnedThisRound;
    private int resolvedThisRound;
    private bool spawnerFinishedThisRound;
    private int nextSpawnId = 1;

    // deity/round indices
    private int currentDeityIndex = 0;          // 0-based
    private int currentRoundWithinDeity = 1;    // 1-based
    private int currentOverallRoundIndex = 1;   // 1-based (across all deities)

    // inherited baselines at start of current deity
    private float inheritedMinSpawnDelay;
    private float inheritedMaxSpawnDelay;
    private float inheritedBoltFallSpeed;
    private float inheritedZeusMoveSpeed;
    private float inheritedZeusMinChangeTime;
    private float inheritedZeusMaxChangeTime;

    private readonly Dictionary<DeityProfile, int> lastClearTauntIndexByDeity = new();

    private void Awake()
    {
        CacheShieldsIfNeeded();

        // Ensure gameplay music never leaks into title on scene load.
        StopGameplayMusic();
    }

    // -------------------- Shields --------------------
    private void CacheShieldsIfNeeded()
    {
        if (!autoCacheShieldsFromStack) return;
        if (shieldsBottomToTop != null && shieldsBottomToTop.Count > 0) return;
        if (shieldStackRoot == null) return;

        shieldsBottomToTop = shieldStackRoot
            .GetComponentsInChildren<Transform>(true)
            .Where(t => t != shieldStackRoot && t.CompareTag("Shield"))
            .OrderBy(t => t.position.y)
            .Select(t => t.gameObject)
            .ToList();
    }

    private void CacheShieldRenderersIfNeeded()
    {
        if (shieldRenderersBottomToTop.Count > 0) return;

        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null) return;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s == null) continue;

            SpriteRenderer sr = s.GetComponent<SpriteRenderer>();
            if (sr != null) shieldRenderersBottomToTop.Add(sr);
        }
    }

    private void SetAuraVisible(bool on)
    {
        CacheShieldRenderersIfNeeded();

        Color target = on ? auraOnColor : auraOffColor;

        for (int i = 0; i < shieldRenderersBottomToTop.Count; i++)
        {
            SpriteRenderer sr = shieldRenderersBottomToTop[i];
            if (sr == null) continue;
            if (sr.gameObject.activeInHierarchy) sr.color = target;
        }
    }

    private void SetPromptVisible(bool on)
    {
        if (tapHoldPrompt != null) tapHoldPrompt.SetActive(on);
    }

    // -------------------- Bolt tracking --------------------
    public void RegisterBolt(Bolt b)
    {
        if (b == null) return;

        if (!activeBolts.Contains(b))
        {
            activeBolts.Add(b);
            spawnedThisRound++;
        }

        // This is your shared SFX source used by Bolt spawn audio
        b.Init(this, nextSpawnId++, sharedSfxSource);
    }

    public void UnregisterBolt(Bolt b)
    {
        if (b == null) return;

        if (activeBolts.Remove(b))
        {
            resolvedThisRound++;
            TryHandleRoundComplete();
        }
    }

    public void OnSpawnerFinishedThisRound()
    {
        spawnerFinishedThisRound = true;
        TryHandleRoundComplete();
    }

    // -------------------- Start / Intro --------------------
    public void OnPressStart()
    {
        StartCoroutine(BeginGameRoutine());
    }

    private IEnumerator BeginGameRoutine()
    {
        Time.timeScale = 1f; // HARD RESET: ensure we never start a run paused

        if (titlePanel != null) titlePanel.SetActive(false);
        if (hudPanel != null) hudPanel.SetActive(true);

        if (menuBgFullBleed != null) menuBgFullBleed.SetActive(false);

        if (stopTitleMusicOnGameplayStart) StopTitleMusic();
        StartGameplayMusic();

        ResetShakeStateForNewRun();

        // enable roots
        if (worldRoot != null) worldRoot.SetActive(true);
        if (groundRoot != null) groundRoot.SetActive(true);
        if (spawningRoot != null) spawningRoot.SetActive(true);
        if (AudioSettingsManager.Instance != null)
            AudioSettingsManager.Instance.ApplySaved();

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(true);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(true);

        // re-enable shields
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        // hard-freeze before intro
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetPromptVisible(false);
        SetAuraVisible(false);

        // reset indices
        currentDeityIndex = Mathf.Clamp(currentDeityIndex, 0, Mathf.Max(0, deityProfiles.Count - 1));
        currentRoundWithinDeity = 1;
        currentOverallRoundIndex = 1;

        // initialize inherited baselines for deity #1
        inheritedMinSpawnDelay = initialMinSpawnDelay;
        inheritedMaxSpawnDelay = initialMaxSpawnDelay;
        inheritedBoltFallSpeed = initialBoltFallSpeed;
        inheritedZeusMoveSpeed = initialZeusMoveSpeed;
        inheritedZeusMinChangeTime = initialZeusMinChangeTime;
        inheritedZeusMaxChangeTime = initialZeusMaxChangeTime;

        // apply deity cosmetics + difficulty for Round 1
        ApplyDeityCosmetics(GetCurrentDeity());
        ApplyDifficultyForCurrentRound();

        BeginRoundTracking();

        runStartRealtime = Time.realtimeSinceStartup;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("run_start", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index", currentOverallRoundIndex },
            { "starting_shields", GetActiveShieldCount() }
        }, flush: true);

        // per-deity first-appearance intro
        yield return StartCoroutine(PlayDeityFirstAppearanceIntroIfNeeded());

        // deity round label (optional)
        yield return StartCoroutine(ShowRoundLabelIfEnabled());

        // countdown
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        // gate start: first grab starts the round
        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = true;

        SetAuraVisible(false);
        SetPromptVisible(true);
    }

    private IEnumerator PlayDeityFirstAppearanceIntroIfNeeded()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) yield break;

        if (currentRoundWithinDeity != 1) yield break;
        if (!dp.playIntroOnFirstRound) yield break;

        // Cache Zeus renderers so we can hide/show without breaking anything else
        SpriteRenderer[] zeusRenderers = null;
        if (zeusRoot != null)
        {
            zeusRenderers = zeusRoot.GetComponentsInChildren<SpriteRenderer>(true);
            foreach (var r in zeusRenderers)
                if (r != null) r.enabled = false;
        }

        // Prep float-in positions BEFORE Zeus becomes visible (prevents 1-frame pop)
        Vector3 end = Vector3.zero;
        Vector3 start = Vector3.zero;

        if (zeusRoot != null && dp.introFloatDuration > 0f)
        {
            end = zeusRoot.position;
            start = end;
            start.y += dp.introFloatYOffset;

            // Put Zeus at the start position while invisible
            zeusRoot.position = start;
        }

        // Beam rollout first (no Zeus visible)
        if (deityEntranceBeam != null && zeusRoot != null)
        {
            yield return StartCoroutine(deityEntranceBeam.RolloutIn(zeusRoot));
        }

        // Now Zeus can appear
        if (zeusRenderers != null)
        {
            foreach (var r in zeusRenderers)
                if (r != null) r.enabled = true;
        }

        // Float-in + entrance loop SFX
        if (zeusRoot != null && dp.introFloatDuration > 0f)
        {
            StartDeityEntranceLoopSfx();

            // start/end were already computed above (before Zeus was made visible)
            // zeusRoot is already at start while invisible, but re-asserting is harmless
            zeusRoot.position = start;

            float t = 0f;
            float dur = Mathf.Max(0.01f, dp.introFloatDuration);
            while (t < dur)
            {
                t += Time.unscaledDeltaTime;
                zeusRoot.position = Vector3.Lerp(start, end, t / dur);
                yield return null;
            }
            zeusRoot.position = end;

            StopDeityEntranceLoopSfx();
        }

        // Beam fades out once Zeus lands
        if (deityEntranceBeam != null)
        {
            yield return StartCoroutine(deityEntranceBeam.FadeOutAndHide());
        }

        // Intro phrase
        string msg = string.IsNullOrEmpty(dp.introText) ? tauntText : dp.introText;
        if (!string.IsNullOrEmpty(msg))
        {
            ShowCenterText(msg);

            // Play optional intro vocal (laugh/sting) WITHOUT delaying the text
            if (introVocalRoutine != null) StopCoroutine(introVocalRoutine);
            if (dp.introVocalClip != null && deityIntroVocalSource != null)
                introVocalRoutine = StartCoroutine(PlayDeityIntroVocalDelayed(dp));

            yield return new WaitForSecondsRealtime(Mathf.Max(0f, dp.introHoldTime));
            HideCenterText();
        }
    }

    private IEnumerator ShowRoundLabelIfEnabled()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) yield break;

        if (!dp.showRoundLabel) yield break;

        string msg = $"{dp.deityName} - Round {currentRoundWithinDeity}";

        Color original = centerText != null ? centerText.color : Color.white;

        // Tint just for the round label
        if (centerText != null)
            centerText.color = dp.roundLabelColor;

        ShowCenterText(msg);
        yield return new WaitForSecondsRealtime(dp.roundLabelHoldTime);
        HideCenterText();

        // Restore so other messages (taunts, grant lines, countdown) stay normal
        if (centerText != null)
            centerText.color = original;
    }

    private IEnumerator PlayCountdownOnlyRoutine()
    {
        PlayCountdownTick(0);
        ShowCenterText(countdown3);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        PlayCountdownTick(1);
        ShowCenterText(countdown2);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        PlayCountdownTick(2);
        ShowCenterText(countdown1);
        yield return new WaitForSecondsRealtime(countdownStepTime);

        PlayCountdownGo();
        ShowCenterText(goText);
        yield return new WaitForSecondsRealtime(goHoldTime);

        HideCenterText();
    }

    // -------------------- Round start gating --------------------
    private void SubscribeShieldDragSignals()
    {
        if (shieldDrag == null) return;

        shieldDrag.GrabStarted -= OnShieldGrabStarted;
        shieldDrag.GrabEnded -= OnShieldGrabEnded;

        shieldDrag.GrabStarted += OnShieldGrabStarted;
        shieldDrag.GrabEnded += OnShieldGrabEnded;
    }

    private void OnShieldGrabStarted()
    {
        SetAuraVisible(true);

        if (!waitingForFirstGrab || gameplayStarted || isGameOver) return;

        gameplayStarted = true;
        waitingForFirstGrab = false;

        SetPromptVisible(false);

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        roundStartRealtime = Time.realtimeSinceStartup;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("round_start", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "bolts_per_round", (boltSpawner != null ? boltSpawner.boltsPerRound : -1) },
            { "shields_remaining", GetActiveShieldCount() }
        });

        BeginRoundTracking();
        StartRound();
    }

    private void OnShieldGrabEnded()
    {
        SetAuraVisible(false);
    }

    // -------------------- Core round control --------------------
    public void StartRound()
    {
        if (isGameOver) return;
        if (boltSpawner != null) boltSpawner.StartRound();
    }

    private void BeginRoundTracking()
    {
        spawnedThisRound = 0;
        resolvedThisRound = 0;
        spawnerFinishedThisRound = false;
        nextSpawnId = 1;

        shieldsLostThisRound = 0;
    }

    private void TryHandleRoundComplete()
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        if (!spawnerFinishedThisRound) return;
        if (spawnedThisRound <= 0) return;
        if (resolvedThisRound < spawnedThisRound) return;

        spawnerFinishedThisRound = false;
        StartCoroutine(RoundCompleteSequence());
    }

    private IEnumerator RoundCompleteSequence()
    {
        // Freeze gameplay
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        float roundSeconds = Time.realtimeSinceStartup - roundStartRealtime;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("round_complete", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "round_seconds", Mathf.RoundToInt(roundSeconds) },
            { "shields_lost_this_round", shieldsLostThisRound }
        }, flush: true);

        // Snap Zeus + shields to center
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }
        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        // clear taunt (random pool) — skip on FINAL round because grant sequence is the payoff
        bool isFinalRoundOfThisDeity = (dp != null && currentRoundWithinDeity >= Mathf.Max(1, dp.roundsCount));
        if (!isFinalRoundOfThisDeity)
        {
            string taunt = GetRandomClearTaunt(dp);
            if (!string.IsNullOrEmpty(taunt))
            {
                ShowCenterText(taunt);
                yield return new WaitForSecondsRealtime(dp.clearTauntHoldTime);
                HideCenterText();
            }
        }

        // Advance round within deity
        currentRoundWithinDeity++;

        bool advancedToNewDeity = false;

        // If deity finished, advance deity and rebuild baselines
        if (dp != null && currentRoundWithinDeity > Mathf.Max(1, dp.roundsCount))
        {
            yield return StartCoroutine(PlayDeityPowerGrantSequenceIfAny(dp));

            int lastRoundWithin = Mathf.Max(1, dp.roundsCount);
            CacheEndOfDeityAsInherited(dp, lastRoundWithin);

            currentDeityIndex++;

            // Win if no more deities -> run complete screen + curtain call
            if (currentDeityIndex >= deityProfiles.Count)
            {
                HideCenterText();
                yield return StartCoroutine(RunCompleteSequence());
                yield break;
            }

            currentRoundWithinDeity = 1;
            advancedToNewDeity = true;

            ApplyDeityCosmetics(GetCurrentDeity());
            ResetShakeForNewDeity();
        }

        // Overall round always increments when we move to a new round
        currentOverallRoundIndex++;

        if (advancedToNewDeity)
        {
            yield return StartCoroutine(PlayDeityFirstAppearanceIntroIfNeeded());
        }

        yield return StartCoroutine(ShowRoundLabelIfEnabled());
        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        ApplyDifficultyForCurrentRound();

        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (shieldDrag != null) shieldDrag.enabled = true;
        if (zeusMover != null) zeusMover.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        BeginRoundTracking();
    }

    // -------------------- Difficulty / cosmetics --------------------
    private DeityProfile GetCurrentDeity()
    {
        if (deityProfiles == null || deityProfiles.Count == 0) return null;
        currentDeityIndex = Mathf.Clamp(currentDeityIndex, 0, deityProfiles.Count - 1);
        return deityProfiles[currentDeityIndex];
    }

    private void ApplyDeityCosmetics(DeityProfile dp)
    {
        if (dp == null) return;

        CacheDeityVisualRendererIfNeeded();

        if (dp.deitySprite != null && deityVisualRenderer != null)
            deityVisualRenderer.sprite = dp.deitySprite;

        if (dp.deitySprite != null && deitySpriteImage != null)
            deitySpriteImage.sprite = dp.deitySprite;

        if (dp.deitySprite != null && deitySpriteRenderer != null)
            deitySpriteRenderer.sprite = dp.deitySprite;

        if (bgGradientImage != null)
            bgGradientImage.color = dp.bgGradientTint;

        if (bgGradientSpriteRenderer != null)
            bgGradientSpriteRenderer.color = dp.bgGradientTint;

        if (boltSpawner != null && dp.projectilePrefab != null)
            boltSpawner.SetBoltPrefab(dp.projectilePrefab);
    }

    private void ApplyDifficultyForCurrentRound()
    {
        DeityProfile dp = GetCurrentDeity();
        if (dp == null) return;

        float baseMinDelay = dp.overrideBaselineMinSpawnDelay ? dp.baselineMinSpawnDelay : inheritedMinSpawnDelay;
        float baseMaxDelay = dp.overrideBaselineMaxSpawnDelay ? dp.baselineMaxSpawnDelay : inheritedMaxSpawnDelay;
        float baseFall = dp.overrideBaselineBoltFallSpeed ? dp.baselineBoltFallSpeed : inheritedBoltFallSpeed;
        float baseMove = dp.overrideBaselineZeusMoveSpeed ? dp.baselineZeusMoveSpeed : inheritedZeusMoveSpeed;
        float baseMinT = dp.overrideBaselineZeusMinChangeTime ? dp.baselineZeusMinChangeTime : inheritedZeusMinChangeTime;
        float baseMaxT = dp.overrideBaselineZeusMaxChangeTime ? dp.baselineZeusMaxChangeTime : inheritedZeusMaxChangeTime;

        float spine = 1.0f + (currentRoundWithinDeity - 1) * dp.spineIncrementPerRound;

        float delayScale = Mathf.Pow(spine, Mathf.Max(0f, dp.spawnDelayWeight));
        float fallScale = Mathf.Pow(spine, Mathf.Max(0f, dp.boltFallSpeedWeight));
        float moveScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusMoveSpeedWeight));
        float changeScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusChangeTimeWeight));

        int bolts = Mathf.Max(1, dp.boltsPerRound);

        float minD = Mathf.Max(minAllowedDelay, baseMinDelay / delayScale);
        float maxD = Mathf.Max(minAllowedDelay, baseMaxDelay / delayScale);
        if (maxD < minD) maxD = minD;

        float fall = baseFall * fallScale;

        float zeusSpeed = baseMove * moveScale;
        float minCT = Mathf.Max(minAllowedChangeTime, baseMinT / changeScale);
        float maxCT = Mathf.Max(minAllowedChangeTime, baseMaxT / changeScale);

        if (boltSpawner != null)
        {
            boltSpawner.boltsPerRound = bolts;
            boltSpawner.minSpawnDelay = minD;
            boltSpawner.maxSpawnDelay = maxD;
            boltSpawner.boltFallSpeed = fall;
        }

        if (zeusMover != null)
        {
            zeusMover.moveSpeed = zeusSpeed;
            zeusMover.minChangeTime = Mathf.Min(minCT, maxCT);
            zeusMover.maxChangeTime = Mathf.Max(minCT, maxCT);
        }

        UpdateShakeAvailabilityForOverallRound(currentOverallRoundIndex);
    }

    private void CacheEndOfDeityAsInherited(DeityProfile dp, int lastRoundWithinDeity)
    {
        if (dp == null) return;

        float baseMinDelay = dp.overrideBaselineMinSpawnDelay ? dp.baselineMinSpawnDelay : inheritedMinSpawnDelay;
        float baseMaxDelay = dp.overrideBaselineMaxSpawnDelay ? dp.baselineMaxSpawnDelay : inheritedMaxSpawnDelay;
        float baseFall = dp.overrideBaselineBoltFallSpeed ? dp.baselineBoltFallSpeed : inheritedBoltFallSpeed;
        float baseMove = dp.overrideBaselineZeusMoveSpeed ? dp.baselineZeusMoveSpeed : inheritedZeusMoveSpeed;
        float baseMinT = dp.overrideBaselineZeusMinChangeTime ? dp.baselineZeusMinChangeTime : inheritedZeusMinChangeTime;
        float baseMaxT = dp.overrideBaselineZeusMaxChangeTime ? dp.baselineZeusMaxChangeTime : inheritedZeusMaxChangeTime;

        float spine = 1.0f + (lastRoundWithinDeity - 1) * dp.spineIncrementPerRound;

        float delayScale = Mathf.Pow(spine, Mathf.Max(0f, dp.spawnDelayWeight));
        float fallScale = Mathf.Pow(spine, Mathf.Max(0f, dp.boltFallSpeedWeight));
        float moveScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusMoveSpeedWeight));
        float changeScale = Mathf.Pow(spine, Mathf.Max(0f, dp.zeusChangeTimeWeight));

        inheritedMinSpawnDelay = Mathf.Max(minAllowedDelay, baseMinDelay / delayScale);
        inheritedMaxSpawnDelay = Mathf.Max(minAllowedDelay, baseMaxDelay / delayScale);
        if (inheritedMaxSpawnDelay < inheritedMinSpawnDelay) inheritedMaxSpawnDelay = inheritedMinSpawnDelay;

        inheritedBoltFallSpeed = baseFall * fallScale;
        inheritedZeusMoveSpeed = baseMove * moveScale;

        inheritedZeusMinChangeTime = Mathf.Max(minAllowedChangeTime, baseMinT / changeScale);
        inheritedZeusMaxChangeTime = Mathf.Max(minAllowedChangeTime, baseMaxT / changeScale);
        if (inheritedZeusMaxChangeTime < inheritedZeusMinChangeTime) inheritedZeusMaxChangeTime = inheritedZeusMinChangeTime;
    }

    // -------------------- Life loss / Game over --------------------
    public void OnBoltHitGround(Bolt groundBolt)
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        StartCoroutine(LifeLostSequence(groundBolt));
    }

    private IEnumerator LifeLostSequence(Bolt groundBolt)
    {
        inLossSequence = true;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("life_lost", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "round_within_deity", currentRoundWithinDeity },
            { "overall_round_index", currentOverallRoundIndex },
            { "cause", "bolt_hit_ground" },
            { "shields_before_loss", GetActiveShieldCount() }
        }, flush: true);

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        SetAuraVisible(false);
        SetPromptVisible(false);

        // freeze bolts
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else activeBolts[i].FreezeBolt();
        }

        // Ground-hit bolt: local flash + local SFX + explode
        if (groundBolt != null)
        {
            yield return StartCoroutine(FlashBoltLocalOnce(groundBolt));
            PlayFailPopSfx();
            groundBolt.Explode();
        }

        yield return new WaitForSecondsRealtime(firstBoomHold);

        // pop remaining bottom->top
        List<Bolt> snapshot = activeBolts
            .Where(b => b != null)
            .OrderBy(b => b.transform.position.y)
            .ThenBy(b => b.spawnId)
            .ToList();

        for (int i = 0; i < snapshot.Count; i++)
        {
            Bolt b = snapshot[i];
            if (b == null) continue;

            bool isFinal = (i == snapshot.Count - 1);

            // Local flash + local SFX
            yield return StartCoroutine(FlashBoltLocalOnce(b));
            PlayFailPopSfx();

            // Final pop: big screen FX + big sound
            if (isFinal)
                TriggerFinalPopScreenFX();

            b.Explode();
            yield return new WaitForSecondsRealtime(popInterval);
        }

        activeBolts.RemoveAll(b => b == null);

        // Shield penalty: calm blink-vanish after the drama
        GameObject shieldToLose = FindFirstActiveShield();

        if (shieldToLose == null)
        {
            HandleGameOver();
            inLossSequence = false;

            if (autoRestartAfterGameOver)
            {
                yield return new WaitForSecondsRealtime(gameOverRestartDelay);
                RestartFromGameOver();
            }

            yield break;
        }

        // Small beat so the shield penalty reads AFTER the big flash
        if (shieldBlinkDelaySeconds > 0f)
            yield return new WaitForSecondsRealtime(shieldBlinkDelaySeconds);

        // Count it as lost (analytics/round stats)
        // NOTE: If your RemoveOneShield() disables the shield, DO NOT call it here.
        // Use the line below instead.
        // shieldsLostThisRound++;

        RemoveOneShield();

        // Blink + disable
        yield return StartCoroutine(BlinkThenDisableShield(shieldToLose));

        if (AreAllShieldsGone())
        {
            HandleGameOver();
            inLossSequence = false;

            if (autoRestartAfterGameOver)
            {
                yield return new WaitForSecondsRealtime(gameOverRestartDelay);
                RestartFromGameOver();
            }

            yield break;
        }

        // reset X positions
        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }
        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        yield return new WaitForSecondsRealtime(resetDelay);

        yield return StartCoroutine(PlayCountdownOnlyRoutine());

        ApplyDifficultyForCurrentRound();
        BeginRoundTracking();

        SubscribeShieldDragSignals();
        gameplayStarted = false;
        waitingForFirstGrab = true;

        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = true;

        SetPromptVisible(false);
        SetAuraVisible(false);

        inLossSequence = false;
    }

    private bool RemoveOneShield()
    {
        // NEW behavior: we only count the loss here.
        // The actual visual “blink vanish” + deactivation is handled in LifeLostSequence.
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0) return false;

        GameObject s = FindFirstActiveShield();
        if (s == null) return false;

        shieldsLostThisRound++;
        return true;
    }

    private bool AreAllShieldsGone()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0) return true;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf) return false;
        }
        return true;
    }

    private void HandleGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        float runSeconds = Time.realtimeSinceStartup - runStartRealtime;

        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("run_end", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index_reached", currentOverallRoundIndex },
            { "run_seconds", Mathf.RoundToInt(runSeconds) }
        }, flush: true);

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        StartCoroutine(GameOverRoutine());
    }

    private IEnumerator GameOverRoutine()
    {
        // clear bolts
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else
            {
                activeBolts[i].FreezeBolt();
                activeBolts[i].Explode();
            }
        }
        activeBolts.RemoveAll(b => b == null);

        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        if (!string.IsNullOrEmpty(gameOverTauntText))
        {
            ShowCenterText(gameOverTauntText);
            yield return new WaitForSecondsRealtime(gameOverTauntHoldTime);
        }

        ShowCenterText(gameOverText);
        yield return new WaitForSecondsRealtime(gameOverHoldTime);

        HideCenterText();
        ReturnToTitleScreenAndReset();
    }

    private void ReturnToTitleScreenAndReset()
    {
        Time.timeScale = 1f;

        if (titlePanel != null) titlePanel.SetActive(true);
        if (hudPanel != null) hudPanel.SetActive(false);

        if (menuBgFullBleed != null) menuBgFullBleed.SetActive(true);

        StopRunCompleteMusic();

        StopGameplayMusic();
        if (resumeTitleMusicOnReturnToTitle) StartTitleMusic();

        if (spawningRoot != null) spawningRoot.SetActive(false);
        if (groundRoot != null) groundRoot.SetActive(false);
        if (worldRoot != null) worldRoot.SetActive(false);

        if (shieldStackRoot != null) shieldStackRoot.gameObject.SetActive(false);
        if (zeusRoot != null) zeusRoot.gameObject.SetActive(false);

        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        waitingForFirstGrab = false;
        gameplayStarted = false;

        SetAuraVisible(false);
        SetPromptVisible(false);
        HideCenterText();

        inLossSequence = false;
        isGameOver = false;

        currentDeityIndex = 0;
        currentRoundWithinDeity = 1;
        currentOverallRoundIndex = 1;

        inheritedMinSpawnDelay = initialMinSpawnDelay;
        inheritedMaxSpawnDelay = initialMaxSpawnDelay;
        inheritedBoltFallSpeed = initialBoltFallSpeed;
        inheritedZeusMoveSpeed = initialZeusMoveSpeed;
        inheritedZeusMinChangeTime = initialZeusMinChangeTime;
        inheritedZeusMaxChangeTime = initialZeusMaxChangeTime;

        ResetShakeStateForNewRun();
        BeginRoundTracking();
    }

    private void RestartFromGameOver()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop != null)
        {
            foreach (var s in shieldsBottomToTop)
                if (s != null) s.SetActive(true);
        }

        if (zeusRoot != null)
        {
            Vector3 zp = zeusRoot.position;
            zp.x = 0f;
            zeusRoot.position = zp;
        }

        if (shieldStackRoot != null)
        {
            Vector3 sp = shieldStackRoot.position;
            sp.x = 0f;
            shieldStackRoot.position = sp;
        }

        isGameOver = false;

        if (zeusMover != null) zeusMover.enabled = true;
        if (shieldDrag != null) shieldDrag.enabled = true;

        StartRound();
    }

    // -------------------- Center text helpers --------------------
    private void ShowCenterText(string msg)
    {
        if (centerText == null) return;
        centerText.gameObject.SetActive(true);
        centerText.text = msg;
    }

    private void HideCenterText()
    {
        if (centerText == null) return;
        centerText.text = "";
        centerText.gameObject.SetActive(false);
    }

    public void ShowRunCompleteScreen(int roundsCleared, int shieldsRemaining, float runSeconds)
    {
        if (runCompletePanel != null) runCompletePanel.SetActive(true);

        if (menuBgFullBleed != null) menuBgFullBleed.SetActive(true);

        // Default header copy (you can change later)
        if (trialCompleteText != null)
        {
            trialCompleteText.text = "TRIAL\nCOMPLETE";
            trialCompleteText.gameObject.SetActive(false); // stage starts blank
        }

        if (runStatsText != null)
        {
            runStatsText.text =
                "RUN STATS\n\n" +
                $"Rounds Cleared: {roundsCleared}\n\n" +
                $"Shields Remaining: {shieldsRemaining}\n\n" +
                $"Time: {FormatTime(runSeconds)}";
        }

        // IMPORTANT: do NOT show "tap anywhere" until curtain call is over
        if (continueText != null)
        {
            continueText.gameObject.SetActive(false);
            continueText.text = runCompleteTapText;
        }
        if (cameoNameText != null)
        {
            cameoNameText.text = "";
            cameoNameText.gameObject.SetActive(false);
        }
    }

    public void SetRunCompleteContinueVisible(bool visible)
    {
        if (continueText == null) return;
        continueText.text = runCompleteTapText;
        continueText.gameObject.SetActive(visible);
    }



    private IEnumerator RunCompleteSequence()
    {
        // Freeze gameplay hard
        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        if (stopGameplayMusicOnRunComplete) StopGameplayMusic();
        StartRunCompleteMusic();

        SetAuraVisible(false);
        SetPromptVisible(false);

        // Clear active bolts safely
        for (int i = activeBolts.Count - 1; i >= 0; i--)
        {
            if (activeBolts[i] == null) activeBolts.RemoveAt(i);
            else
            {
                activeBolts[i].FreezeBolt();
                activeBolts[i].Explode();
            }
        }
        activeBolts.RemoveAll(b => b == null);

        // Stats
        float runSeconds = Time.realtimeSinceStartup - runStartRealtime;
        int shieldsRemaining = GetActiveShieldCount();

        // NOTE: we track overall round index as 1-based current round.
        // At end-of-run, currentOverallRoundIndex is already the "next" index in some flows.
        // For display, we’ll clamp to at least 1.
        int roundsCleared = Mathf.Max(1, currentOverallRoundIndex);

        ShowRunCompleteScreen(roundsCleared, shieldsRemaining, runSeconds);

        // Make sure the stage is blank before blink + cameos
        if (cameoDeityImage != null)
            cameoDeityImage.gameObject.SetActive(false);

        // CTA hidden until the end
        SetRunCompleteContinueVisible(false);
        awaitingRunCompleteTap = false;

        // TRIAL COMPLETE blink beat
        yield return StartCoroutine(BlinkTrialComplete());

        // Curtain call begins AFTER blink
        yield return StartCoroutine(PlayCurtainCallReverseOrder());

        // Now allow tap-anywhere
        SetRunCompleteContinueVisible(true);
        awaitingRunCompleteTap = true;
    }

    private IEnumerator PlayCurtainCallReverseOrder()
    {
        if (cameoDeityImage == null || cameoStartAnchor == null || cameoEndAnchor == null)
            yield break;

        if (deityProfiles == null || deityProfiles.Count == 0)
            yield break;

        // Ensure image is visible and reset state
        cameoDeityImage.gameObject.SetActive(true);
        Color baseColor = cameoDeityImage.color;
        baseColor.a = 1f;
        cameoDeityImage.color = baseColor;

        // Reverse order: last -> first
        for (int i = deityProfiles.Count - 1; i >= 0; i--)
        {
            DeityProfile dp = deityProfiles[i];
            if (dp == null || dp.deitySprite == null) continue;

            yield return StartCoroutine(PlayOneDeityCameo(dp));
        }

        // Hide image at end
        cameoDeityImage.gameObject.SetActive(false);
    }

    private IEnumerator PlayOneDeityCameo(DeityProfile dp)
    {
        // 1) Set sprite + start position
        cameoDeityImage.sprite = dp.deitySprite;

        RectTransform imgRt = cameoDeityImage.rectTransform;
        imgRt.anchoredPosition = cameoStartAnchor.anchoredPosition;

        if (cameoNameText != null)
        {
            cameoNameText.text = dp.deityName.ToUpperInvariant();
            cameoNameText.gameObject.SetActive(true);
        }

        // Fully visible
        Color c = cameoDeityImage.color;
        c.a = 1f;
        cameoDeityImage.color = c;

        // 2) Float down
        float dur = Mathf.Max(0.01f, cameoFloatSeconds);
        float t = 0f;
        Vector2 start = cameoStartAnchor.anchoredPosition;
        Vector2 end = cameoEndAnchor.anchoredPosition;

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / dur);
            imgRt.anchoredPosition = Vector2.Lerp(start, end, a);
            yield return null;
        }
        imgRt.anchoredPosition = end;

        if (cameoNameText != null)
        {
            cameoNameText.gameObject.SetActive(false);
        }

        // 3) Land hold
        if (cameoLandHoldSeconds > 0f)
            yield return new WaitForSecondsRealtime(cameoLandHoldSeconds);

        // 4) Signature shot (simple UI fly + flash)
        yield return StartCoroutine(PlayProjectileRainExit(dp));

        // 5) Vanish (fade out)
        float vd = Mathf.Max(0.01f, cameoVanishSeconds);
        t = 0f;
        float startA = cameoDeityImage.color.a;

        while (t < vd)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / vd);
            Color cc = cameoDeityImage.color;
            cc.a = Mathf.Lerp(startA, 0f, a);
            cameoDeityImage.color = cc;
            yield return null;
        }

        Color final = cameoDeityImage.color;
        final.a = 0f;
        cameoDeityImage.color = final;

        // Small beat between deities
        yield return new WaitForSecondsRealtime(0.10f);
    }

    private IEnumerator PlayProjectileRainExit(DeityProfile dp)
    {
        if (dp == null) yield break;
        if (cameoDeityImage == null) yield break;
        if (impactLineAnchor == null) yield break;
        if (cameoVfxRoot == null) yield break;

        SpriteRenderer projSr = TryGetProjectileSpriteRenderer(dp);
        Sprite projectileSprite = (projSr != null) ? projSr.sprite : null;

        if (projectileSprite == null)
            projectileSprite = dp.deitySprite; // safe fallback

        Vector2 projSize = new Vector2(rainProjectileSize, rainProjectileSize);

        if (rainAutoSizeFromWorld && projectileSprite != null)
        {
            projSize = ComputeUiSizeDeltaFromWorldSprite(projectileSprite, projSr, cameoVfxRoot);
            projSize *= Mathf.Max(0.01f, rainWorldToUiScale);
        }

        // Per-deity art-direction knob (ex: Aphrodite hearts)
        projSize *= Mathf.Max(0.01f, dp.runCompleteRainSizeMultiplier);

        // Rotation: use prefab SpriteRenderer transform Z (ex: bolt 60°)
        float projZ = 0f;
        if (dp.runCompleteRainUsePrefabRotation && projSr != null)
            projZ = projSr.transform.eulerAngles.z;

        projZ += dp.runCompleteRainRotationOffset;
        Quaternion projRot = Quaternion.Euler(0f, 0f, projZ);

    

        RectTransform parent = cameoVfxRoot;
        if (parent == null) yield break;

        Vector2 startPos = cameoDeityImage.rectTransform.anchoredPosition;

        if (dp.runCompleteRainUseGrantOrigin && dp.grantWorldOrigin != null)
        {
            if (TryWorldToUiLocal(dp.grantWorldOrigin.position, cameoVfxRoot, out Vector2 handLocal))
                startPos = handLocal;
        }

        startPos += dp.runCompleteRainUiOffset;

        // Impact Y comes from the anchor; X will be near deity X with jitter
        float impactY = impactLineAnchor.anchoredPosition.y;

        int count = Mathf.Clamp(rainCount, 1, 60);
        float stagger = Mathf.Max(0f, rainStaggerSeconds);

        PlayRainVolleyStartSfx(dp);

        for (int i = 0; i < count; i++)
        {
            // Start at deity center (optionally with tiny jitter so it reads as multiple)
            float jitter = (rainXJitter <= 0f) ? 0f : Random.Range(-rainXJitter, rainXJitter);
            Vector2 s = new Vector2(startPos.x + jitter, startPos.y);

            // End at same X, fixed impact line Y
            Vector2 e = new Vector2(s.x, impactY);

            // Fire-and-forget projectile travel + impact burst
            StartCoroutine(SpawnAndTravelUiProjectile(projectileSprite, parent, s, e, projSize, projRot));

            if (stagger > 0f)
                yield return new WaitForSecondsRealtime(stagger);
        }

        // Give the last projectile time to reach the impact line before we vanish the deity
        yield return new WaitForSecondsRealtime(Mathf.Max(0.01f, rainTravelSeconds + 0.05f));
    }

    private IEnumerator SpawnAndTravelUiProjectile(Sprite sprite, RectTransform parent, Vector2 start, Vector2 end, Vector2 sizeDelta, Quaternion rotation)
    {
        // Create projectile image
        GameObject go = new GameObject("RainProjectile", typeof(RectTransform), typeof(Image));
        RectTransform rt = go.GetComponent<RectTransform>();
        Image img = go.GetComponent<Image>();

        rt.SetParent(parent, worldPositionStays: false);
        rt.SetAsLastSibling();

        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.localScale = Vector3.one;
        rt.localRotation = rotation;

        img.sprite = sprite;
        img.color = Color.white;
        img.preserveAspect = true;
        img.raycastTarget = false;

        rt.sizeDelta = new Vector2(Mathf.Max(1f, sizeDelta.x), Mathf.Max(1f, sizeDelta.y));

        rt.anchoredPosition = start;

        // Travel
        float dur = Mathf.Max(0.01f, rainTravelSeconds);
        float t = 0f;

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / dur);
            rt.anchoredPosition = Vector2.Lerp(start, end, a);
            yield return null;
        }

        rt.anchoredPosition = end;

        // Impact: spawn shrapnel burst (UI)
        SpawnUiShrapnelBurst(parent, end);

        Destroy(go);
    }

    private void SpawnUiShrapnelBurst(RectTransform parent, Vector2 impactPos)
    {
        if (parent == null) return;

        PlayRunCompleteImpactSfx();

        int n = Mathf.Clamp(shrapnelFragments, 1, 60);
        float life = Mathf.Max(0.05f, shrapnelLifetimeSeconds);
        float speed = Mathf.Max(10f, shrapnelSpeed);
        float size = Mathf.Max(1f, shrapnelFragmentSize);

        // We’ll spawn simple white squares (fast + readable). You can swap to a sprite later.
        for (int i = 0; i < n; i++)
        {
            GameObject go = new GameObject("ShrapnelFrag", typeof(RectTransform), typeof(Image));
            RectTransform rt = go.GetComponent<RectTransform>();
            Image img = go.GetComponent<Image>();

            rt.SetParent(parent, worldPositionStays: false);
            rt.SetAsLastSibling();

            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.localScale = Vector3.one;

            img.color = Color.white;
            img.raycastTarget = false;

            rt.sizeDelta = new Vector2(size, size);
            rt.anchoredPosition = impactPos;

            Vector2 dir = RandomUpwardDirection(shrapnelUpConeDegrees);
            StartCoroutine(AnimateUiFragment(rt, img, dir * speed, life));
        }
    }

    private Vector2 RandomUpwardDirection(float upConeDegrees)
    {
        float deg = Mathf.Clamp(upConeDegrees, 0f, 180f);

        if (deg <= 0.01f)
        {
            float angRad = Random.Range(0f, 360f) * Mathf.Deg2Rad;
            return new Vector2(Mathf.Cos(angRad), Mathf.Sin(angRad));
        }

        // Centered around straight up (90°), spread +/- (deg/2)
        float half = deg * 0.5f;
        float angDeg = 90f + Random.Range(-half, half);
        float angRad2 = angDeg * Mathf.Deg2Rad;

        return new Vector2(Mathf.Cos(angRad2), Mathf.Sin(angRad2)).normalized;
    }

    private IEnumerator AnimateUiFragment(RectTransform rt, Image img, Vector2 velocity, float lifetime)
    {
        float t = 0f;
        Color c = img.color;

        while (t < lifetime)
        {
            t += Time.unscaledDeltaTime;

            // Move
            rt.anchoredPosition += velocity * Time.unscaledDeltaTime;

            // Fade out
            float a = 1f - Mathf.Clamp01(t / lifetime);
            c.a = a;
            img.color = c;

            yield return null;
        }

        Destroy(rt.gameObject);
    }

    private SpriteRenderer TryGetProjectileSpriteRenderer(DeityProfile dp)
    {
        if (dp == null) return null;
        if (dp.projectilePrefab == null) return null;

        SpriteRenderer sr = dp.projectilePrefab.GetComponent<SpriteRenderer>();
        if (sr == null)
            sr = dp.projectilePrefab.GetComponentInChildren<SpriteRenderer>(true);

        return sr;
    }

    private Sprite TryGetProjectileSprite(DeityProfile dp)
    {
        SpriteRenderer sr = TryGetProjectileSpriteRenderer(dp);
        return (sr != null) ? sr.sprite : null;
    }

    public void HideRunCompleteScreen()
    {
        if (runCompletePanel != null) runCompletePanel.SetActive(false);
    }

    private string FormatTime(float seconds)
    {
        seconds = Mathf.Max(0f, seconds);
        int s = Mathf.RoundToInt(seconds);
        int m = s / 60;
        int r = s % 60;
        return $"{m:00}:{r:00}";
    }

    private int GetActiveShieldCount()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null) return 0;

        int count = 0;
        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            var s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf) count++;
        }
        return count;
    }

    private string GetRandomClearTaunt(DeityProfile dp)
    {
        if (dp == null) return "";

        // Prefer pool if provided
        if (dp.clearTauntPool != null && dp.clearTauntPool.Length > 0)
        {
            int count = dp.clearTauntPool.Length;

            int last = -1;
            lastClearTauntIndexByDeity.TryGetValue(dp, out last);

            int idx = Random.Range(0, count);

            // Avoid repeating the same taunt back-to-back when possible
            if (count > 1)
            {
                int guard = 0;
                while (idx == last && guard < 10)
                {
                    idx = Random.Range(0, count);
                    guard++;
                }
            }

            lastClearTauntIndexByDeity[dp] = idx;

            string pick = dp.clearTauntPool[idx];
            return string.IsNullOrEmpty(pick) ? "" : pick.Trim();
        }

        // Fallback single taunt
        return string.IsNullOrEmpty(dp.clearTauntText) ? "" : dp.clearTauntText.Trim();
    }

    // -------------------- Shake the Heavens --------------------
    private void SetShakeIconLit(bool lit)
    {
        if (shakeIcon == null) return;

        Color c = shakeIcon.color;

        // Hide completely until granted this run
        if (!shakeUnlockedThisRun)
            c.a = 0f;
        else
            c.a = lit ? shakeIconLitAlpha : shakeIconDimAlpha;

        shakeIcon.color = c;
    }

    private void UpdateShakeAvailabilityForOverallRound(int overallRoundIndex)
    {
        // NOTE: overallRoundIndex is no longer used for unlock.
        // Unlock is granted by finishing a deity (via DeityProfile.grantedPower).
        shakeAvailable = shakeUnlockedThisRun && (!shakeUsed);
        SetShakeIconLit(shakeAvailable);
    }

    private void ResetShakeStateForNewRun()
    {
        shakeUnlockedThisRun = false;

        shakeAvailable = false;
        shakeUsed = false;
        SetShakeIconLit(false);

        if (boltSpawner != null)
            boltSpawner.SetPaused(false);
    }

    public void Debug_OnShakeTheHeavensTriggered()
    {
        if (isGameOver) return;
        if (inLossSequence) return;
        if (!shakeAvailable) return;
        if (shakeUsed) return;

        // ---- Analytics: STH used (counts bolts cleared right now) ----
        var dp = GetCurrentDeity();
        UGSAnalyticsManager.RecordEvent("sth_used", new Dictionary<string, object>
        {
            { "deity", dp != null ? dp.deityName : "unknown" },
            { "overall_round_index", currentOverallRoundIndex },
            { "bolts_cleared", activeBolts.Count }
        }, flush: true);

        shakeUsed = true;
        shakeAvailable = false;
        SetShakeIconLit(false);

        if (sthRoutine != null) StopCoroutine(sthRoutine);
        sthRoutine = StartCoroutine(ShakeTheHeavensRoutine());
    }

    private IEnumerator ShakeTheHeavensRoutine()
    {
        if (boltSpawner != null) boltSpawner.SetPaused(true);
        if (zeusMover != null) zeusMover.enabled = false;

        List<Bolt> snapshot = activeBolts.Where(b => b != null).ToList();
        for (int i = 0; i < snapshot.Count; i++)
        {
            Bolt b = snapshot[i];
            if (b == null) continue;
            b.Explode();
        }

        activeBolts.RemoveAll(b => b == null);

        yield return new WaitForSecondsRealtime(sthStunDuration);

        if (!isGameOver && !inLossSequence)
        {
            if (boltSpawner != null) boltSpawner.SetPaused(false);

            if (zeusMover != null && gameplayStarted && !waitingForFirstGrab)
                zeusMover.enabled = true;
        }

        sthRoutine = null;
    }

    private void ResetShakeForNewDeity()
    {
        // New deity = re-arm the power (if it has been unlocked this run)
        shakeUsed = false;

        shakeAvailable = shakeUnlockedThisRun && (!shakeUsed);
        SetShakeIconLit(shakeAvailable);

        if (boltSpawner != null)
            boltSpawner.SetPaused(false);
    }

    private IEnumerator PlayDeityPowerGrantSequenceIfAny(DeityProfile dp)
    {
        if (dp == null) yield break;
        if (dp.grantedPower == DeityGrantedPower.None) yield break;

        // 1) Grant line(s) (one line at a time)
        yield return StartCoroutine(ShowCenterTextLines(dp.grantText, dp.grantHoldTime));

        // 2) Fly icon from deity hand -> slot
        yield return StartCoroutine(FlyGrantedPowerIconToSlot(dp));

        // 3) Actually unlock + light icon + punch + optional SFX
        ApplyGrantedPower(dp);
        yield return StartCoroutine(PunchShakeIcon(dp.grantIconPunchScale));

        // 4) How-to line(s) (one line at a time)
        yield return StartCoroutine(ShowCenterTextLines(dp.grantHowToText, dp.grantHowToHoldTime));
    }

    private void ApplyGrantedPower(DeityProfile dp)
    {
        if (dp == null) return;

        // Optional SFX (reward hit)
        if (sharedSfxSource != null && dp.grantSfx != null)
            sharedSfxSource.PlayOneShot(dp.grantSfx, dp.grantSfxVolume);

        if (dp.grantedPower == DeityGrantedPower.ShakeTheHeavens)
        {
            // Unlock for the rest of this run
            shakeUnlockedThisRun = true;

            // When granted, it should immediately be ready to use
            shakeUsed = false;
            shakeAvailable = true;
            SetShakeIconLit(true);
        }
    }

    private IEnumerator FlyGrantedPowerIconToSlot(DeityProfile dp)
    {
        if (dp == null) yield break;
        if (dp.grantWorldOrigin == null) yield break;
        if (shakeIcon == null) yield break;

        // World camera for hand -> screen
        Camera worldCam = Camera.main;
        if (worldCam == null)
            worldCam = FindObjectOfType<Camera>();

        if (worldCam == null) yield break;

        // UI canvas/camera
        Canvas uiCanvas = shakeIcon.GetComponentInParent<Canvas>();
        if (uiCanvas == null) yield break;

        Camera uiCam = (uiCanvas.renderMode == RenderMode.ScreenSpaceOverlay) ? null : uiCanvas.worldCamera;

        RectTransform parent = (powerFlyParent != null) ? powerFlyParent : (shakeIcon.rectTransform.parent as RectTransform);
        if (parent == null) yield break;

        RectTransform slotRt = shakeIcon.rectTransform;

        // Create a temporary UI Image to fly
        GameObject go = new GameObject("PowerFlyIcon", typeof(RectTransform), typeof(UnityEngine.UI.Image));
        RectTransform rt = go.GetComponent<RectTransform>();
        UnityEngine.UI.Image img = go.GetComponent<UnityEngine.UI.Image>();

        rt.SetParent(parent, worldPositionStays: false);
        rt.SetAsLastSibling();

        // Make sure anchored positioning behaves predictably
        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.localScale = Vector3.one;

        img.sprite = shakeIcon.sprite; // grant uses the shake icon sprite
        img.color = Color.white;       // full alpha regardless of slot dimming
        img.preserveAspect = true;
        img.raycastTarget = false;

        // Match slot size
        rt.sizeDelta = slotRt.rect.size;

        // Compute start/end in the PARENT rect's local space
        Vector3 startScreen = worldCam.WorldToScreenPoint(dp.grantWorldOrigin.position);
        Vector3 endScreen = RectTransformUtility.WorldToScreenPoint(uiCam, slotRt.position);

        Vector2 startLocal;
        Vector2 endLocal;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(parent, startScreen, uiCam, out startLocal);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(parent, endScreen, uiCam, out endLocal);

        rt.anchoredPosition = startLocal;

        float dur = Mathf.Max(0.01f, dp.grantIconFlySeconds);
        float t = 0f;

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / dur);
            rt.anchoredPosition = Vector2.Lerp(startLocal, endLocal, a);
            yield return null;
        }

        rt.anchoredPosition = endLocal;

        Destroy(go);
    }

    private IEnumerator PunchShakeIcon(float punchScale)
    {
        if (shakeIcon == null) yield break;

        RectTransform rt = shakeIcon.rectTransform;
        if (rt == null) yield break;

        Vector3 baseScale = rt.localScale;
        Vector3 targetScale = baseScale * Mathf.Max(1f, punchScale);

        const float upTime = 0.10f;
        const float downTime = 0.14f;

        float t = 0f;
        while (t < upTime)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / upTime);
            rt.localScale = Vector3.Lerp(baseScale, targetScale, a);
            yield return null;
        }

        t = 0f;
        while (t < downTime)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / downTime);
            rt.localScale = Vector3.Lerp(targetScale, baseScale, a);
            yield return null;
        }

        rt.localScale = baseScale;
    }

    private IEnumerator ShowCenterTextLines(string textBlock, float perLineHoldSeconds)
    {
        if (string.IsNullOrEmpty(textBlock)) yield break;

        string[] lines = textBlock.Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i].Trim();
            if (string.IsNullOrEmpty(line)) continue;

            ShowCenterText(line);
            yield return new WaitForSecondsRealtime(Mathf.Max(0.01f, perLineHoldSeconds));
        }

        HideCenterText();
    }

    private void CacheDeityVisualRendererIfNeeded()
    {
        if (deityVisualRenderer != null) return;

        if (deityVisualRoot != null)
        {
            deityVisualRenderer = deityVisualRoot.GetComponent<SpriteRenderer>();
            return;
        }

        if (zeusRoot != null)
        {
            Transform t = zeusRoot.Find(deityVisualChildName);
            if (t != null)
            {
                deityVisualRenderer = t.GetComponent<SpriteRenderer>();
                if (deityVisualRenderer != null) return;
            }

            deityVisualRenderer = zeusRoot.GetComponentInChildren<SpriteRenderer>(true);
        }
    }

    public void UI_QuitToTitle()
    {
        Time.timeScale = 1f;

        if (boltSpawner != null) boltSpawner.StopRound();
        if (zeusMover != null) zeusMover.enabled = false;
        if (shieldDrag != null) shieldDrag.enabled = false;

        StopRunCompleteMusic();

        ReturnToTitleScreenAndReset();
    }

    // -------------------- SFX helper --------------------
    private void PlayFailPopSfx()
    {
        if (sharedSfxSource == null) return;
        if (failPopSfx == null) return;
        sharedSfxSource.PlayOneShot(failPopSfx, failPopVolume);
    }

    private void PlayCountdownTick(int stepIndex) // 0=3, 1=2, 2=1
    {
        AudioSource src = (countdownSfxSource != null) ? countdownSfxSource : sharedSfxSource;
        if (src == null) return;
        if (countdownTickSfx == null) return;

        float originalPitch = src.pitch;

        if (countdownPitchRamp)
            src.pitch = 1f + (countdownPitchStep * Mathf.Clamp(stepIndex, 0, 2));

        src.PlayOneShot(countdownTickSfx, countdownSfxVolume);
        src.pitch = originalPitch;
    }

    private void PlayCountdownGo()
    {
        AudioSource src = (countdownSfxSource != null) ? countdownSfxSource : sharedSfxSource;
        if (src == null) return;
        if (countdownGoSfx == null) return;

        src.PlayOneShot(countdownGoSfx, countdownSfxVolume);
    }

    private void StartGameplayMusic()
    {
        if (gameplayMusicSource == null) return;

        gameplayMusicSource.loop = true;
        gameplayMusicSource.pitch = 1f;

        if (!gameplayMusicSource.isPlaying)
            gameplayMusicSource.Play();
    }

    private void StopGameplayMusic()
    {
        if (gameplayMusicSource == null) return;

        if (gameplayMusicSource.isPlaying)
            gameplayMusicSource.Stop();
    }

    private void StopTitleMusic()
    {
        if (titleMusicSource == null) return;

        if (titleMusicSource.isPlaying)
            titleMusicSource.Stop();
    }

    private void StartTitleMusic()
    {
        if (titleMusicSource == null) return;

        titleMusicSource.loop = true;
        titleMusicSource.pitch = 1f;
        titleMusicSource.Stop();
        titleMusicSource.time = 0f;
        titleMusicSource.Play();
    }
    private void StartDeityEntranceLoopSfx()
    {
        if (deityEntranceLoopSource == null) return;
        if (deityEntranceLoopClip == null) return;

        deityEntranceLoopSource.Stop();
        deityEntranceLoopSource.clip = deityEntranceLoopClip;

        deityEntranceLoopSource.loop = false;          // ✅ play once
        deityEntranceLoopSource.Play();                // ✅ play once
    }

    private void StopDeityEntranceLoopSfx()
    {
        if (deityEntranceLoopSource == null) return;
        if (!deityEntranceLoopSource.isPlaying) return;

        StartCoroutine(FadeOutAndStop_DeityEntranceLoop());
    }

    private Coroutine introVocalRoutine;

    private void PlayDeityIntroVocal(DeityProfile dp)
    {
        if (dp == null) return;
        if (deityIntroVocalSource == null) return;
        if (dp.introVocalClip == null) return;

        float vol = Mathf.Clamp01(dp.introVocalVolume);
        deityIntroVocalSource.PlayOneShot(dp.introVocalClip, vol);
    }

    private IEnumerator PlayDeityIntroVocalDelayed(DeityProfile dp)
    {
        if (dp == null) yield break;
        float d = Mathf.Max(0f, dp.introVocalDelay);

        if (d > 0f)
            yield return new WaitForSecondsRealtime(d);

        PlayDeityIntroVocal(dp);
    }

    private IEnumerator FadeOutAndStop_DeityEntranceLoop()
    {
        if (deityEntranceLoopSource == null) yield break;

        float startVol = deityEntranceLoopSource.volume;
        float dur = Mathf.Max(0.01f, deityEntranceLoopFadeOutSeconds);
        float t = 0f;

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            deityEntranceLoopSource.volume = Mathf.Lerp(startVol, 0f, t / dur);
            yield return null;
        }

        deityEntranceLoopSource.Stop();
        deityEntranceLoopSource.volume = startVol;
    }
    private IEnumerator FlashBoltLocalOnce(Bolt b)
    {
        if (b == null) yield break;

        SpriteRenderer[] srs = b.GetComponentsInChildren<SpriteRenderer>(true);
        if (srs == null || srs.Length == 0) yield break;

        Color[] original = new Color[srs.Length];
        for (int i = 0; i < srs.Length; i++)
        {
            if (srs[i] == null) continue;
            original[i] = srs[i].color;
            srs[i].color = boltFlashColor;
        }

        yield return new WaitForSecondsRealtime(Mathf.Max(0.001f, boltFlashSeconds));

        for (int i = 0; i < srs.Length; i++)
        {
            if (srs[i] == null) continue;
            srs[i].color = original[i];
        }
    }

    private void TriggerFinalPopScreenFX()
    {
        if (lifeLostCameraShake != null)
            lifeLostCameraShake.Shake(lifeLostShakeDuration, lifeLostShakeMagnitude);

        if (lifeLostFlash != null)
            lifeLostFlash.FlashPulses(finalFlashPulses, finalFlashOnSeconds, finalFlashOffSeconds, finalFlashAlpha);

        if (sharedSfxSource != null && finalPopSfx != null)
            sharedSfxSource.PlayOneShot(finalPopSfx, finalPopVolume);

        HapticsSettings.TryVibrate();
    }

    private GameObject FindFirstActiveShield()
    {
        CacheShieldsIfNeeded();
        if (shieldsBottomToTop == null || shieldsBottomToTop.Count == 0) return null;

        for (int i = 0; i < shieldsBottomToTop.Count; i++)
        {
            GameObject s = shieldsBottomToTop[i];
            if (s != null && s.activeSelf) return s;
        }
        return null;
    }

    private IEnumerator BlinkThenDisableShield(GameObject shield)
    {
        if (shield == null) yield break;

        SpriteRenderer sr = shield.GetComponent<SpriteRenderer>();

        // If no SpriteRenderer, just disable directly (but still play drain SFX)
        if (sr == null)
        {
            PlayShieldDrainSfx();
            shield.SetActive(false);
            yield break;
        }

        int blinks = Mathf.Max(1, shieldBlinkCount);

        for (int i = 0; i < blinks; i++)
        {
            sr.enabled = false;
            yield return new WaitForSecondsRealtime(Mathf.Max(0.001f, shieldBlinkOffSeconds));

            sr.enabled = true;
            yield return new WaitForSecondsRealtime(Mathf.Max(0.001f, shieldBlinkOnSeconds));
        }

        // ensure visible, then drain + vanish
        sr.enabled = true;
        PlayShieldDrainSfx();
        shield.SetActive(false);
    }
 
    private void PlayShieldDrainSfx()
    {
        if (sharedSfxSource == null) return;
        if (shieldDrainSfx == null) return;

        float v = shieldDrainVolume * shieldDrainVolumeBoost; // NO Clamp01
        sharedSfxSource.PlayOneShot(shieldDrainSfx, v);
    }
    private IEnumerator BlinkTrialComplete()
    {
        if (trialCompleteText == null) yield break;

        trialCompleteText.gameObject.SetActive(true);

        int blinks = Mathf.Max(1, trialBlinkCount);
        float onT = Mathf.Max(0.01f, trialBlinkOnSeconds);
        float offT = Mathf.Max(0.01f, trialBlinkOffSeconds);

        for (int i = 0; i < blinks; i++)
        {
            trialCompleteText.enabled = true;
            yield return new WaitForSecondsRealtime(onT);

            trialCompleteText.enabled = false;
            yield return new WaitForSecondsRealtime(offT);
        }

        trialCompleteText.enabled = true;                // reset
        trialCompleteText.gameObject.SetActive(false);   // hide before cameos
    }
    private Vector2 ComputeUiSizeDeltaFromWorldSprite(Sprite sprite, SpriteRenderer spriteRenderer, RectTransform anyUiChild)
    {
        if (sprite == null) return new Vector2(rainProjectileSize, rainProjectileSize);

        // Sprite's size in WORLD units at scale (1,1,1)
        float worldW = sprite.rect.width / sprite.pixelsPerUnit;
        float worldH = sprite.rect.height / sprite.pixelsPerUnit;

        // Include the VISUAL renderer's scale (this captures child "Visual" scale like 0.2)
        if (spriteRenderer != null)
        {
            Vector3 s = spriteRenderer.transform.lossyScale;
            worldW *= Mathf.Abs(s.x);
            worldH *= Mathf.Abs(s.y);
        }

        float pxPerWorld = GetPixelsPerWorldUnit();
        float pxW = worldW * pxPerWorld;
        float pxH = worldH * pxPerWorld;

        float scaleFactor = GetCanvasScaleFactor(anyUiChild);
        return new Vector2(pxW / scaleFactor, pxH / scaleFactor);
    }

    private float GetPixelsPerWorldUnit()
    {
        Camera cam = Camera.main;
        if (cam != null && cam.orthographic)
        {
            // Screen height in pixels covers 2*orthographicSize world units
            return Screen.height / (2f * cam.orthographicSize);
        }

        // Fallback (won't be perfect on perspective, but safe)
        return 100f;
    }

    private float GetCanvasScaleFactor(RectTransform anyUiChild)
    {
        if (anyUiChild == null) return 1f;
        Canvas c = anyUiChild.GetComponentInParent<Canvas>();
        return (c != null) ? Mathf.Max(0.01f, c.scaleFactor) : 1f;
    }
    private void PlayRunCompleteImpactSfx()
    {
        if (sharedSfxSource == null) return;
        if (runCompleteImpactSfx == null) return;

        if (Time.unscaledTime < nextRunCompleteImpactSfxTime) return;

        sharedSfxSource.PlayOneShot(runCompleteImpactSfx, runCompleteImpactVolume);
        nextRunCompleteImpactSfxTime = Time.unscaledTime + Mathf.Max(0f, runCompleteImpactCooldownSeconds);
    }
    private bool TryWorldToUiLocal(Vector3 worldPos, RectTransform uiRect, out Vector2 localPoint)
    {
        localPoint = Vector2.zero;
        if (uiRect == null) return false;

        Camera worldCam = Camera.main;
        if (worldCam == null) worldCam = FindObjectOfType<Camera>();
        if (worldCam == null) return false;

        Vector3 screen = worldCam.WorldToScreenPoint(worldPos);

        Canvas canvas = uiRect.GetComponentInParent<Canvas>();
        Camera uiCam = (canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay) ? canvas.worldCamera : null;

        return RectTransformUtility.ScreenPointToLocalPointInRectangle(uiRect, screen, uiCam, out localPoint);
    }
    private void StartRunCompleteMusic()
    {
        if (runCompleteMusicSource == null) return;
        if (runCompleteMusicClip == null) return;

        runCompleteMusicSource.clip = runCompleteMusicClip;
        runCompleteMusicSource.loop = true;
        runCompleteMusicSource.volume = runCompleteMusicVolume;

        runCompleteMusicSource.pitch = 1f;   // ✅ force normal speed

        if (!runCompleteMusicSource.isPlaying)
            runCompleteMusicSource.Play();
    }

    private void StopRunCompleteMusic()
    {
        if (runCompleteMusicSource == null) return;

        if (runCompleteMusicSource.isPlaying)
            runCompleteMusicSource.Stop();
    }
    public void OnRunCompleteTap()
    {
        if (!awaitingRunCompleteTap) return;

        awaitingRunCompleteTap = false;
        SetRunCompleteContinueVisible(false);
        HideRunCompleteScreen();

        ReturnToTitleScreenAndReset();
    }
    private void PlayRainVolleyStartSfx(DeityProfile dp)
    {
        if (sharedSfxSource == null) return;
        if (dp == null) return;
        if (dp.projectilePrefab == null) return;

        Bolt bolt = dp.projectilePrefab.GetComponent<Bolt>();
        if (bolt == null)
            bolt = dp.projectilePrefab.GetComponentInChildren<Bolt>(true);

        if (bolt == null) return;
        if (bolt.spawnSfx == null) return;

        // Use the prefab's configured volume if available
        float v = (bolt.sfxVolume > 0f) ? bolt.sfxVolume : 1f;
        sharedSfxSource.PlayOneShot(bolt.spawnSfx, v);
    }
    private void Start()
    {
        StartCoroutine(EnsureAudioStartupRoutine());
    }

    private IEnumerator EnsureAudioStartupRoutine()
    {
        // Wait 1 frame so all objects/tags/sources exist
        yield return null;

        // Hard-safe defaults
        AudioListener.pause = false;
        AudioListener.volume = 1f;

        // Re-apply saved toggles (mutes/unmutes all tagged Music/SFX sources)
        if (AudioSettingsManager.Instance != null)
            AudioSettingsManager.Instance.ApplySaved();

        // If we are currently on the title screen, ensure title music is actually playing
        if (titlePanel != null && titlePanel.activeInHierarchy)
        {
            StartTitleMusic();
        }
    }
}