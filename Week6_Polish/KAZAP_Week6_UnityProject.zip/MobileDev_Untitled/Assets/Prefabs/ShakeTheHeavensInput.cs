using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class ShakeTheHeavensInput : MonoBehaviour
{
    [Header("Shake Icon (Readiness Gate)")]
    [Tooltip("Assign your top-right shake icon Image here.")]
    public Image shakeIconImage;

    [Tooltip("Icon alpha at/above this value is considered READY (lit).")]
    [Range(0f, 1f)]
    public float readyAlphaThreshold = 0.95f;

    [Header("Real Device Shake Detection")]
    [Tooltip("0.10�0.30 is a good range. Higher = snappier, lower = smoother.")]
    [Range(0.01f, 1f)]
    public float smoothing = 0.15f;

    [Tooltip("Higher = harder to trigger. Start around 1.2�1.6.")]
    public float shakeThreshold = 1.35f;

    [Tooltip("Seconds between triggers.")]
    public float shakeCooldown = 0.75f;

    [Header("Editor / Emulator Trigger")]
    public bool enableEditorKey = true;
    public KeyCode editorKey = KeyCode.Space;

    [Header("Debug")]
    public bool logWhenBlocked = false;

    [Header("RoundManager Hook")]
    public RoundManager roundManager;

    private Vector3 smoothedAccel;
    private float lastShakeTime = -999f;

    private void OnEnable()
    {
        // Enable accelerometer for the new Input System (safe on devices that support it)
        if (Accelerometer.current != null)
            InputSystem.EnableDevice(Accelerometer.current);
    }

    private void OnDisable()
    {
        if (Accelerometer.current != null)
            InputSystem.DisableDevice(Accelerometer.current);
    }

    private void Update()
    {
        if (Time.timeScale == 0f)
            return;

        // If not ready, block
        if (!IsIconReady())
        {
            if (logWhenBlocked && Application.isEditor && enableEditorKey && EditorKeyPressedThisFrame())
                Debug.Log("STH blocked: icon not ready/lit.");
            return;
        }

        // Block during life-loss/game-over so we don't consume it visually
        if (roundManager != null && (roundManager.IsInLossSequence || roundManager.IsGameOver))
        {
            if (logWhenBlocked && Application.isEditor && enableEditorKey && EditorKeyPressedThisFrame())
                Debug.Log("STH blocked: loss sequence / game over.");
            return;
        }

        // Editor/emulator: key
        if (Application.isEditor && enableEditorKey)
        {
            if (EditorKeyPressedThisFrame())
            {
                TriggerSTH("EditorKey", 0f);
                return;
            }
        }

        // Device: accelerometer shake (new Input System)
        if (Accelerometer.current == null)
            return;

        Vector3 rawAccel = Accelerometer.current.acceleration.ReadValue();
        smoothedAccel = Vector3.Lerp(smoothedAccel, rawAccel, smoothing);

        float shakeSignal = (rawAccel - smoothedAccel).magnitude;

        if (shakeSignal > shakeThreshold && (Time.unscaledTime - lastShakeTime) >= shakeCooldown)
        {
            lastShakeTime = Time.unscaledTime;
            TriggerSTH("Accelerometer", shakeSignal);
        }
    }

    private bool EditorKeyPressedThisFrame()
    {
        var kb = Keyboard.current;
        if (kb == null) return false;

        // Minimal mapping (you�re using Space). Add more cases if you ever change the key.
        switch (editorKey)
        {
            case KeyCode.Space: return kb.spaceKey.wasPressedThisFrame;
            case KeyCode.X: return kb.xKey.wasPressedThisFrame;
            case KeyCode.Z: return kb.zKey.wasPressedThisFrame;
            case KeyCode.C: return kb.cKey.wasPressedThisFrame;
            case KeyCode.V: return kb.vKey.wasPressedThisFrame;
            case KeyCode.B: return kb.bKey.wasPressedThisFrame;
            case KeyCode.N: return kb.nKey.wasPressedThisFrame;
            case KeyCode.M: return kb.mKey.wasPressedThisFrame;

            case KeyCode.LeftArrow: return kb.leftArrowKey.wasPressedThisFrame;
            case KeyCode.RightArrow: return kb.rightArrowKey.wasPressedThisFrame;
            case KeyCode.UpArrow: return kb.upArrowKey.wasPressedThisFrame;
            case KeyCode.DownArrow: return kb.downArrowKey.wasPressedThisFrame;

            case KeyCode.Return: return kb.enterKey.wasPressedThisFrame;
            case KeyCode.Escape: return kb.escapeKey.wasPressedThisFrame;

            default:
                // Fallback to Space so you don't silently lose the editor trigger
                return kb.spaceKey.wasPressedThisFrame;
        }
    }

    private bool IsIconReady()
    {
        if (shakeIconImage == null) return false;
        if (!shakeIconImage.gameObject.activeInHierarchy) return false;

        // dim/hidden = alpha low, ready = alpha high
        return shakeIconImage.color.a >= readyAlphaThreshold;
    }

    private void TriggerSTH(string source, float signal)
    {
        Debug.Log($"STH TRIGGERED! source={source}  signal={signal:F2}");

        if (roundManager != null)
            roundManager.Debug_OnShakeTheHeavensTriggered();
    }

}
