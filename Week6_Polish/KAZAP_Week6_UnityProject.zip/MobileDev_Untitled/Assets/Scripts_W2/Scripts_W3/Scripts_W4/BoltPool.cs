using System.Collections.Generic;
using UnityEngine;

// Simple marker so the pool knows which prefab an instance came from.
public class BoltPoolMarker : MonoBehaviour
{
    public int prefabKey;
}

public class BoltPool : MonoBehaviour
{
    [Header("Debug")]
    [SerializeField] private Transform poolRoot;

    private GameObject currentPrefab;
    private int currentPrefabKey;

    private readonly Queue<GameObject> inactive = new Queue<GameObject>();
    private readonly HashSet<GameObject> active = new HashSet<GameObject>();

    // These are remembered so Configure can safely rebuild.
    private Transform configuredParent;
    private int configuredPrewarm;

    /// <summary>
    /// Configure the pool to use a given prefab. If the prefab changes, we purge old pooled instances.
    /// </summary>
    public void Configure(GameObject prefab, Transform parent, int prewarmCount)
    {
        if (prefab == null) return;

        bool prefabChanged = (currentPrefab != prefab);

        currentPrefab = prefab;
        currentPrefabKey = prefab.GetInstanceID();

        configuredParent = parent != null ? parent : transform;
        configuredPrewarm = Mathf.Max(0, prewarmCount);

        EnsurePoolRoot();

        if (prefabChanged)
        {
            PurgeAllPooledObjects();
        }

        PrewarmTo(configuredPrewarm);
    }

    private void EnsurePoolRoot()
    {
        if (poolRoot != null) return;

        GameObject root = new GameObject("BoltPoolRoot");
        poolRoot = root.transform;
        poolRoot.SetParent(configuredParent != null ? configuredParent : transform, false);
        poolRoot.localPosition = Vector3.zero;
        poolRoot.localRotation = Quaternion.identity;
        poolRoot.localScale = Vector3.one;
    }

    private void PurgeAllPooledObjects()
    {
        // Destroy inactive objects
        while (inactive.Count > 0)
        {
            GameObject go = inactive.Dequeue();
            if (go != null) Destroy(go);
        }

        // Destroy active pooled objects (only ones the pool is tracking)
        foreach (GameObject go in active)
        {
            if (go != null) Destroy(go);
        }
        active.Clear();
    }

    private void PrewarmTo(int target)
    {
        if (currentPrefab == null) return;

        while (inactive.Count < target)
        {
            GameObject go = Instantiate(currentPrefab, poolRoot);
            go.SetActive(false);

            BoltPoolMarker marker = go.GetComponent<BoltPoolMarker>();
            if (marker == null) marker = go.AddComponent<BoltPoolMarker>();
            marker.prefabKey = currentPrefabKey;

            inactive.Enqueue(go);
        }
    }

    public GameObject Get(Vector3 position, Quaternion rotation, Transform parent)
    {
        if (currentPrefab == null) return null;

        EnsurePoolRoot();
        PrewarmTo(configuredPrewarm);

        GameObject go = (inactive.Count > 0) ? inactive.Dequeue() : Instantiate(currentPrefab, poolRoot);

        // If this instance belongs to an old prefab type, destroy + replace.
        BoltPoolMarker marker = go.GetComponent<BoltPoolMarker>();
        if (marker == null || marker.prefabKey != currentPrefabKey)
        {
            if (go != null) Destroy(go);

            go = Instantiate(currentPrefab, poolRoot);
            marker = go.AddComponent<BoltPoolMarker>();
            marker.prefabKey = currentPrefabKey;
        }

        Transform useParent = parent != null ? parent : poolRoot;

        go.transform.SetParent(useParent, true);
        go.transform.SetPositionAndRotation(position, rotation);
        go.SetActive(true);

        active.Add(go);
        return go;
    }

    public void Return(GameObject go)
    {
        if (go == null) return;

        // No longer active
        active.Remove(go);

        BoltPoolMarker marker = go.GetComponent<BoltPoolMarker>();

        // If it�s not the current prefab type, we destroy it (prevents cross-deity contamination).
        if (marker == null || marker.prefabKey != currentPrefabKey)
        {
            Destroy(go);
            return;
        }

        go.SetActive(false);
        go.transform.SetParent(poolRoot, false);
        inactive.Enqueue(go);
    }

    /// <summary>
    /// Returns all pooled bolts that are currently children of the given parent.
    /// SAFETY: only returns children that have BoltPoolMarker.
    /// </summary>
    public void ClearAllActiveChildren(Transform parent)
    {
        if (parent == null) return;

        List<GameObject> toReturn = new List<GameObject>();

        for (int i = 0; i < parent.childCount; i++)
        {
            Transform child = parent.GetChild(i);
            if (child == null) continue;

            if (child.GetComponent<BoltPoolMarker>() != null)
            {
                toReturn.Add(child.gameObject);
            }
        }

        for (int i = 0; i < toReturn.Count; i++)
        {
            Return(toReturn[i]);
        }
    }
}