using UnityEngine;

public class InterruptionHandler : MonoBehaviour
{
    [Header("Refs")]
    public PauseController pauseController;
    public RoundManager roundManager;

    [Tooltip("If true, auto-pause when app loses focus (alt-tab).")]
    public bool pauseOnFocusLost = true;

    [Tooltip("If true, auto-pause when app is backgrounded. (Mobile interruption)")]
    public bool pauseOnAppPause = true;

    private bool hasGameplayStartedThisRun;

    private void Awake()
    {
        if (pauseController == null)
            pauseController = FindObjectOfType<PauseController>();

        if (roundManager == null)
            roundManager = FindObjectOfType<RoundManager>();
    }

    private void Update()
    {
        // Track if gameplay has started at least once (prevents pausing on title screen)
        if (!hasGameplayStartedThisRun && roundManager != null)
        {
            // RoundManager sets hudPanel active during gameplay start; this is a safe proxy
            if (roundManager.hudPanel != null && roundManager.hudPanel.activeInHierarchy)
                hasGameplayStartedThisRun = true;
        }
    }

    private void OnApplicationPause(bool paused)
    {
        if (!pauseOnAppPause) return;
        if (!paused) return; // only act when going to background

        TryAutoPause();
    }

    private void OnApplicationFocus(bool hasFocus)
    {
        if (!pauseOnFocusLost) return;
        if (hasFocus) return; // only act when losing focus

        TryAutoPause();
    }

    private void TryAutoPause()
    {
        // Only during gameplay (not title/settings)
        if (!hasGameplayStartedThisRun) return;

        if (roundManager != null && (roundManager.IsGameOver || roundManager.IsInLossSequence))
            return;

        if (pauseController != null)
            pauseController.Pause();
    }

    // Call this from RoundManager when returning to title if you want to reset state (optional)
    public void ResetGameplayFlag()
    {
        hasGameplayStartedThisRun = false;
    }
}