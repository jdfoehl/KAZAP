using UnityEngine;

public static class PolishAccessibilitySettings
{
    public enum EffectLevel { Off = 0, Reduced = 1, Full = 2 }

    private const string KEY_FLASH = "acc_flash_level";
    private const string KEY_SHAKE = "acc_shake_level";

    private static bool _loaded;

    public static EffectLevel FlashLevel { get; private set; } = EffectLevel.Full;
    public static EffectLevel ShakeLevel { get; private set; } = EffectLevel.Full;

    public static float FlashMultiplier
    {
        get
        {
            EnsureLoaded();
            return LevelToMultiplier(FlashLevel);
        }
    }

    public static float ShakeMultiplier
    {
        get
        {
            EnsureLoaded();
            return LevelToMultiplier(ShakeLevel);
        }
    }

    public static void EnsureLoaded()
    {
        if (_loaded) return;

        FlashLevel = (EffectLevel)Mathf.Clamp(PlayerPrefs.GetInt(KEY_FLASH, (int)EffectLevel.Full), 0, 2);
        ShakeLevel = (EffectLevel)Mathf.Clamp(PlayerPrefs.GetInt(KEY_SHAKE, (int)EffectLevel.Full), 0, 2);

        _loaded = true;
    }

    public static void SetFlashLevel(EffectLevel level)
    {
        FlashLevel = level;
        PlayerPrefs.SetInt(KEY_FLASH, (int)level);
        PlayerPrefs.Save();
    }

    public static void SetShakeLevel(EffectLevel level)
    {
        ShakeLevel = level;
        PlayerPrefs.SetInt(KEY_SHAKE, (int)level);
        PlayerPrefs.Save();
    }

    private static float LevelToMultiplier(EffectLevel level)
    {
        switch (level)
        {
            case EffectLevel.Off: return 0f;
            case EffectLevel.Reduced: return 0.5f;
            case EffectLevel.Full:
            default: return 1f;
        }
    }
}