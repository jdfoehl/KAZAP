using UnityEngine;

public class ShieldInterceptFeedback2D : MonoBehaviour
{
    [Header("Shrapnel VFX (optional)")]
    [SerializeField] private ParticleSystem shrapnelPrefab;
    [SerializeField] private Transform vfxParent;

    [Header("Intercept SFX (optional)")]
    [Tooltip("If assigned, we will use this source (recommended: RoundManager.sharedSfxSource so SFX toggle applies).")]
    [SerializeField] private AudioSource sharedSfxSource;

    [Tooltip("Fallback local source (optional). Used only if sharedSfxSource is not assigned.")]
    [SerializeField] private AudioSource localSfxSource;

    [SerializeField] private AudioClip interceptSfx;
    [Range(0f, 1f)][SerializeField] private float interceptVolume = 1f;

    [Tooltip("Prevents constant audio spam on rapid catches.")]
    [SerializeField] private float sfxCooldownSeconds = 0.08f;

    private float _nextSfxTime;

    private void Awake()
    {
        // Auto-find RoundManager shared SFX source if not assigned (safe convenience)
        if (sharedSfxSource == null)
        {
            RoundManager rm = FindObjectOfType<RoundManager>();
            if (rm != null) sharedSfxSource = rm.sharedSfxSource;
        }

        if (localSfxSource == null)
            localSfxSource = GetComponent<AudioSource>();
    }

    public void PlayInterceptFeedback(Vector3 worldPos, Vector2 incomingVelocity)
    {
        // --- VFX ---
        if (shrapnelPrefab != null)
        {
            float angle = 0f;
            if (incomingVelocity.sqrMagnitude > 0.0001f)
                angle = Mathf.Atan2(-incomingVelocity.y, -incomingVelocity.x) * Mathf.Rad2Deg;

            Quaternion rot = Quaternion.Euler(0f, 0f, angle);

            ParticleSystem ps = Instantiate(shrapnelPrefab, worldPos, rot, vfxParent);
            ps.Play(true);
        }

        // --- SFX ---
        if (interceptSfx == null) return;
        if (Time.unscaledTime < _nextSfxTime) return;

        AudioSource src = (sharedSfxSource != null) ? sharedSfxSource : localSfxSource;
        if (src != null)
        {
            src.PlayOneShot(interceptSfx, interceptVolume);
            _nextSfxTime = Time.unscaledTime + Mathf.Max(0f, sfxCooldownSeconds);
        }
    }
}