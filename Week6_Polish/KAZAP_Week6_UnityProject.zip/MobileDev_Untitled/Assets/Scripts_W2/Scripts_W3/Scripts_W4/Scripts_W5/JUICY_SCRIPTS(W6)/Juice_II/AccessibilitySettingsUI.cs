using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class AccessibilitySettingsUI : MonoBehaviour
{
    [Header("UI Refs")]
    public TMP_Text flashLevelLabel;
    public Button flashLevelButton;

    public TMP_Text shakeLevelLabel;
    public Button shakeLevelButton;

    private void Awake()
    {
        // Load saved prefs
        PolishAccessibilitySettings.EnsureLoaded();

        // Wire button clicks
        if (flashLevelButton != null)
            flashLevelButton.onClick.AddListener(CycleFlash);

        if (shakeLevelButton != null)
            shakeLevelButton.onClick.AddListener(CycleShake);

        RefreshLabels();
    }

    private void OnEnable()
    {
        // In case settings changed elsewhere
        PolishAccessibilitySettings.EnsureLoaded();
        RefreshLabels();
    }

    private void CycleFlash()
    {
        var next = NextLevel(PolishAccessibilitySettings.FlashLevel);
        PolishAccessibilitySettings.SetFlashLevel(next);
        RefreshLabels();
    }

    private void CycleShake()
    {
        var next = NextLevel(PolishAccessibilitySettings.ShakeLevel);
        PolishAccessibilitySettings.SetShakeLevel(next);
        RefreshLabels();
    }

    private PolishAccessibilitySettings.EffectLevel NextLevel(PolishAccessibilitySettings.EffectLevel current)
    {
        // Full -> Reduced -> Off -> Full
        switch (current)
        {
            case PolishAccessibilitySettings.EffectLevel.Full:
                return PolishAccessibilitySettings.EffectLevel.Reduced;
            case PolishAccessibilitySettings.EffectLevel.Reduced:
                return PolishAccessibilitySettings.EffectLevel.Off;
            case PolishAccessibilitySettings.EffectLevel.Off:
            default:
                return PolishAccessibilitySettings.EffectLevel.Full;
        }
    }

    private void RefreshLabels()
    {
        if (flashLevelLabel != null)
            flashLevelLabel.text = $"FLASH: {LevelToText(PolishAccessibilitySettings.FlashLevel)}";

        if (shakeLevelLabel != null)
            shakeLevelLabel.text = $"SHAKE: {LevelToText(PolishAccessibilitySettings.ShakeLevel)}";
    }

    private string LevelToText(PolishAccessibilitySettings.EffectLevel level)
    {
        switch (level)
        {
            case PolishAccessibilitySettings.EffectLevel.Off: return "OFF";
            case PolishAccessibilitySettings.EffectLevel.Reduced: return "REDUCED";
            case PolishAccessibilitySettings.EffectLevel.Full:
            default: return "FULL";
        }
    }
}