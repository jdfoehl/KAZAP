using System.Collections;
using UnityEngine;

public class TransformShake2D : MonoBehaviour
{
    [SerializeField] private Transform target;

    private Coroutine shakeRoutine;

    private void Awake()
    {
        if (target == null)
            target = transform;
    }

    public void Shake(float durationSeconds, float magnitudeUnits)
    {
        if (target == null) return;

        float m = PolishAccessibilitySettings.ShakeMultiplier;

        // Off = no shake
        if (m <= 0f)
            return;

        // Reduced/Full: scale magnitude (duration stays the same)
        magnitudeUnits *= m;

        if (shakeRoutine != null)
        {
            StopCoroutine(shakeRoutine);
            shakeRoutine = null;
        }

        shakeRoutine = StartCoroutine(ShakeRoutine(durationSeconds, magnitudeUnits));
    }

    public void StopAndReset()
    {
        if (target == null) return;

        if (shakeRoutine != null)
        {
            StopCoroutine(shakeRoutine);
            shakeRoutine = null;
        }
    }

    private IEnumerator ShakeRoutine(float durationSeconds, float magnitudeUnits)
    {
        Vector3 original = target.localPosition;

        float duration = Mathf.Max(0.01f, durationSeconds);
        float magnitude = Mathf.Max(0f, magnitudeUnits);

        float elapsed = 0f;

        while (elapsed < duration)
        {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;

            target.localPosition = original + new Vector3(x, y, 0f);

            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        target.localPosition = original;
        shakeRoutine = null;
    }
}
