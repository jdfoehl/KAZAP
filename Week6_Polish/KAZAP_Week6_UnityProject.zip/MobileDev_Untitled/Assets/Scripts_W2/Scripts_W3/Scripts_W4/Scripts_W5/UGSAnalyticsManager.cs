using System;
using System.Collections.Generic;
using UnityEngine;
using Unity.Services.Core;
using Unity.Services.Analytics;

public class UGSAnalyticsManager : MonoBehaviour
{
    private static UGSAnalyticsManager instance;
    private static bool initialized;

    /// <summary>
    /// Optional: lets other scripts check readiness.
    /// </summary>
    public static bool IsInitialized => initialized;

    private async void Awake()
    {
        // Singleton
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(gameObject);

        if (initialized) return;

        try
        {
            await UnityServices.InitializeAsync();

            // For Unity 6.1 + Services Analytics, this is the �start collecting� step.
            // If your project is configured for consent flows, you may need to handle consent separately,
            // but this will compile and work for the common classroom setup.
            AnalyticsService.Instance.StartDataCollection();

            initialized = true;
            Debug.Log("[UGSAnalytics] Initialized + data collection started.");
        }
        catch (Exception e)
        {
            initialized = false;
            Debug.LogError($"[UGSAnalytics] Initialize failed: {e}");
        }
    }

    /// <summary>
    /// Your RoundManager currently calls UGSAnalyticsManager.Record(...)
    /// so keep this wrapper.
    /// </summary>
    public static void Record(string eventName, Dictionary<string, object> parameters = null, bool flush = false)
    {
        RecordEvent(eventName, parameters, flush);
    }

    /// <summary>
    /// Some earlier versions called RecordEvent(...). Support both.
    /// </summary>
    public static void RecordEvent(string eventName, Dictionary<string, object> parameters = null, bool flush = false)
    {
        if (!initialized)
        {
            // Don�t spam logs every frame; just warn once per call.
            Debug.LogWarning($"[UGSAnalytics] Not initialized yet. Event '{eventName}' was skipped.");
            return;
        }

        if (string.IsNullOrEmpty(eventName))
        {
            Debug.LogWarning("[UGSAnalytics] Tried to record an event with a null/empty name.");
            return;
        }

        try
        {
            // Analytics 6.2.x: CustomEvent + RecordEvent
            // CustomEvent supports dictionary-style initialization / Add(key,value).  :contentReference[oaicite:1]{index=1}
            CustomEvent ev = new CustomEvent(eventName);

            if (parameters != null)
            {
                foreach (var kvp in parameters)
                {
                    // Valid value types are limited (string/int/long/float/double/bool/DateTime). :contentReference[oaicite:2]{index=2}
                    // If you pass something unsupported, Unity throws ArgumentException.
                    ev.Add(kvp.Key, kvp.Value);
                }
            }

            AnalyticsService.Instance.RecordEvent(ev);  // :contentReference[oaicite:3]{index=3}

            if (flush)
            {
                AnalyticsService.Instance.Flush();      // :contentReference[oaicite:4]{index=4}
            }
        }
        catch (ArgumentException ae)
        {
            Debug.LogError($"[UGSAnalytics] Bad parameter type for '{eventName}': {ae.Message}");
        }
        catch (Exception e)
        {
            Debug.LogError($"[UGSAnalytics] Failed to record '{eventName}': {e}");
        }
    }
}