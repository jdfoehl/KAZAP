using UnityEngine;

public static class HapticsSettings
{
    private const string KEY = "opt_haptics_enabled";
    private static bool _loaded;

    public static bool Enabled { get; private set; } = true;

    public static void EnsureLoaded()
    {
        if (_loaded) return;
        Enabled = PlayerPrefs.GetInt(KEY, 1) == 1;
        _loaded = true;
    }

    public static void SetEnabled(bool enabled)
    {
        Enabled = enabled;
        PlayerPrefs.SetInt(KEY, enabled ? 1 : 0);
        PlayerPrefs.Save();
    }

    public static void TryVibrate()
    {
        EnsureLoaded();
        if (!Enabled) return;

#if UNITY_EDITOR
        Debug.Log("[Haptics] Vibrate triggered (editor debug only).");
#endif

        Handheld.Vibrate();
    }
}