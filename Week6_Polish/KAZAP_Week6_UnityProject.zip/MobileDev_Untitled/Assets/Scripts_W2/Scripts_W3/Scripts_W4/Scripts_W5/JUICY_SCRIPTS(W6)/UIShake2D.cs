using System.Collections;
using UnityEngine;

public class UIShake2D : MonoBehaviour
{
    [SerializeField] private RectTransform target;

    private Coroutine shakeRoutine;

    private void Awake()
    {
        if (target == null)
            target = GetComponent<RectTransform>();
    }

    public void Shake(float durationSeconds, float magnitudePx)
    {
        if (target == null) return;

        float m = PolishAccessibilitySettings.ShakeMultiplier;

        // Off = no shake
        if (m <= 0f)
            return;

        // Reduced/Full: scale magnitude
        magnitudePx *= m;

        if (shakeRoutine != null)
        {
            StopCoroutine(shakeRoutine);
            shakeRoutine = null;
        }

        shakeRoutine = StartCoroutine(ShakeRoutine(durationSeconds, magnitudePx));
    }

    public void StopAndReset()
    {
        if (target == null) return;

        if (shakeRoutine != null)
        {
            StopCoroutine(shakeRoutine);
            shakeRoutine = null;
        }
        // No persistent offset is stored; caller�s layout remains.
        // (We reset inside the coroutine each time.)
    }

    private IEnumerator ShakeRoutine(float durationSeconds, float magnitudePx)
    {
        Vector2 original = target.anchoredPosition;

        float duration = Mathf.Max(0.01f, durationSeconds);
        float magnitude = Mathf.Max(0f, magnitudePx);

        float elapsed = 0f;

        while (elapsed < duration)
        {
            float x = Random.Range(-1f, 1f) * magnitude;
            float y = Random.Range(-1f, 1f) * magnitude;

            target.anchoredPosition = original + new Vector2(x, y);

            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        target.anchoredPosition = original;
        shakeRoutine = null;
    }
}