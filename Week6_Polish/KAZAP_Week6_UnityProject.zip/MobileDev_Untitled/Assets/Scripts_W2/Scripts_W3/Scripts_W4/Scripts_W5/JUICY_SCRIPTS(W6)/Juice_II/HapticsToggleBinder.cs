using UnityEngine;
using UnityEngine.UI;

public class HapticsToggleBinder : MonoBehaviour
{
    [SerializeField] private Toggle hapticsToggle;

    private bool _setting;

    private void Awake()
    {
        HapticsSettings.EnsureLoaded();

        if (hapticsToggle == null)
            hapticsToggle = GetComponent<Toggle>();

        if (hapticsToggle != null)
        {
            _setting = true;
            hapticsToggle.isOn = HapticsSettings.Enabled;
            _setting = false;

            hapticsToggle.onValueChanged.AddListener(OnToggleChanged);
        }
    }

    private void OnToggleChanged(bool on)
    {
        if (_setting) return;
        HapticsSettings.SetEnabled(on);
    }
}