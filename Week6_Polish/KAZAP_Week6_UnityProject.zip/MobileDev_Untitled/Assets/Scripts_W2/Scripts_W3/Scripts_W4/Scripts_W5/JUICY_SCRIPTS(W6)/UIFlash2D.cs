using System.Collections;
using UnityEngine;

public class UIFlash2D : MonoBehaviour
{
    [SerializeField] private CanvasGroup group;

    private Coroutine routine;

    private void Awake()
    {
        if (group == null) group = GetComponent<CanvasGroup>();
        if (group != null) group.alpha = 0f;
    }

    public void FlashPulses(int pulses, float onSeconds, float offSeconds, float maxAlpha)
    {
        if (group == null) return;

        float m = PolishAccessibilitySettings.FlashMultiplier;

        // Off = no flash
        if (m <= 0f)
        {
            group.alpha = 0f;
            return;
        }

        // Reduced/Full: scale intensity
        maxAlpha = Mathf.Clamp01(maxAlpha) * m;

        if (routine != null) StopCoroutine(routine);
        routine = StartCoroutine(FlashRoutine(pulses, onSeconds, offSeconds, maxAlpha));
    }

    public void ForceHide()
    {
        if (routine != null) StopCoroutine(routine);
        routine = null;

        if (group != null) group.alpha = 0f;
    }

    private IEnumerator FlashRoutine(int pulses, float onSeconds, float offSeconds, float maxAlpha)
    {
        pulses = Mathf.Max(1, pulses);
        onSeconds = Mathf.Max(0.001f, onSeconds);
        offSeconds = Mathf.Max(0f, offSeconds);
        maxAlpha = Mathf.Clamp01(maxAlpha);

        for (int i = 0; i < pulses; i++)
        {
            group.alpha = maxAlpha;
            yield return new WaitForSecondsRealtime(onSeconds);

            group.alpha = 0f;

            if (i < pulses - 1 && offSeconds > 0f)
                yield return new WaitForSecondsRealtime(offSeconds);
        }

        group.alpha = 0f;
        routine = null;
    }
}