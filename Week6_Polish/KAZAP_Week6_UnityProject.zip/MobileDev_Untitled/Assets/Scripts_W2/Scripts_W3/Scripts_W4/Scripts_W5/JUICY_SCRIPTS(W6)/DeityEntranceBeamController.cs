using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class DeityEntranceBeamController : MonoBehaviour
{
    [Header("UI References")]
    [SerializeField] private RectTransform overlayRootRect;   // OverlayRoot RectTransform
    [SerializeField] private RectTransform beamRect;          // DeityEntranceBeam RectTransform (this)
    [SerializeField] private CanvasGroup beamGroup;           // CanvasGroup on DeityEntranceBeam

    [Header("World Tracking")]
    [SerializeField] private Camera worldCamera;              // Main Camera
    [SerializeField] private float followSmooth = 25f;        // higher = snappier follow
    [SerializeField] private float xOffsetPixels = 0f;        // optional: nudge left/right

    [Header("Beam Alpha")]
    [SerializeField] private float maxAlpha = 0.22f;

    [Header("Beam Rollout")]
    [Tooltip("Beam grows from 0 height to full height over this time.")]
    [SerializeField] private float rolloutSeconds = 0.16f;

    [Tooltip("Tiny pause after rollout before Zeus appears/descends.")]
    [SerializeField] private float rolloutHoldSeconds = 0.05f;

    [Tooltip("Fade out time once Zeus has landed.")]
    [SerializeField] private float fadeOutSeconds = 0.12f;

    [Tooltip("Extra height coverage. 1.0 = exactly overlay height. Use 1.05+ for safety.")]
    [SerializeField] private float coveragePadding = 1.05f;

    [Header("Rollout SFX")]
    [SerializeField] private AudioSource rolloutSfxSource;
    [SerializeField] private AudioClip rolloutSfxClip;
    [SerializeField, Range(0f, 1f)] private float rolloutSfxVolume = 1f;

    private Transform targetWorld;
    private bool isFollowing = false;
    private float currentX;

    private Coroutine beamRoutine;

    private void Awake()
    {
        if (beamGroup != null) beamGroup.alpha = 0f;
        SetBeamHeightPx(0f);
    }

    private void Update()
    {
        if (!isFollowing || targetWorld == null || overlayRootRect == null || beamRect == null)
            return;

        Vector3 screenPos = (worldCamera != null)
            ? worldCamera.WorldToScreenPoint(targetWorld.position)
            : Camera.main.WorldToScreenPoint(targetWorld.position);

        if (screenPos.z < 0f) return;

        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                overlayRootRect,
                new Vector2(screenPos.x, screenPos.y),
                null,
                out Vector2 localPoint))
            return;

        float targetX = localPoint.x + xOffsetPixels;

        currentX = Mathf.Lerp(currentX, targetX, 1f - Mathf.Exp(-followSmooth * Time.unscaledDeltaTime));

        Vector2 ap = beamRect.anchoredPosition;
        ap.x = currentX;
        beamRect.anchoredPosition = ap;
    }

    // ---------------------------
    // NEW: Rollout + keep visible
    // ---------------------------
    public IEnumerator RolloutIn(Transform worldTarget)
    {
        // Rollout SFX (play once at rollout start)
        if (rolloutSfxSource != null && rolloutSfxClip != null)
        {
            rolloutSfxSource.Stop(); // optional: prevents overlap if spammed
            rolloutSfxSource.PlayOneShot(rolloutSfxClip, rolloutSfxVolume);
        }

        targetWorld = worldTarget;

        if (beamRoutine != null) StopCoroutine(beamRoutine);
        beamRoutine = null;

        SnapXNow();

        isFollowing = true;

        if (beamGroup != null) beamGroup.alpha = 0f;
        SetBeamHeightPx(0f);

        float fullHeight = GetFullHeightPx();
        float t = 0f;
        float dur = Mathf.Max(0.0001f, rolloutSeconds);

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a01 = Mathf.Clamp01(t / dur);

            SetBeamHeightPx(Mathf.Lerp(0f, fullHeight, a01));

            if (beamGroup != null)
                beamGroup.alpha = a01 * maxAlpha;

            yield return null;
        }

        SetBeamHeightPx(fullHeight);
        if (beamGroup != null) beamGroup.alpha = maxAlpha;

        if (rolloutHoldSeconds > 0f)
            yield return new WaitForSecondsRealtime(rolloutHoldSeconds);
    }

    // ---------------------------
    // NEW: Fade out + fully hide
    // ---------------------------
    public IEnumerator FadeOutAndHide()
    {
        if (beamRoutine != null) StopCoroutine(beamRoutine);
        beamRoutine = null;

        if (beamGroup == null)
        {
            isFollowing = false;
            targetWorld = null;
            SetBeamHeightPx(0f);
            yield break;
        }

        float startAlpha = beamGroup.alpha;
        float t = 0f;
        float dur = Mathf.Max(0.0001f, fadeOutSeconds);

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a01 = 1f - Mathf.Clamp01(t / dur);
            beamGroup.alpha = a01 * startAlpha;
            yield return null;
        }

        beamGroup.alpha = 0f;
        isFollowing = false;
        targetWorld = null;
        SetBeamHeightPx(0f);
    }

    // Keep your old API working (if anything calls it already)
    public void PlayBeam(Transform worldTarget, float fadeIn, float hold, float fadeOut)
    {
        targetWorld = worldTarget;

        if (beamRoutine != null) StopCoroutine(beamRoutine);
        beamRoutine = StartCoroutine(BeamRoutine(fadeIn, hold, fadeOut));
    }

    public void ForceHide()
    {
        if (beamRoutine != null) StopCoroutine(beamRoutine);
        beamRoutine = null;

        isFollowing = false;
        targetWorld = null;

        if (beamGroup != null) beamGroup.alpha = 0f;
        SetBeamHeightPx(0f);
    }

    private IEnumerator BeamRoutine(float fadeIn, float hold, float fadeOut)
    {
        if (beamGroup == null) yield break;

        SnapXNow();
        isFollowing = true;

        float t = 0f;
        float inDur = Mathf.Max(0.0001f, fadeIn);
        while (t < inDur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / inDur);
            beamGroup.alpha = a * maxAlpha;
            yield return null;
        }
        beamGroup.alpha = maxAlpha;

        if (hold > 0f)
            yield return new WaitForSecondsRealtime(hold);

        t = 0f;
        float outDur = Mathf.Max(0.0001f, fadeOut);
        while (t < outDur)
        {
            t += Time.unscaledDeltaTime;
            float a = 1f - Mathf.Clamp01(t / outDur);
            beamGroup.alpha = a * maxAlpha;
            yield return null;
        }

        beamGroup.alpha = 0f;
        isFollowing = false;
        targetWorld = null;
        beamRoutine = null;
    }

    private void SnapXNow()
    {
        if (targetWorld == null || overlayRootRect == null || beamRect == null) return;

        Vector3 screenPos = (worldCamera != null)
            ? worldCamera.WorldToScreenPoint(targetWorld.position)
            : Camera.main.WorldToScreenPoint(targetWorld.position);

        if (screenPos.z < 0f) return;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            overlayRootRect,
            new Vector2(screenPos.x, screenPos.y),
            null,
            out Vector2 localPoint);

        currentX = localPoint.x + xOffsetPixels;

        Vector2 ap = beamRect.anchoredPosition;
        ap.x = currentX;
        beamRect.anchoredPosition = ap;
    }

    private float GetFullHeightPx()
    {
        if (overlayRootRect == null) return 0f;
        return overlayRootRect.rect.height * coveragePadding;
    }

    private void SetBeamHeightPx(float height)
    {
        if (beamRect == null) return;
        beamRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, Mathf.Max(0f, height));
    }
}