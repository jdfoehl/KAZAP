using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class TitleZoomTransition : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private RectTransform overlayRoot;   // OverlayRoot RectTransform
    [SerializeField] private Image overlayImage;          // StartZoomOverlay Image
    [SerializeField] private CanvasGroup overlayGroup;    // StartZoomOverlay CanvasGroup

    [Header("Timing")]
    [SerializeField] private float zoomDuration = 0.30f;
    [SerializeField] private float fadeOutDuration = 0.12f;

    [Header("Flash Before Reveal")]
    [SerializeField] private bool enableFlashes = true;
    [SerializeField] private int flashCount = 3;
    [SerializeField] private float flashOnSeconds = 0.03f;
    [SerializeField] private float flashOffSeconds = 0.03f;
    [SerializeField] private Color flashColor = Color.white;

    [SerializeField] private float flashDimMultiplier = 0.35f; // 0.25�0.5 is a good range

    [Header("Coverage")]
    [Tooltip("Extra multiplier so we fully cover corners.")]
    [SerializeField] private float coverPaddingMultiplier = 1.2f;

    public bool IsPlaying { get; private set; }

    private Coroutine routine;

    private Color baseColor;

    private void Awake()
    {
        if (overlayRoot == null)
            overlayRoot = GetComponent<RectTransform>();

        if (overlayImage != null && overlayGroup == null)
            overlayGroup = overlayImage.GetComponent<CanvasGroup>();

        if (overlayImage != null)
            overlayImage.gameObject.SetActive(false);
    }

    public void Play(Image sourceButtonImage, Color overlayColor, Action onCovered)
    {
        if (sourceButtonImage == null || overlayRoot == null || overlayImage == null || overlayGroup == null)
        {
            Debug.LogWarning("[TitleZoomTransition] Missing references; cannot play transition.");
            onCovered?.Invoke();
            return;
        }

        if (routine != null)
        {
            StopCoroutine(routine);
            routine = null;
        }

        routine = StartCoroutine(PlayRoutine(sourceButtonImage, overlayColor, onCovered));
    }

    private IEnumerator PlayRoutine(Image sourceButtonImage, Color overlayColor, Action onCovered)
    {
        IsPlaying = true;

        // Copy look
        overlayImage.sprite = sourceButtonImage.sprite;
        overlayImage.type = sourceButtonImage.type;
        overlayImage.preserveAspect = sourceButtonImage.preserveAspect;
        overlayImage.color = overlayColor;

        baseColor = overlayColor;

        // Activate + reset
        overlayImage.gameObject.SetActive(true);
        overlayGroup.alpha = 1f;

        RectTransform src = sourceButtonImage.rectTransform;
        RectTransform dst = overlayImage.rectTransform;

        // Match position and size in OverlayRoot space
        Vector2 startPos = WorldToLocalPointIn(overlayRoot, src.position);
        dst.anchoredPosition = startPos;

        Vector2 startSize = GetRectSizeInParentSpace(src, overlayRoot);
        dst.sizeDelta = startSize;

        dst.localScale = Vector3.one;

        // Compute scale required to cover screen FROM THIS START POSITION (button is not centered)
        float rw = overlayRoot.rect.width;
        float rh = overlayRoot.rect.height;

        float bw = Mathf.Max(1f, startSize.x);
        float bh = Mathf.Max(1f, startSize.y);

        // OverlayRoot local-space bounds (handles any pivot)
        float left = -rw * overlayRoot.pivot.x;
        float right = rw * (1f - overlayRoot.pivot.x);
        float bottom = -rh * overlayRoot.pivot.y;
        float top = rh * (1f - overlayRoot.pivot.y);

        // startPos is the overlay center in OverlayRoot space
        Vector2 c0 = new Vector2(left, bottom);
        Vector2 c1 = new Vector2(left, top);
        Vector2 c2 = new Vector2(right, bottom);
        Vector2 c3 = new Vector2(right, top);

        // For each corner, compute required uniform scale so the overlay rectangle reaches that corner.
        // Required scale on X: 2*abs(dx)/buttonWidth, on Y: 2*abs(dy)/buttonHeight
        float s0x = (2f * Mathf.Abs(c0.x - startPos.x)) / bw;
        float s0y = (2f * Mathf.Abs(c0.y - startPos.y)) / bh;

        float s1x = (2f * Mathf.Abs(c1.x - startPos.x)) / bw;
        float s1y = (2f * Mathf.Abs(c1.y - startPos.y)) / bh;

        float s2x = (2f * Mathf.Abs(c2.x - startPos.x)) / bw;
        float s2y = (2f * Mathf.Abs(c2.y - startPos.y)) / bh;

        float s3x = (2f * Mathf.Abs(c3.x - startPos.x)) / bw;
        float s3y = (2f * Mathf.Abs(c3.y - startPos.y)) / bh;

        float scaleToCover = Mathf.Max(
            Mathf.Max(s0x, s0y),
            Mathf.Max(s1x, s1y),
            Mathf.Max(s2x, s2y),
            Mathf.Max(s3x, s3y)
        );

        scaleToCover = Mathf.Max(1f, scaleToCover) * coverPaddingMultiplier;

        // Zoom
        float t = 0f;
        float dur = Mathf.Max(0.01f, zoomDuration);

        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(t / dur);

            // Smoothstep
            float eased = a * a * (3f - 2f * a);

            float s = Mathf.Lerp(1f, scaleToCover, eased);
            dst.localScale = new Vector3(s, s, 1f);

            yield return null;
        }

        dst.localScale = new Vector3(scaleToCover, scaleToCover, 1f);

        // Fully covered now � do flashes BEFORE we start gameplay + reveal
        if (enableFlashes && flashCount > 0)
        {
            float fm = PolishAccessibilitySettings.FlashMultiplier;

            // OFF = no flashes
            if (fm > 0f)
            {
                // Dim base color so the "flash" actually reads
                Color dimFull = new Color(
                    baseColor.r * flashDimMultiplier,
                    baseColor.g * flashDimMultiplier,
                    baseColor.b * flashDimMultiplier,
                    baseColor.a
                );

                // Reduced = less contrast + fewer flashes
                Color dim = Color.Lerp(baseColor, dimFull, fm);
                Color flash = Color.Lerp(dim, flashColor, fm);

                int count = flashCount;
                if (fm < 1f)
                    count = Mathf.Max(1, Mathf.RoundToInt(flashCount * fm));

                for (int i = 0; i < count; i++)
                {
                    overlayImage.color = flash;
                    yield return new WaitForSecondsRealtime(Mathf.Max(0f, flashOnSeconds));

                    overlayImage.color = dim;
                    yield return new WaitForSecondsRealtime(Mathf.Max(0f, flashOffSeconds));
                }

                // Return to base before we start gameplay
                overlayImage.color = baseColor;
            }
            else
            {
                // Ensure we stay at base (no flashing)
                overlayImage.color = baseColor;
            }
        }

        // NOW start gameplay (still hidden behind overlay)
        onCovered?.Invoke();

        // Fade out to reveal gameplay
        float ft = 0f;
        float fd = Mathf.Max(0.01f, fadeOutDuration);

        while (ft < fd)
        {
            ft += Time.unscaledDeltaTime;
            float a = Mathf.Clamp01(ft / fd);
            overlayGroup.alpha = 1f - a;
            yield return null;
        }

        overlayGroup.alpha = 0f;
        overlayImage.gameObject.SetActive(false);

        IsPlaying = false;
        routine = null;
    }

    private static Vector2 WorldToLocalPointIn(RectTransform parent, Vector3 worldPos)
    {
        Vector3 local = parent.InverseTransformPoint(worldPos);
        return new Vector2(local.x, local.y);
    }

    private static Vector2 GetRectSizeInParentSpace(RectTransform src, RectTransform desiredParent)
    {
        Vector3[] corners = new Vector3[4];
        src.GetWorldCorners(corners);

        Vector3 a = desiredParent.InverseTransformPoint(corners[0]);
        Vector3 c = desiredParent.InverseTransformPoint(corners[2]);

        float w = Mathf.Abs(c.x - a.x);
        float h = Mathf.Abs(c.y - a.y);

        return new Vector2(w, h);
    }
}