using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TextScalingManager : MonoBehaviour
{
    [Header("UI Refs (Settings Panel)")]
    public Slider textSizeSlider;
    public TextMeshProUGUI sampleText;
    public TextMeshProUGUI percentageDisplay;

    [Header("Scale Scope (HUD + Prompts ONLY)")]
    [Tooltip("ONLY TextMeshProUGUI under these roots will be scaled.\n" +
             "Recommended: assign HudPanel (and any prompt objects that live outside HudPanel).\n" +
             "Do NOT assign PausePanel or SettingsPanel.")]
    public Transform[] includedRoots;

    [Tooltip("If true, will include inactive children under includedRoots (recommended).")]
    public bool includeInactive = true;

    [Header("Scale Range")]
    [Range(0.1f, 3f)] public float minScale = 0.75f;
    [Range(0.1f, 3f)] public float maxScale = 1.25f;

    private float textScaleMultiplier = 1f;

    // Store base sizes for INCLUDED text elements only
    private readonly Dictionary<TextMeshProUGUI, float> originalSizes = new Dictionary<TextMeshProUGUI, float>();

    private const string PREF_KEY = "TextScale";

    private void Start()
    {
        if (textSizeSlider == null)
        {
            Debug.LogError("TextScalingManager: textSizeSlider is not assigned.");
            enabled = false;
            return;
        }

        // Configure slider
        textSizeSlider.minValue = minScale;
        textSizeSlider.maxValue = maxScale;

        // Load saved preference (clamped)
        textScaleMultiplier = Mathf.Clamp(PlayerPrefs.GetFloat(PREF_KEY, 1f), minScale, maxScale);
        textSizeSlider.SetValueWithoutNotify(textScaleMultiplier);

        // Register ONLY the text we intend to scale
        RegisterIncludedText();

        // Listen for changes
        textSizeSlider.onValueChanged.RemoveListener(OnTextSizeChanged);
        textSizeSlider.onValueChanged.AddListener(OnTextSizeChanged);

        // Apply immediately
        ApplyTextScaling();
        UpdatePercentageLabel();
    }

    private void RegisterIncludedText()
    {
        originalSizes.Clear();

        // 1) Collect TMP under included roots (HUD + prompts)
        if (includedRoots != null)
        {
            for (int r = 0; r < includedRoots.Length; r++)
            {
                Transform root = includedRoots[r];
                if (root == null) continue;

                TextMeshProUGUI[] texts = root.GetComponentsInChildren<TextMeshProUGUI>(includeInactive);
                for (int i = 0; i < texts.Length; i++)
                {
                    TextMeshProUGUI t = texts[i];
                    if (t == null) continue;

                    // Safety: skip input fields if ever added later
                    if (t.GetComponentInParent<TMP_InputField>(true) != null)
                        continue;

                    if (!originalSizes.ContainsKey(t))
                        originalSizes.Add(t, t.fontSize);
                }
            }
        }

        // 2) ALWAYS include the Settings sample preview + percentage label
        // (so the slider feels responsive even though SettingsPanel isn't being scaled globally)
        if (sampleText != null && !originalSizes.ContainsKey(sampleText))
            originalSizes.Add(sampleText, sampleText.fontSize);

        if (percentageDisplay != null && !originalSizes.ContainsKey(percentageDisplay))
            originalSizes.Add(percentageDisplay, percentageDisplay.fontSize);
    }

    private void OnTextSizeChanged(float value)
    {
        textScaleMultiplier = Mathf.Clamp(value, minScale, maxScale);
        textSizeSlider.SetValueWithoutNotify(textScaleMultiplier);

        PlayerPrefs.SetFloat(PREF_KEY, textScaleMultiplier);
        PlayerPrefs.Save();

        ApplyTextScaling();
        UpdatePercentageLabel();
    }

    private void ApplyTextScaling()
    {
        // If something got rebuilt / lost references, rebuild the list (cheap for this project size)
        if (originalSizes.Count == 0)
            RegisterIncludedText();

        foreach (var pair in originalSizes)
        {
            TextMeshProUGUI t = pair.Key;
            float baseSize = pair.Value;

            if (t == null) continue;

            t.fontSize = baseSize * textScaleMultiplier;
        }
    }

    private void UpdatePercentageLabel()
    {
        if (percentageDisplay == null) return;
        percentageDisplay.text = $"TEXT: {(textScaleMultiplier * 100f):F0}%";
    }

    // Optional helper if you ever spawn a NEW HUD TMP at runtime:
    public void RegisterNewHudText(TextMeshProUGUI t)
    {
        if (t == null) return;
        if (t.GetComponentInParent<TMP_InputField>(true) != null) return;

        if (!originalSizes.ContainsKey(t))
            originalSizes.Add(t, t.fontSize);

        t.fontSize = originalSizes[t] * textScaleMultiplier;
    }
}