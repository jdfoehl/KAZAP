using UnityEngine;

[RequireComponent(typeof(RectTransform))]
public class SafeAreaFitter : MonoBehaviour
{
    [Header("Extra Padding (in screen pixels)")]
    public int extraLeft = 0;
    public int extraRight = 0;
    public int extraTop = 0;
    public int extraBottom = 0;

    private RectTransform rect;
    private Rect lastSafeArea;
    private ScreenOrientation lastOrientation;
    private Vector2Int lastScreen;

    private void Awake()
    {
        rect = GetComponent<RectTransform>();
        ApplySafeArea();
    }

    private void OnEnable()
    {
        ApplySafeArea();
    }

    private void Update()
    {
        // Re-apply if something changes (rotation, resolution, safe area)
        if (Screen.safeArea != lastSafeArea ||
            Screen.orientation != lastOrientation ||
            lastScreen.x != Screen.width ||
            lastScreen.y != Screen.height)
        {
            ApplySafeArea();
        }
    }

    private void ApplySafeArea()
    {
        Rect safe = Screen.safeArea;

        // Apply extra padding inwards
        safe.xMin += extraLeft;
        safe.xMax -= extraRight;
        safe.yMin += extraBottom;
        safe.yMax -= extraTop;

        // Clamp to screen bounds
        safe.xMin = Mathf.Clamp(safe.xMin, 0, Screen.width);
        safe.xMax = Mathf.Clamp(safe.xMax, 0, Screen.width);
        safe.yMin = Mathf.Clamp(safe.yMin, 0, Screen.height);
        safe.yMax = Mathf.Clamp(safe.yMax, 0, Screen.height);

        lastSafeArea = Screen.safeArea;
        lastOrientation = Screen.orientation;
        lastScreen = new Vector2Int(Screen.width, Screen.height);

        Vector2 anchorMin = safe.position;
        Vector2 anchorMax = safe.position + safe.size;

        anchorMin.x /= Screen.width;
        anchorMin.y /= Screen.height;
        anchorMax.x /= Screen.width;
        anchorMax.y /= Screen.height;

        rect.anchorMin = anchorMin;
        rect.anchorMax = anchorMax;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;
    }
}