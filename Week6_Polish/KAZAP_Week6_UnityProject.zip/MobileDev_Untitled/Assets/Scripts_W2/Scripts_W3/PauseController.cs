using UnityEngine;
using UnityEngine.UI;

public class PauseController : MonoBehaviour
{
    [Header("Refs")]
    public RoundManager roundManager;
    public GameObject pausePanel;
    public GameObject settingsPanel;

    [Tooltip("Optional: lock shield dragging while paused/settings.")]
    public ShieldDragController shieldDrag;

    [Header("Buttons (optional if you wire via Inspector OnClick)")]
    public Button resumeButton;
    public Button quitToTitleButton;

    private bool isPaused;
    private bool openedSettingsFromTitle;

    private void Awake()
    {
        // Ensure we start unpaused and panels are hidden.
        isPaused = false;

        if (pausePanel != null) pausePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);

        if (resumeButton != null)
            resumeButton.onClick.AddListener(Resume);

        if (quitToTitleButton != null)
            quitToTitleButton.onClick.AddListener(QuitToTitle);
    }

    // ---------- PAUSE FLOW ----------
    public void TogglePause()
    {
        if (roundManager != null && (roundManager.IsGameOver || roundManager.IsInLossSequence))
            return;

        SetPaused(!isPaused);
    }

    public void Pause()
    {
        if (roundManager != null && (roundManager.IsGameOver || roundManager.IsInLossSequence))
            return;

        SetPaused(true);
    }

    public void Resume()
    {
        SetPaused(false);
    }

    public void QuitToTitle()
    {
        // Leaving pause/settings should always unpause.
        SetPaused(false);

        if (roundManager != null)
            roundManager.UI_QuitToTitle();
    }

    // ---------- SETTINGS OPEN ----------
    // Called from Pause menu "Settings" button
    public void OpenSettings_FromPause()
    {
        openedSettingsFromTitle = false;

        // Stay paused
        if (!isPaused)
            SetPaused(true);

        if (pausePanel != null) pausePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(true);
    }

    // Called from Title screen "Options" button
    public void OpenSettings_FromTitle()
    {
        openedSettingsFromTitle = true;

        // Title flow: do NOT pause time (you're not in gameplay)
        // Just swap panels.
        if (pausePanel != null) pausePanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(true);
    }

    // Back button on Settings panel calls THIS (always)
    public void CloseSettings()
    {
        if (settingsPanel != null) settingsPanel.SetActive(false);

        if (openedSettingsFromTitle)
        {
            // Return to TITLE (not pause)
            openedSettingsFromTitle = false;

            if (pausePanel != null) pausePanel.SetActive(false);
            // Title panel is handled by RoundManager; it should already be active.
            // If you have a TitlePanel ref somewhere else, you'd enable it here.
            return;
        }

        // Return to PAUSE menu
        if (pausePanel != null) pausePanel.SetActive(true);
    }

    // ---------- CORE PAUSE ----------
    private void SetPaused(bool paused)
    {
        isPaused = paused;

        Time.timeScale = paused ? 0f : 1f;

        if (shieldDrag != null)
        {
            if (paused) shieldDrag.ForceCancelDrag();
            shieldDrag.inputLocked = paused;
        }

        // When unpausing, hide BOTH menus
        if (!paused)
        {
            if (pausePanel != null) pausePanel.SetActive(false);
            if (settingsPanel != null) settingsPanel.SetActive(false);
            openedSettingsFromTitle = false;
            return;
        }

        // When pausing, show pause panel by default (settings stays hidden unless opened)
        if (pausePanel != null) pausePanel.SetActive(true);
        if (settingsPanel != null) settingsPanel.SetActive(false);
    }
}