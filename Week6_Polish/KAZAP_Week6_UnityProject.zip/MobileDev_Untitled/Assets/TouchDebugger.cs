using TMPro;
using UnityEngine;

public class TouchDebugger : MonoBehaviour
{
    [Header("UI")]
    public TextMeshProUGUI debugText;

    // Mouse-sim tracking
    private Vector2 pressStartMousePos;
    private Vector2 lastMousePos;
    private bool mouseWasDown;

    void Update()
    {
        if (debugText == null) return;

        // =========================
        // REAL TOUCH (on device)
        // =========================
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);

            debugText.text =
                $"Touch Count: {Input.touchCount}\n" +
                $"Touch ID: {t.fingerId}\n" +
                $"Position: {t.position}\n" +
                $"Phase: {t.phase}\n" +
                $"Delta (per-frame): {t.deltaPosition}";
            return;
        }

        // =========================
        // EDITOR MOUSE SIM (no device)
        // =========================
        bool mouseDown = Input.GetMouseButton(0);
        bool mousePressedThisFrame = Input.GetMouseButtonDown(0);
        bool mouseReleasedThisFrame = Input.GetMouseButtonUp(0);

        // Idle
        if (!mouseDown && !mouseWasDown)
        {
            debugText.text =
                "No touches detected.\n" +
                "Touch the screen!";
            return;
        }

        Vector2 mousePos = Input.mousePosition;

        // Simulated phase
        string phase;

        if (mousePressedThisFrame)
        {
            pressStartMousePos = mousePos;
            lastMousePos = mousePos;
            phase = "Began (sim)";
        }
        else if (mouseReleasedThisFrame)
        {
            phase = "Ended (sim)";
        }
        else
        {
            // TOTAL movement since press (this is the key clarity improvement)
            Vector2 totalDeltaHeld = mousePos - pressStartMousePos;

            // Treat as "Moved" once total movement passes a small threshold (pixels)
            phase = (totalDeltaHeld.sqrMagnitude > 25f) ? "Moved (sim)" : "Stationary (sim)";
        }

        // Per-frame delta AND total delta
        Vector2 frameDelta = mousePos - lastMousePos;
        Vector2 totalDelta = mousePos - pressStartMousePos;

        // Update last position while held so per-frame delta is meaningful
        if (mouseDown) lastMousePos = mousePos;

        int simTouchCount = mouseDown ? 1 : 0;

        debugText.text =
            $"Touch Count: {simTouchCount} (Editor Mouse Sim)\n" +
            $"Touch ID: -1\n" +
            $"Position: ({mousePos.x:F0}, {mousePos.y:F0})\n" +
            $"Phase: {phase}\n" +
            $"Delta (per-frame): ({frameDelta.x:F0}, {frameDelta.y:F0})\n" +
            $"Delta (total): ({totalDelta.x:F0}, {totalDelta.y:F0})";

        mouseWasDown = mouseDown;
    }
}